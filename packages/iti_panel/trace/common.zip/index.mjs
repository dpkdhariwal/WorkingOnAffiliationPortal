import dotenv from "dotenv";
// Load correct .env file based on NODE_ENV
dotenv.config({
  path: `.env.${process.env.NODE_ENV || "development"}`,
});
import path from "path";
import serveIndex from "serve-index";


/* eslint-disable no-undef */
import express from "express";
import cors from "cors";

import jwt from "jsonwebtoken";
import cookieParser from "cookie-parser";
import { createServer } from "node:http";
import { Server } from "socket.io";

import applicant from "./routes/applicant.js";
import state from "./routes/state.js";
import generals from "./routes/general.js";
import basicAuth from "express-basic-auth";


import auth from "./routes/auth.js";
// import task from "./routes/task.js";
import { applicantToken } from './Middleware/auth.js';
import { multerErrorHandler } from "./services/multer/configs.js";

// LGD Routes
import statesRoutes from "./routes/statesRoutes.js";
import districtsRoutes from "./routes/districtsRoutes.js";
import subdistrictsRoutes from "./routes/subdistrictsRoutes.js";
import villagesRoutes from "./routes/villagesRoutes.js";
import pincodeRoutes from "./routes/pincodeRoutes.js";
import dstRoutes from "./routes/dstRoutes.js";
import itiRoutes from "./routes/itiRoutes.js";


const port = process.env.PORT || 3000;

console.log(27, process.env.PORT);

const allowedOrigins = ["http://localhost:5173", "http://localhost:5174", "http://localhost:9000", "http://localhost:3001", "http://10.202.3.43:3000"];


const app = express();

// Middleware
app.use(cookieParser());
app.use(express.json()); 

app.use(cors({
  origin: ["http://localhost:5173", "http://localhost:5174", "http://localhost", "https://affiliation.dgt.gov.in"],  // your frontend
  credentials: true
}));

const apiRouter = express.Router();

apiRouter.use("/general", applicantToken, generals);
apiRouter.use("/applicant", applicantToken, applicant);
apiRouter.use("/state", applicantToken, state);
apiRouter.use("/auth", auth);
// apiRouter.use("/task", task);

// LGD Routes
const lgdRouter = express.Router();
lgdRouter.use("/states", applicantToken, statesRoutes);
lgdRouter.use("/districts", applicantToken, districtsRoutes);
lgdRouter.use("/subdistricts", applicantToken, subdistrictsRoutes);
lgdRouter.use("/villages", applicantToken, villagesRoutes);
lgdRouter.use("/pincode", applicantToken, pincodeRoutes);
lgdRouter.use("/dst", applicantToken, dstRoutes);
lgdRouter.use("/iti", applicantToken, itiRoutes);

apiRouter.use("/lgd", lgdRouter);  // <-- mount lgd under /api
app.use("/api", apiRouter); // <-- all under /api


// Serve Uploads
const uploadsPath = path.resolve("E:/all_uploaded_affiliation_documents/temp_files/");

// app.use(
//   "/uploads",
//   express.static("E:/all_uploaded_affiliation_documents/temp_files"),
//   serveIndex("E:/all_uploaded_affiliation_documents/temp_files", { icons: true })
// );
app.use(
  "/uploads",
  basicAuth({
    users: { admin: "123" }, // username: admin, password: password123
    challenge: true, // shows login dialog in browser
  }),
  express.static(process.env.UPLOAD_ROOT_PATH),
  serveIndex(process.env.UPLOAD_ROOT_PATH, { icons: true })
);


// Error handling middleware (keep only one)
app.use((req, res) => {
  res.status(404).send("Route Not Found");
});



// Server
const server = createServer(app);

const io = new Server(server, { cors: { origin: allowedOrigins, credentials: true, }, });

io.use((socket, next) => {
  if (socket.request) {
    next();
  } else {
    next(new Error("Invalid socket request"));
  }
});


io.on("connection", (socket) => {
  console.log("A user connected");
});


server.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});

