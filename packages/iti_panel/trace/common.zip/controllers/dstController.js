import Dst from '../models/Dst.js';

export const getAllDst = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    const dsts = await Dst.findAndCountAll({
    //   where: { user_id: req.user.id },
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['created_at', 'DESC']],
    });

    res.json({
      dsts: dsts.rows,
      total: dsts.count,
      page: parseInt(page),
      totalPages: Math.ceil(dsts.count / limit),
    });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching DST records', error: error.message });
  }
};

export const getDstById = async (req, res) => {
  try {
    const { id } = req.params;

    const dst = await Dst.findOne({
      where: { id, user_id: req.user.id },
    });

    if (!dst) {
      return res.status(404).json({ message: 'DST record not found' });
    }

    res.json(dst);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching DST record', error: error.message });
  }
};

export const createDst = async (req, res) => {
  try {
    const dstData = {
      ...req.body,
      user_id: req.user.id,
    };

    const dst = await Dst.create(dstData);

    res.status(201).json({ message: 'DST record created successfully', dst });
  } catch (error) {
    if (error.name === 'SequelizeValidationError') {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    res.status(500).json({ message: 'Error creating DST record', error: error.message });
  }
};

export const updateDst = async (req, res) => {
  try {
    const { id } = req.params;

    const [updatedRowsCount] = await Dst.update(req.body, {
      where: { id, user_id: req.user.id },
    });

    if (updatedRowsCount === 0) {
      return res.status(404).json({ message: 'DST record not found or no changes made' });
    }

    const updatedDst = await Dst.findOne({ where: { id } });

    res.json({ message: 'DST record updated successfully', dst: updatedDst });
  } catch (error) {
    if (error.name === 'SequelizeValidationError') {
      return res.status(400).json({ message: 'Validation error', errors: error.errors });
    }
    res.status(500).json({ message: 'Error updating DST record', error: error.message });
  }
};

export const deleteDst = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedRowsCount = await Dst.destroy({
      where: { id, user_id: req.user.id },
    });

    if (deletedRowsCount === 0) {
      return res.status(404).json({ message: 'DST record not found' });
    }

    res.json({ message: 'DST record deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting DST record', error: error.message });
  }
};
