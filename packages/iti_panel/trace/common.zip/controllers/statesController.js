import State from '../models/State.js';


export const getStates = async (req, res) => {
  try {
    const states = await State.findAll({
      attributes: ['stateCode', 'stateNameEnglish', 'stateNameLocal', 'shortName', 'census2011Code', 'effectiveDate', 'lastUpdated', 'majorVersion', 'minorVersion', 'stateOrUt', 'transactionId', 'operationCode', 'transactionDescription', 'isactive'],
      order: [['stateNameEnglish', 'ASC']]
    });
    res.json(states);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching states data', error: error.message });
  }
};
