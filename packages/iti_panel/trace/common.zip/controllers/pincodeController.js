import Village from '../models/Village.js';
import { Sequelize } from 'sequelize';

export const getPincode = async (req, res) => {
  try {
    const { villageCode } = req.body;
    if (!villageCode) {
      return res.status(400).json({ message: 'villageCode is required' });
    }
    const pincodes = await Village.findAll({
      where: { villageCode },
      attributes: [[Sequelize.fn('DISTINCT', Sequelize.col('pincode')), 'pincode']],
      raw: true
    });
    // Filter out null/undefined pincodes and flatten result
    const uniquePincodes = pincodes
      .map(p => p.pincode)
      .filter((p, i, arr) => p && arr.indexOf(p) === i);
    if (uniquePincodes.length === 1) {
      res.json({ pincode: uniquePincodes[0] });
    } else if (uniquePincodes.length === 0) {
      res.status(404).json({ message: 'No pincode found for the given input.' });
    } else {
      res.json({ pincodes: uniquePincodes });
    }
  } catch (error) {
    res.status(500).json({ message: 'Error fetching pincodes', error: error.message });
  }
};
