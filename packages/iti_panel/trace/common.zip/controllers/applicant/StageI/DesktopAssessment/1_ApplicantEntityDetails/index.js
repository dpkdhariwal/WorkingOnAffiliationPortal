import dotenv from "dotenv";
// Load correct .env file based on NODE_ENV
dotenv.config({ path: `.env.${process.env.NODE_ENV || "development"}`, });
/* eslint-disable no-undef */
import jwt from "jsonwebtoken";
import fs from "fs";
import path from "path";

const dir = path.join("uploads");
import mysql from "mysql2/promise";
import { pKeyPath } from "../../common/common.js";
import { masterConfig, eMsg, dbConfig, affDbConfig } from "../db.js";


const privateKey = fs.readFileSync(pKeyPath, "utf8");
import * as cons from "../../constant/constants.js";
import { throws } from "assert";

import dayjs from "dayjs";
import utc from "dayjs/plugin/utc.js";
import timezone from "dayjs/plugin/timezone.js";
import { upload, upload2 } from "../../services/multer/configs.js";

import { pid } from "../../index.js";
import { landDetail } from "../../index.js";

dayjs.extend(utc);
dayjs.extend(timezone);
let updateDate;
export const formattedDate = dayjs().tz("Asia/Kolkata").toISOString();
export const submitDate = updateDate = dayjs().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
// console.log("ISO India:", formattedDate);

import { sequelize } from '../../config/database.js';

import AppFlow from "../Sequelize/AppFlow.js";
import AppFormSubCivilInfra from "../Sequelize/AppFormSubCivilInfra.js";
import EntEntityDetails from "../Sequelize/EntEntityDetails.js";
import EntityAddress from "../Sequelize/EntityAddress.js";
import EntOtherITI from "../Sequelize/EntOtherITI.js";
import FormFlowStageI from "../Sequelize/FormFlowStageI.js";
import FormFlowStageII from "../Sequelize/FormFlowStageII.js";

import PIA_Details from "../Sequelize/ProposedInstituteAddressesDetails.js";
import PIDetails from "../Sequelize/ProposedProposedInstituteDetails.js";



import LandInstDetail from "../Sequelize/LandInstDetail.js";
import LandLeasedLand from "../Sequelize/LandLeasedLand.js";
import LandOwnedLand from "../Sequelize/LandOwnedLand.js";







import { st1form } from "../../index.js";
import TradeAreaInfo from "../Sequelize/tradeAreaInfo.js";
import MasterTradeInfo from "../Sequelize/tradeAreaInfo.js";
import TradesNewInstTrades from "../Sequelize/tradesNewInstTrades.js";

import get from "lodash.get";
import LeaseDeedDocument from "../Sequelize/LeaseDeedDocument.js";
import LandConversionCertificates from "../Sequelize/LandConversionCertificates.js";
import AuthorizedSignatoryDetail from "../Sequelize/AuthorizedSignatoryDetail.js";
import Certificat from "../Sequelize/Certificat.js";
import SecretaryChairpersonPresidentIdInfo from "../Sequelize/SecretaryChairpersonPresidentIdInfo.js";
import ProposedProposedInstituteDetails from "../Sequelize/ProposedProposedInstituteDetails.js";
import LandDocuments from "../Sequelize/land_documents.js";
import Stage1Documents from "../Sequelize/stage1_documents.js";
import InitialCertificats from "../Sequelize/initial_certificats.js";
import InitialAuthorizedSignatoryDetails from "../Sequelize/initial_authorized_signatory_details.js";
import InitialSecretaryChairpersonPresidentIdInfo from "../Sequelize/initial_secretary_chairperson_president_id_info.js";
import AppAssessmentFlowStageI from "../Sequelize/AppAssessmentFlowStageI.js";
import AssessmentStatus from "../Sequelize/AssessmentStatus.js";


export const setEntityDetails = async (req, res) => {
  let connection, stmt, results, update, formattedDate, jsonData, userId, submitDate, updateDate;
  // formattedDate = new Date().toISOString(); // "2025-08-05T07:25:13.123Z"
  // submitDate = new Date().toISOString().slice(0, 19).replace('T', ' ');

  formattedDate = dayjs().tz("Asia/Kolkata").toISOString();
  // console.log("ISO India:", formattedDate);

  submitDate = updateDate = dayjs().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

  // console.log("MySQL India:", submitDate);
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  const t = await sequelize.transaction();
  try {
    // connection = await mysql.createConnection(affDbConfig);
    const { data, appId } = req.body;
    const { email } = req.user;
    userId = req.userInfo.user_id;
    jsonData = JSON.parse(data);


    // Create directory if it doesn't exist
    const dir = path.join(process.env.TEMP_FILES_UPLOAD_PATH, appId);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      console.log("Directory created:", dir);
    } else {
      console.log("Directory already exists:", dir);
    }
    // End

    // Converting in Sequelize Object
    const found = await AppFlow.findOne({ where: { appId: appId } });
    if (!found) {
      const mainStepsData = cons.AppFlow.map((step) => ({ ...step, appId: appId, userId: userId, }));
      await AppFlow.bulkCreate(mainStepsData, { transaction: t });
    }


    // Settign Up Stage I Form Flow
    const found2 = await FormFlowStageI.findOne({ where: { appId: appId } });
    if (!found2) {
      const mainStepsData = cons.STAGE_I_APP_FORM_FLOW.map((step) => {
        switch (step.step) {
          case cons.ST1FC.APPLICANT_ENTITY_DETAILS.step:
            return { ...step, status: cons.FILLED, submitDate: cons.currentDate, appId: appId, userId: userId, }
          case cons.ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step:
            return { ...step, stepStatus: cons.SL.ACTIVE, appId: appId, userId: userId }
          default:
            return { ...step, appId: appId, userId: userId, }
        }

      });
      await FormFlowStageI.bulkCreate(mainStepsData, { transaction: t });
      // throw mainStepsData;
    }



    // Settign Up Stage I Form Flow
    const found3 = await FormFlowStageII.findOne({ where: { appId: appId } });
    if (!found3) {
      const mainStepsData = cons.STAGE_II_APP_FORM_FLOW.map((step) => ({ ...step, appId: appId, userId: userId, }));
      await FormFlowStageII.bulkCreate(mainStepsData, { transaction: t });
      for (const [index, flow] of mainStepsData.entries()) {
        if ("subSteps" in flow) {
          switch (flow.step) {
            case cons.CIVIL_INFRASTRUCTURE_DETAIL:
              const mainStepsData = flow.subSteps.map((step) => ({ ...step, appId: appId, userId: userId, }));
              await AppFormSubCivilInfra.bulkCreate(mainStepsData, { transaction: t });
            default:
              break;
          }
        }
      }
    }


    const found5 = await EntEntityDetails.findOne({ where: { appId: appId } });
    const toSave = {
      aff_category: jsonData.aff_category,
      aff_sub_category: jsonData.aff_sub_category,
      category: jsonData.category,
      name_of_applicant_entity: jsonData.name_of_applicant_entity,
      ApplicantEntityEmailId: jsonData.ApplicantEntityEmailId,
      isApplicantEntityEmailIdVerified: jsonData.isApplicantEntityEmailIdVerified,
      ApplicantContactNumber: jsonData.ApplicantContactNumber,
      Is_the_applicant_running_any_other_iti: jsonData.Is_the_applicant_running_any_other_iti,
      appId: appId,
      userId: userId
    }
    if (found5) {
      await EntEntityDetails.update(toSave, { where: { appId } }); // 👈 here
      console.log("✅ Updated existing record");
    } else {
      await EntEntityDetails.create(toSave);
      console.log("✅ Inserted new record");
    }


    // Save Entity Address
    const toSave2 = {
      state_code: jsonData.ApplicantEntityState,
      district_code: jsonData.ApplicantEntityDistrict,
      sub_district_code: jsonData.ApplicantEntitySubDistrict,
      village_code: jsonData.ApplicantEntityVillage,
      pincode: jsonData.ApplicantEntityPincode,
      plotNumber_khasaraNumber_gataNumber: jsonData.ApplicantEntityPlotNumber_KhasaraNumber_GataNumber,
      landmark: jsonData.ApplicantEntityLandmark,
      appId: appId,
      userId: userId
    }
    const found6 = await EntityAddress.findOne({ where: { appId: appId } });
    if (found6) {
      await EntityAddress.update(toSave2, { where: { appId } }); // 👈 here
      console.log("✅ Updated existing record");
    } else {
      await EntityAddress.create(toSave2);
      console.log("✅ Inserted new record");
    }

    if (jsonData.Is_the_applicant_running_any_other_iti === "yes") {
      await EntOtherITI.destroy({ where: { appId }, transaction: t });
      const mainStepsData = jsonData.runningITIs.map((obj) => ({ ...obj, appId: appId, userId: userId, }));
      await EntOtherITI.bulkCreate(mainStepsData, { transaction: t });
    }
    else if (jsonData.Is_the_applicant_running_any_other_iti === "no") {
      await EntOtherITI.destroy({ where: { appId }, transaction: t });
    }

    await t.commit();
    console.log("Multiple records inserted within transaction ✅");

  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    // if (connection) await connection.end();
  }
  return { msg: "Information Successfully" };

};

export const getAppListByUserId = async (req, res) => {
  let connection, stmt, results, update, formattedDate, jsonData, userId, submitDate, updateDate;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  let enrichedApps;
  try {

    connection = await mysql.createConnection(affDbConfig);

    const { data, appId } = req.body;
    userId = req.userInfo.user_id;
    const { state, userType, state_code } = req.userInfo;


    // throw req.userInfo;



    // const list = await EntEntityDetails.findAll({
    //   where: {},
    //   include: [
    //     {
    //       model: ProposedProposedInstituteDetails,
    //       as: "proposedInstitute",  // matches hasOne alias
    //       required: false
    //     }
    //   ]
    // });

    // throw lsit;


    // throw req.userInfo;


    let sel_entity_details, result, finalResult;
    await connection.beginTransaction();
    // return userType;
    switch (userType) {
      case "applicant":
        sel_entity_details = await connection.prepare('SELECT * FROM `' + cons.ENTITY_DETAILS + '` WHERE userId = ?');
        result = await sel_entity_details.execute([userId]);
        finalResult = result[0];
        break;
      case "dgt":
        sel_entity_details = await connection.prepare('SELECT * FROM `' + cons.ENTITY_DETAILS + '` WHERE 1');
        result = await sel_entity_details.execute([userId]);
        finalResult = result[0];
        break;
      case "rdsde":
        sel_entity_details = await connection.prepare('SELECT * FROM `' + cons.ENTITY_DETAILS + '` WHERE 1');
        result = await sel_entity_details.execute([userId]);
        finalResult = result[0];
        break;
      case "state_admin":
        sel_entity_details = await connection.prepare('SELECT * FROM `' + cons.ENTITY_DETAILS + '` WHERE 1');
        result = await sel_entity_details.execute([userId]);
        finalResult = result[0];
        break;
      case "state_assessor":

        // // One-to-One relationship (adjust if it should be One-to-Many)
        // let found3 = EntEntityDetails.hasOne(ProposedProposedInstituteDetails, {
        //   foreignKey: "appId",      // field in ProposedProposedInstituteDetails
        //   sourceKey: "appId",       // field in EntEntityDetails
        //   as: "proposedInstitute"   // alias used in include
        // });

        // throw found3;
        // throw state_code;
        sel_entity_details = await connection.prepare(`SELECT t1.*, t2.state_code FROM ent_entitydetails as t1 JOIN proposed_proposedinstituteaddressesdetails as t2 on t1.appId=t2.appId and t2.state_code=?`);
        result = await sel_entity_details.execute([state_code]);
        finalResult = result[0];
        break;
      default:
        throw new Error("User Profile is Incorrect");
        break;
    }
    // return state;
    if (!finalResult || finalResult.length === 0) {
      throw new Error("Applications Not Found");
    }

    enrichedApps = await Promise.all(
      finalResult.map(async (app) => {
        const entityDetails = await getEntityDetailsByUserId(req, res, connection, app.appId); // <-- await here!
        const proposedInstDetails = await getProposedInstDetailsByUserId(req, res, connection, app.appId);
        return { ...app, ...entityDetails, proposedInstDetails, };
      })
    );

    // Commit the transaction
    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }

  return enrichedApps;


};

export const getAppListByStateUser = async (req, res) => {
  let connection, stmt, results, update, formattedDate, jsonData, userId, submitDate, updateDate;

  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {

    connection = await mysql.createConnection(affDbConfig);

    const { data, appId } = req.body;
    userId = req.userInfo.user_id;


    await connection.beginTransaction();

    stmt = await connection.prepare('SELECT * FROM `' + cons.ENTITY_DETAILS + '` WHERE 1');


    let [result] = await stmt.execute([userId]);
    if (!result || result.length === 0) {
      throw new Error("Applications Not Found");
    }

    // return result;
    const enrichedApps = await Promise.all(
      result.map(async (app) => {
        const entityDetails = await getEntityDetailsByUserId(req, res, connection, app.appId); // <-- await here!
        const proposedInstDetails = await getProposedInstDetailsByUserId(req, res, connection, app.appId);
        return { ...app, ...entityDetails, proposedInstDetails, };
      })
    );



    //  const db = await initDB();
    // let result = await db.getAllFromIndex(cons.ENTITY_DETAILS, "userId", userId);

    // const enrichedApps = await Promise.all(
    //   result.map(async (app) => {
    //     const entityDetails = await getEntityDetailsByUserId(app.appId); // <-- await here!
    //     const proposedInstDetails = await getProposedInstDetailsByUserId(
    //       app.appId
    //     );
    //     return {
    //       ...app,
    //       entityDetails,
    //       proposedInstDetails,
    //     };
    //   })
    // );
    // return enrichedApps; // Now includes full entity details, not Promises



    // Commit the transaction
    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return enrichedApps;


};

export const getDbEntityDetails = async (req, res) => {
  let finalResult, userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;

    const found1 = await EntEntityDetails.findOne({ where: { appId: appId } });
    const found2 = await EntityAddress.findOne({ where: { appId: appId } });
    const found3 = await EntOtherITI.findAll({ where: { appId: appId } });

    const obj1 = {
      aff_category: found1.aff_category,
      aff_sub_category: found1.aff_sub_category,
      category: found1.category,
      name_of_applicant_entity: found1.name_of_applicant_entity,
      ApplicantEntityEmailId: found1.ApplicantEntityEmailId,
      isApplicantEntityEmailIdVerified: found1.isApplicantEntityEmailIdVerified,
      ApplicantContactNumber: found1.ApplicantContactNumber,
      isApplicantEntityMobileNumberVerified: true,
      Is_the_applicant_running_any_other_iti: found1.Is_the_applicant_running_any_other_iti
    }
    const obj2 = {
      ApplicantEntityState: found2.state_code,
      ApplicantEntityDistrict: found2.district_code,
      ApplicantEntitySubDistrict: found2.sub_district_code,
      ApplicantEntityVillage: found2.village_code,
      ApplicantEntityPincode: found2.pincode,
      ApplicantEntityPlotNumber_KhasaraNumber_GataNumber: found2.plotNumber_khasaraNumber_gataNumber,
      ApplicantEntityLandmark: found2.landmark
    }
    const arrayList = found3.map((item) => {
      return {
        run_AffiliationNo: '',
        run_ITIName: item.run_ITIName,
        run_MISCode: item.run_MISCode,
        run_State: item.run_State,
        run_District: item.run_District,
        run_SubDistrict: '',
        run_Village: '',
        run_TownCity: item.run_TownCity,
        run_Pincode: item.run_Pincode,
        run_PlotNumber_KhasaraNumber: item.run_PlotNumber_KhasaraNumber,
        run_Landmark: item.run_Landmark
      };
    });
    // throw arrayList;
    finalResult = { ...st1form.initialValues, ...obj1, ...obj2, runningITIs: arrayList.length > 0 ? arrayList : [st1form.runningITI_Obj], };
    // throw found1;
    // throw found2;
    // throw found3;
  } catch (err) {
    throw err;
  } finally {
    // if (connection) await connection.end();
  }
  return finalResult;

};

export const getEntityDetailsByUserId = async (req, res, connection, appId) => {

  let stmt, results, update, formattedDate, jsonData, userId, submitDate, updateDate;
  let l1, l2, l3;
  try {

    userId = req.userInfo.user_id;

    // const pool = mysql.createPool(masterConfig);
    // connection = await pool.getConnection();

    // await connection.beginTransaction();

    let sel_entity_details = await connection.prepare('SELECT * FROM `' + cons.ENTITY_DETAILS + '` WHERE appId = ?');
    let sel_entity_address = await connection.prepare('SELECT * FROM `' + cons.ENTITY_ADDRESS + '` WHERE appId = ?');
    let sel_other_iti = await connection.prepare('SELECT * FROM `' + cons.OTHER_ITI + '` WHERE appId = ?');


    let rows;
    rows = await sel_entity_details.execute([appId]);

    l1 = rows[0];

    rows = await sel_entity_address.execute([appId]);
    l2 = rows[0];


    rows = await sel_other_iti.execute([appId]);
    l3 = rows[0];

    // Commit the transaction
    // await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    // if (connection) {
    //   await connection.rollback();
    // }
    throw err;
  } finally {
    // if (connection) await connection.end();
  }
  return { entity_details: l1[0] || {}, entity_address: l2, other_iti: l3, };

};

export const getProposedInstDetailsByUserId = async (req, res, connection, appId) => {
  let l1, l2;
  try {
    let stmt, results, update, formattedDate, jsonData, userId, submitDate, updateDate;
    userId = req.userInfo.user_id;
    // const pool = mysql.createPool(masterConfig);
    // connection = await pool.getConnection();
    // await connection.beginTransaction();
    let proposed_insti_details = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_DETAILS + '` WHERE appId = ?');
    let proposed_insti_addresses = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_ADDRESSES + '` WHERE appId = ?');

    let rows;
    rows = await proposed_insti_details.execute([appId]);
    l1 = rows[0];

    rows = await proposed_insti_addresses.execute([appId]);
    l2 = rows[0];
    // Commit the transaction
    // await connection.commit();
    // connection.release();

  } catch (err) {
    console.error("Error in checkUser:", err);
    // if (connection) {
    //   await connection.rollback();
    // }
    throw err;
  } finally {
    // if (connection) await connection.end();
  }

  return { pro_insti_details: l1[0] || {}, pro_insti_address: l2, };


  // const db = await initDB();
  // let l1 = await db.getAllFromIndex(PROPOSED_INSTI_DETAILS, "appId", appId);
  // let l2 = await db.getAllFromIndex(PROPOSED_INSTI_ADDRESSES, "appId", appId);
  // return {
  //   pro_insti_details: l1[0] || {},
  //   pro_insti_address: l2,
  // };
};


// export const setProposedInstDetails = async (req, res) => {
//   let connection, stmt, results, update, formattedDate, jsonData, userId, stepInfo;
//   const t = await sequelize.transaction();
//   try {

//     // connection = await mysql.createConnection(affDbConfig);

//     const { step, data, appId } = req.body;
//     userId = req.userInfo.user_id;

//     jsonData = JSON.parse(data);
//     stepInfo = JSON.parse(step);


//     const found5 = await PIA_Details.findOne({ where: { appId: appId }, transaction: t });
//     const toSave = {
//       state_code: jsonData.cmp_post_state,
//       district_code: jsonData.cmp_post_district,
//       sub_district_code: jsonData.cmp_post_sub_district,
//       village_code: jsonData.cmp_post_village,
//       pincode: jsonData.cmp_post_pincode,
//       plotNumber_khasaraNumber: jsonData.cmp_post_plot_number_khasara_number,
//       landmark: jsonData.cmp_post_landmark,
//       appId: appId,
//       userId: userId
//     };
//     if (found5) {
//       await PIA_Details.update(toSave, { where: { appId }, transaction: t }); // 👈 here
//       console.log("✅ Updated existing record");
//     } else {
//       await PIA_Details.create(toSave);
//       console.log("✅ Inserted new record");
//     }


//     const found6 = await PIDetails.findOne({ where: { appId: appId }, transaction: t });
//     const toSave2 = {
//       name_of_applicant_institute: jsonData.name_of_applicant_institute,
//       type_of_institute: jsonData.type_of_institute,
//       institute_location: jsonData.institute_location,
//       is_falls_under_hill_area_hill: jsonData.is_falls_under_hill_area_hill,
//       Falls_Under_Hill_Area_Hill__Supporting_Doc: req.files.Falls_Under_Hill_Area_Hill__Supporting_Doc[0].filename,
//       is_falls_under_border_district: jsonData.is_falls_under_border_district,
//       Falls_Under_Border_District__Supporting_Doc: req.files.Falls_Under_Border_District__Supporting_Doc[0].filename,
//       under_msti_category: jsonData.under_msti_category,
//       Whether_the_institute_is_exclusive_for_women_trainees: jsonData.Whether_the_institute_is_exclusive_for_women_trainees,
//       latitude: jsonData.latitude,
//       Longitude: jsonData.Longitude,
//       appId: appId,
//       userId: userId
//     };

//     if (found6) {
//       await PIDetails.update(toSave2, { where: { appId }, transaction: t }); // 👈 here
//       console.log("✅ Updated existing record");
//     } else {
//       await PIDetails.create(toSave2);
//       console.log("✅ Inserted new record");
//     }


//     // Settign Up Stage I Form Flow
//     let toSave3 = { status: cons.SL.FILLED };
//     const [updatedRows] = await FormFlowStageI.update(toSave3,
//       {
//         where: { appId, step: cons.ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step }, transaction: t
//       }
//     );

//     // if (updatedRows === 0) {
//     //   throw new Error("Step Not Found, for Updating " + cons.ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step);
//     // }

//     let toSave4 = { stepStatus: cons.SL.ACTIVE };
//     const [updatedRows2] = await FormFlowStageI.update(toSave4,
//       {
//         where: {
//           appId: appId,
//           step: cons.ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step
//         }, transaction: t
//       }
//     );
//     // if (updatedRows2 === 0) {
//     //   throw new Error("Step Not Found, for Updating " + cons.ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step);
//     // }

//     await t.commit();
//     console.log("Multiple records inserted within transaction ✅");
//   } catch (err) {
//     await t.rollback();
//     throw err;
//   } finally {
//     // if (connection) await connection.end();
//   }
//   return { msg: "Information Successfully" };
// };
export const setProposedInstDetails = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { step, data, appId } = req.body;
    const userId = req.userInfo.user_id;

    const jsonData = JSON.parse(data);
    const stepInfo = JSON.parse(step);

    // ----------- PIA_Details -----------
    const found5 = await PIA_Details.findOne({ where: { appId }, transaction: t });

    const toSave = {
      state_code: jsonData.cmp_post_state,
      district_code: jsonData.cmp_post_district,
      sub_district_code: jsonData.cmp_post_sub_district,
      village_code: jsonData.cmp_post_village,
      pincode: jsonData.cmp_post_pincode,
      plotNumber_khasaraNumber: jsonData.cmp_post_plot_number_khasara_number,
      landmark: jsonData.cmp_post_landmark,
      appId,
      userId,
    };

    if (found5) {
      await PIA_Details.update(toSave, { where: { appId }, transaction: t });
      console.log("✅ Updated existing PIA_Details record");
    } else {
      await PIA_Details.create(toSave, { transaction: t });
      console.log("✅ Inserted new PIA_Details record");
    }

    // ----------- PIDetails -----------
    const found6 = await PIDetails.findOne({ where: { appId }, transaction: t });

    const toSave2 = {
      name_of_applicant_institute: jsonData.name_of_applicant_institute,
      type_of_institute: jsonData.type_of_institute,
      institute_location: jsonData.institute_location,
      is_falls_under_hill_area_hill: jsonData.is_falls_under_hill_area_hill,
      Falls_Under_Hill_Area_Hill__Supporting_Doc:
        req?.files?.Falls_Under_Hill_Area_Hill__Supporting_Doc?.[0]?.filename || null,
      is_falls_under_border_district: jsonData.is_falls_under_border_district,
      Falls_Under_Border_District__Supporting_Doc:
        req?.files?.Falls_Under_Border_District__Supporting_Doc?.[0]?.filename || null,
      under_msti_category: jsonData.under_msti_category,
      Whether_the_institute_is_exclusive_for_women_trainees:
        jsonData.Whether_the_institute_is_exclusive_for_women_trainees,
      latitude: jsonData.latitude,
      Longitude: jsonData.Longitude,
      appId,
      userId,
    };

    if (found6) {
      await PIDetails.update(toSave2, { where: { appId }, transaction: t });
      console.log("✅ Updated existing PIDetails record");
    } else {
      await PIDetails.create(toSave2, { transaction: t });
      console.log("✅ Inserted new PIDetails record");
    }

    // ----------- FormFlowStageI -----------
    const toSave3 = { status: cons.SL.FILLED };
    const [updatedRows] = await FormFlowStageI.update(toSave3, {
      where: { appId, step: cons.ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step },
      transaction: t,
    });
    console.log("Stage I update affected rows:", updatedRows);

    const toSave4 = { stepStatus: cons.SL.ACTIVE };
    const [updatedRows2] = await FormFlowStageI.update(toSave4, {
      where: { appId, step: cons.ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step },
      transaction: t,
    });
    console.log("Trade Unit step update affected rows:", updatedRows2);

    // ----------- Commit -----------
    await t.commit();
    console.log("Multiple records inserted/updated within transaction ✅");

  } catch (err) {
    await t.rollback();
    console.error("❌ Transaction rolled back due to error:", err);
    return res.status(500).json({ error: "Something went wrong", details: err.message });
  }
  return { msg: "Information saved successfully" };
};

export const setInstTradeDetails = async (req, res) => {
  let jsonData, userId, stepInfo;
  const t = await sequelize.transaction();

  try {
    const { step, data, appId } = req.body;
    userId = req.userInfo.user_id;
    jsonData = JSON.parse(data);
    stepInfo = JSON.parse(step);

    let preparedArray = jsonData.trades.map((item) => {
      const { trade, units_in_shift_1, units_in_shift_2, units_in_shift_3 } = item
      return { tradeId: trade, unit_in_shift1: units_in_shift_1, unit_in_shift2: units_in_shift_2, unit_in_shift3: units_in_shift_3, appId: appId };
    });

    // Remove if Exist
    await TradesNewInstTrades.destroy({ where: { appId }, transaction: t, });

    // Insert New 
    await TradesNewInstTrades.bulkCreate(preparedArray, { transaction: t });


    // Update Flow Status
    await FormFlowStageI.update({ status: cons.SL.FILLED }, {
      where: { appId, step: cons.ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step },
      transaction: t,
    });

    await FormFlowStageI.update({ stepStatus: cons.SL.ACTIVE }, {
      where: { appId, step: cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step },
      transaction: t,
    });

    await t.commit();

  } catch (err) {
    await t.rollback();
    throw err;
  }
  return { msg: "Information Successfully" };
};

export const setInstLandDetails = async (req, res) => {
  let connection, stmt, results, update, formattedDate, jsonData, userId, stepInfo;
  const t = await sequelize.transaction();
  try {
    const { step, data, appId } = req.body;
    userId = req.userInfo.user_id;

    jsonData = JSON.parse(data);
    stepInfo = JSON.parse(step);


    // throw jsonData.possession_of_land;

    switch (jsonData.possession_of_land) {
      case 'owned':
        const toSave2 = {
          land_owner_name: jsonData.land_owner_name,
          land_registration_number: jsonData.land_registration_number,
          appId: appId,
          userId: userId
        }
        const found6 = await LandOwnedLand.findOne({
          where: { appId: appId },
          transaction: t,
        });
        if (found6) {
          await LandOwnedLand.update(toSave2, {
            where: { appId },
            transaction: t,
          });
        } else {
          await LandOwnedLand.create(toSave2);
        }
        // Save
        const toSave3 = {
          possession_of_land: jsonData.possession_of_land,
          land_area_in_square_metres: jsonData.land_area_in_square_metres,
          appId: appId,
          userId: userId
        }
        const found7 = await LandInstDetail.findOne({
          where: { appId: appId },
          transaction: t,
        });
        if (found7) {
          await LandInstDetail.update(toSave3, {
            where: { appId },
            transaction: t,
          });
        } else {
          await LandInstDetail.create(toSave3);
        }
        break;
      case 'leased':


        const found1 = await LandInstDetail.findOne({
          where: { appId: appId },
          transaction: t,
        });
        // throw found1;
        const toSave4 = {
          possession_of_land: jsonData.possession_of_land,
          land_area_in_square_metres: jsonData.land_area_in_square_metres,
          appId: appId,
          userId: userId
        }
        if (found1) {

          await LandInstDetail.update(toSave4, {
            where: { appId },
            transaction: t,
          });
        } else {
          await LandInstDetail.create(toSave4);
        }

        const toSave6 = {
          name_of_lessor: jsonData.name_of_lessor,
          name_of_lessee: jsonData.name_of_lessee,
          lease_deed_number: jsonData.lease_deed_number,
          date_of_commencement: jsonData.date_of_commencement,
          date_of_expiry: jsonData.date_of_expiry,
          appId: appId,
          userId: userId
        }
        const found8 = await LandLeasedLand.findOne({
          where: { appId: appId },
          transaction: t,
        });
        if (found8) {
          await LandLeasedLand.update(toSave6, {
            where: { appId },
            transaction: t,
          }); // 👈 here
        } else {
          await LandLeasedLand.create(toSave6);
        }
        break;
      default:
        throw new Error("Error In Possession of Land Type");
        break;
    }

    // ----------- FormFlowStageI -----------
    const toSave3 = { status: cons.SL.FILLED };
    const [updatedRows] = await FormFlowStageI.update(toSave3, {
      where: { appId, step: cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step },
      transaction: t,
    });
    console.log("Stage I update affected rows:", updatedRows);

    const toSave4 = { stepStatus: cons.SL.ACTIVE };
    const [updatedRows2] = await FormFlowStageI.update(toSave4, {
      where: { appId, step: cons.ST1FC.FEE_PAYMENT.step },
      transaction: t,
    });
    console.log("Trade Unit step update affected rows:", updatedRows2);

    // ----------- Commit -----------
    await t.commit();
    console.log("Multiple records inserted/updated within transaction ✅");

  } catch (err) {
    await t.rollback();
    throw err;
  }
  return { msg: "Information Successfully" };
};

export const getInstLandDetails = async (req, res) => {
  let finalResult, userId;
  try {

    const { appId } = req.body;
    userId = req.userInfo.user_id;

    const found1 = await LandOwnedLand.findOne({
      where: { appId: appId }
    });
    const found2 = await LandInstDetail.findOne({
      where: { appId: appId },
    });
    const found3 = await LandLeasedLand.findOne({
      where: { appId: appId },
    });







    finalResult = {
      ...landDetail.initialValues,
      "possession_of_land": found2?.possession_of_land || '',
      "land_area_in_square_metres": found2?.land_area_in_square_metres || '',
      "land_owner_name": found1?.land_owner_name || '',
      "land_registration_number": found1?.land_registration_number || '',
      "name_of_lessor": found3?.name_of_lessor || '',
      "name_of_lessee": found3?.name_of_lessee || '',
      "lease_deed_number": found3?.lease_deed_number || '',
      "date_of_commencement": found3?.date_of_commencement || '',
      "date_of_expiry": found3?.date_of_expiry || ''
    };
    // throw finalResult;
    // throw found1;
    // throw found2;
    // throw found3;
  } catch (err) {
    throw err;
  }

  return finalResult;

};




export const getProposedInstDetailsForAutoFill = async (req, res) => {
  let finalResult, userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;

    const found5 = await PIA_Details.findOne({ where: { appId } });
    const found6 = await PIDetails.findOne({ where: { appId } });
    const {
      name_of_applicant_institute,
      type_of_institute,
      institute_location,
      is_falls_under_hill_area_hill,
      Falls_Under_Hill_Area_Hill__Supporting_Doc,
      is_falls_under_border_district,
      Falls_Under_Border_District__Supporting_Doc,
      under_msti_category,
      Whether_the_institute_is_exclusive_for_women_trainees,
      latitude,
      Longitude, } = found6 || {};


    const { state_code,
      district_code,
      sub_district_code,
      village_code,
      pincode,
      plotNumber_khasaraNumber,
      landmark } = found5 || {};


    finalResult = {
      name_of_applicant_institute: name_of_applicant_institute,
      type_of_institute: type_of_institute,
      cmp_post_state: state_code,
      cmp_post_district: district_code,
      cmp_post_sub_district: sub_district_code,
      comp_town_city: '',
      cmp_post_village: village_code,
      cmp_post_pincode: pincode,
      cmp_post_plot_number_khasara_number: plotNumber_khasaraNumber,
      cmp_post_landmark: landmark,
      institute_location: institute_location,
      is_falls_under_hill_area_hill: is_falls_under_hill_area_hill,
      Falls_Under_Hill_Area_Hill__Supporting_Doc: Falls_Under_Hill_Area_Hill__Supporting_Doc,
      is_falls_under_border_district: is_falls_under_border_district,
      Falls_Under_Border_District__Supporting_Doc: Falls_Under_Border_District__Supporting_Doc,
      under_msti_category: under_msti_category,
      Whether_the_institute_is_exclusive_for_women_trainees: Whether_the_institute_is_exclusive_for_women_trainees,
      latitude: latitude,
      Longitude: Longitude
    }
    // throw pid.intiValues;
    // throw found6;
    // throw found5;
    // throw appId;
  } catch (err) {
    throw err;
  }
  return finalResult;
};

// export const getProposedInstDetailsForAutoFill = async (req, res) => {

//   let connection, stmt, results, update, jsonData, userId, submitDate, updateDate;
//   // const pool = mysql.createPool(masterConfig);
//   // connection = await pool.getConnection();
//   let l1, l2;
//   try {

//     connection = await mysql.createConnection(affDbConfig);

//     const { appId } = req.body;
//     userId = req.userInfo.user_id;



//     await connection.beginTransaction();

//     let sel_proposed_insti_details = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_DETAILS + '` WHERE appId = ?');
//     let sel_proposed_insti_addresses = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_ADDRESSES + '` WHERE appId = ?');

//     let rows;
//     rows = await sel_proposed_insti_details.execute([appId]);
//     l1 = rows[0];
//     rows = await sel_proposed_insti_addresses.execute([appId]);
//     l2 = rows[0];

//     // Commit the transaction
//     await connection.commit();
//     // connection.release();

//   } catch (err) {
//     console.error("Error in checkUser:", err);
//     if (connection) {
//       await connection.rollback();
//     }
//     throw err;
//   } finally {
//     if (connection) await connection.end();
//   }
//   return { pro_insti_details: l1[0] || {}, pro_insti_address: l2, };

// };
export const getProposedInstDetailByAppId = async (appId, connection) => {
  let l1, l2;
  try {
    // Session User
    // userId = req.userInfo.user_id;

    // Create Connection
    // const pool = mysql.createPool(masterConfig);
    // connection = await pool.getConnection();

    connection = await mysql.createConnection(affDbConfig);


    await connection.beginTransaction();

    let sel_proposed_insti_details = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_DETAILS + '` WHERE appId = ?');
    let sel_proposed_insti_addresses = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_ADDRESSES + '` WHERE appId = ?');

    let rows;
    rows = await sel_proposed_insti_details.execute([appId]);
    l1 = rows[0];

    rows = await sel_proposed_insti_addresses.execute([appId]);
    l2 = rows[0];


    // Commit the transaction
    await connection.commit();
    // connection.release();

  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return { pro_insti_details: l1[0] || {}, pro_insti_address: l2, };

};

export const getStage1FormFlow = async (req, res) => {
  let connection, userId, finalList;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {

    connection = await mysql.createConnection(affDbConfig);


    const { appId } = req.body;
    userId = req.userInfo.user_id;



    await connection.beginTransaction();

    let sel_app_form_flow_stage_i = await connection.prepare('SELECT * FROM `' + cons.APP_FORM_FLOW_STAGE_I + '` WHERE appId = ?');
    let [flow] = await sel_app_form_flow_stage_i.execute([appId]);

    finalList = await Promise.all(flow.map(async (item) => {
      switch (item.step) {
        case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
          // check possession_of_land
          console.log(item.step);
          return item;
        default:
          return item;
      }
    }));


    // Commit the transaction
    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return finalList;



  // const db = await initDB();
  // try {
  //   const tx = db.transaction([cons.APP_FORM_FLOW_STAGE_I], 'readwrite');
  //   const list = tx.objectStore(cons.APP_FORM_FLOW_STAGE_I);
  //   const flow = await list.index('appId').getAll(appId);
  //   console.log(flow);
  //   flow.sort((a, b) => a.stepNo - b.stepNo);
  //   const finalList = await Promise.all(flow.map(async (item) => {
  //     switch (item.step) {
  //       case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
  //         // check possession_of_land
  //         console.log(item.step);
  //         return item;
  //       default:
  //         return item;
  //     }
  //   }));
  //   console.log(finalList);
  //   await tx.done;
  //   return finalList;
  // } catch (error) {
  //   return []
  // }
};


export const markascomleted_app_form_flow_stage_i = async (connection, appId, stepInfo) => {
  let stmt1 = await connection.prepare('SELECT * FROM `' + cons.APP_FORM_FLOW_STAGE_I + '` WHERE appId = ? and step=?');
  let [result2] = await stmt1.execute([appId, stepInfo.step]);
  if (result2.length > 0) {
    let stmt1 = await connection.prepare('UPDATE `' + cons.APP_FORM_FLOW_STAGE_I + '` SET stepStatus=?, status=?, updateDate=? WHERE appId=? and step=?;');
    await stmt1.execute([cons.ACTIVE, cons.FILLED, updateDate, appId, stepInfo.step]);
  }
  else {
    throw new Error("Form FLow Step Information Not Found");
  }
}

export const markasactive_app_form_flow_stage_i = async (connection, appId, step) => {
  let sel_proposed_insti_details = await connection.prepare('SELECT * FROM `' + cons.APP_FORM_FLOW_STAGE_I + '` WHERE appId = ? and step=?');
  let [result2] = await sel_proposed_insti_details.execute([appId, step]);
  if (result2.length > 0) {
    let stmt = await connection.prepare('UPDATE `' + cons.APP_FORM_FLOW_STAGE_I + '` SET stepStatus=? WHERE appId=? and step=?;');
    await stmt.execute([cons.ACTIVE, appId, step]);
  }
  else {
    throw new Error("Form FLow Step Information Not Found");
  }
}


export const markAsAtiveAppFlow = async (connection, appId, step) => {
  let sel_proposed_insti_details = await connection.prepare('SELECT * FROM `' + cons.APP_FLOW + '` WHERE appId = ? and step=?');
  let [result2] = await sel_proposed_insti_details.execute([appId, step]);
  if (result2.length > 0) {
    let stmt = await connection.prepare('UPDATE `' + cons.APP_FLOW + '` SET stepStatus=? WHERE appId=? and step=?;');
    await stmt.execute([cons.SL.PENDING, appId, step]);
  }
  else {
    throw new Error("Form FLow Step Information Not Found");
  }
}






export const getFeeInfo = async (req, res) => {
  let connection, userId, finalResult;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();

  try {

    connection = await mysql.createConnection(affDbConfig);


    const { appId } = req.body;
    userId = req.userInfo.user_id;


    await connection.beginTransaction();

    let stmt1 = await connection.prepare('SELECT * FROM `' + cons.APP_FLOW + '` WHERE step=? and appId = ?');
    let [result] = await stmt1.execute([cons.STAGE_I_FEE, appId]);
    if (result.length > 0) {
      finalResult = result[0]
    }
    else {
      throw new Error("Form FLow Step Not Found");
    }

    // Commit the transaction
    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return { stageI: finalResult };



  // const db = await initDB();
  // try {
  //   const tx = db.transaction([cons.APP_FORM_FLOW_STAGE_I], 'readwrite');
  //   const list = tx.objectStore(cons.APP_FORM_FLOW_STAGE_I);
  //   const flow = await list.index('appId').getAll(appId);
  //   console.log(flow);
  //   flow.sort((a, b) => a.stepNo - b.stepNo);
  //   const finalList = await Promise.all(flow.map(async (item) => {
  //     switch (item.step) {
  //       case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
  //         // check possession_of_land
  //         console.log(item.step);
  //         return item;
  //       default:
  //         return item;
  //     }
  //   }));
  //   console.log(finalList);
  //   await tx.done;
  //   return finalList;
  // } catch (error) {
  //   return []
  // }
};


export const setAsExemptedStageI = async (req, res) => {
  let formData, connection, stmt, results, update, formattedDate, jsonData, userId, stepInfo;
  try {

    const t = await sequelize.transaction();

    const { data, step, appId } = req.body;
    userId = req.userInfo.user_id;

    stepInfo = JSON.parse(step);
    formData = JSON.parse(data);


    // CHeck First 
    const appFlow = await AppFlow.findOne({
      where: { appId, step: cons.STAGE_I_FEE },
      transaction: t,
    });

    // console.log(1258, "Fetched:", appFlow ? appFlow.get({ plain: true }) : null);




    await AppFlow.update({ status: cons.STAGE_I__FEE_EXEMPTED, status: "completed" }, {
      where: { appId, step: cons.STAGE_I_FEE, },
      transaction: t,
    });


    await FormFlowStageI.update({ status: cons.SL.FILLED }, {
      where: { appId, step: cons.ST1FC.FEE_PAYMENT.step },
      transaction: t,
    });

    await FormFlowStageI.update({ stepStatus: cons.SL.ACTIVE }, {
      where: { appId, step: cons.ST1FC.DOCUMENTS_UPLOAD.step },
      transaction: t,
    });
    await t.commit();
  } catch (err) {
    await t.rollback();
    console.error("❌ Transaction rolled back due to error:", err);
    return res.status(500).json({ error: "Something went wrong", details: err.message });
  }
  return { msg: "Information saved successfully" };
};

export const setUploadDocumentStageI = async (req, res) => {
  let formData, connection, stmt, results, update, formattedDate, jsonData, userId, stepInfo;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  // Safe access
  const file = req.files.find(f => f.fieldname === "land_conversion_certificate[2].document");
  const t = await sequelize.transaction();

  try {


    // connection = await mysql.createConnection(affDbConfig);


    const { data, step, appId } = req.body;
    userId = req.userInfo.user_id;

    // await connection.beginTransaction();

    stepInfo = JSON.parse(step);
    formData = JSON.parse(data);

    let found = await LandInstDetail.findOne({ where: { appId: appId } });
    switch (found.possession_of_land) {
      case "leased":
        for (const [index, item] of formData.lease_deed_documents.entries()) {

          const lease_deed_document = req.files.find(f => f.fieldname === `lease_deed_documents[${index}].document`);
          if (!lease_deed_document) {
            throw new Error(`File missing for ${item.language} at index ${index}`);
          }
          console.log(1326, item.language, index, lease_deed_document);

          switch (item.language) {
            case "English":
            case "Hindi":
              await Stage1Documents.create({
                uniqueId: cons.randomId(),
                appId: appId,
                language: item.language,
                document: lease_deed_document.filename,
                uploaded_datetime: cons.currentDate,
                file_meta_info: { lease_deed_document }
              }, { transaction: t });
              break;
            default:
              const lease_deed_notarised_document = req.files.find(f => f.fieldname === `lease_deed_documents[${index}].notarised_document`);
              if (!lease_deed_notarised_document) {
                throw new Error(`File missing`);
              }
              await Stage1Documents.create({
                uniqueId: cons.randomId(),
                appId: appId,
                language: item.language,
                document: lease_deed_document.filename,
                notarised_document: lease_deed_notarised_document.filename,
                uploaded_datetime: cons.currentDate,
                file_meta_info: { lease_deed_document, lease_deed_notarised_document }
              }, { transaction: t });
              break;
          }
        }
        break;
      case "owned":
        for (const [index, item] of formData.onwed_land_documents.entries()) {
          const land_document = req.files.find(f => f.fieldname === `onwed_land_documents[${index}].document`);
          if (!land_document) {
            throw new Error(`File missing for ${item.land_documents_language} at index ${index}`);
          }
          switch (item.land_documents_language) {
            case "English":
            case "Hindi":
              await Stage1Documents.create({
                uniqueId: cons.randomId(),
                land_document_type: cons.LAND_DOCUMENT_TYPES.OWNED,
                appId: appId,
                language: item.land_documents_language,
                document: land_document.filename,
                uploaded_datetime: cons.currentDate,
              }, { transaction: t });
              break;
            default:
              const land_document_notarised_document = req.files.find(f => f.fieldname === `land_notarised_documents[${index}].notarised_document`);
              if (!land_document_notarised_document) {
                throw new Error(`File missing`);
              }

              await Stage1Documents.create({
                uniqueId: cons.randomId(),
                land_document_type: cons.LAND_DOCUMENT_TYPES.OWNED,
                appId: appId,
                language: item.land_documents_language,
                document: land_document.filename,
                notarised_document: land_document_notarised_document.filename,
                uploaded_datetime: cons.currentDate,
              }, { transaction: t });
              break;
          }
        }
        break;
      default:
        throw new Error("Error In Possession of Land Type");
    }

    // Saving Land Conversion Certificate
    for (const [index, item] of formData.land_conversion_certificate.entries()) {
      const lcc_documents = req.files.find(f => f.fieldname === `land_conversion_certificate[${index}].document`);
      if (!lcc_documents) {
        throw new Error(`File missing for ${item.language} at index ${index}`);
      }
      switch (item.language) {
        case "English":
        case "Hindi":
          await Stage1Documents.create({
            uniqueId: cons.randomId(),
            land_document_type: cons.LAND_DOCUMENT_TYPES.LAND_CONVERSION_CERTIFICATE,
            appId: appId,
            language: item.language,
            document: lcc_documents.filename,
            uploaded_datetime: cons.currentDate,
          }, { transaction: t });
          break;
        default:
          const lcc_notarised_documents = req.files.find(f => f.fieldname === `land_conversion_certificate[${index}].notarised_document`);
          if (!lcc_notarised_documents) {
            throw new Error(`File missing for`);
          }
          await Stage1Documents.create({
            uniqueId: cons.randomId(),
            land_document_type: cons.LAND_DOCUMENT_TYPES.LAND_CONVERSION_CERTIFICATE,
            appId: appId,
            language: item.language,
            document: lcc_documents.filename,
            notarised_document: lcc_notarised_documents.filename,
            uploaded_datetime: cons.currentDate,
          }, { transaction: t });
          break;
      }
    }


    // Saving AuthorizedSignatoryDetails
    const { name_of_authorized_signatory,
      email_id_of_authorized_signatory,
      is_verified_email_id_of_authorized_signatory,
      mobile_number_of_authorized_signatory,
      is_verified_mobile_number_of_authorized_signatory,
      id_proof_of_authorized_signatory,
      id_proof_number_of_authorized_signatory,
      id_proof_docs_of_authorized_signatory } = formData;

    if (is_verified_email_id_of_authorized_signatory != true) {
      throw new Error("Please Verify Email ID of Authorized Signatory");
    }

    if (is_verified_mobile_number_of_authorized_signatory != true) {
      throw new Error("Please Verify Mobile Number Authorized Signatory");
    }

    const doc_of_authorized_signatory_document = req.files.find(f => f.fieldname === `doc_of_authorized_signatory`);
    if (!doc_of_authorized_signatory_document) {
      throw new Error(`File missing`);
    }

    await InitialAuthorizedSignatoryDetails.create({
      uniqueId: cons.randomId(),
      appId: appId,
      name: name_of_authorized_signatory,
      email_id: email_id_of_authorized_signatory,
      mobile_number: mobile_number_of_authorized_signatory,
      id_proof_type: id_proof_of_authorized_signatory,
      id_proof_number: id_proof_number_of_authorized_signatory,
      document: doc_of_authorized_signatory_document.fieldname,
      uploaded_datetime: cons.currentDate,
    }, { transaction: t });



    // Select Registration Certificate of Applicant Organization
    const doc_of_registration_cert_of_applicant_org = req.files.find(f => f.fieldname === `doc_of_registration_cert_of_applicant_org`);
    if (!doc_of_registration_cert_of_applicant_org) {
      throw new Error(`File missing for ${item.language} at index ${index}`);
    }

    await InitialCertificats.create({
      uniqueId: cons.randomId(),
      appId: appId,
      stage: "STAGE_I",
      keyName: "registration_certificate",
      document: doc_of_registration_cert_of_applicant_org.fieldname,
      upload_datetime: cons.currentDate,
    }, { transaction: t });


    // doc_iti_resolution
    const doc_iti_resolution = req.files.find(f => f.fieldname == `doc_iti_resolution`);
    if (!doc_iti_resolution) {
      throw new Error(`File missing`);
    }
    await InitialCertificats.create({
      uniqueId: cons.randomId(),
      appId: appId,
      stage: "STAGE_I",
      keyName: cons.Certificat.DOC_ITI_RESOLUTION,
      document: doc_iti_resolution.fieldname,
      upload_datetime: cons.currentDate,
    }, { transaction: t });



    // doc_of_authorized_signatory
    const doc_of_authorized_signatory = req.files.find(f => f.fieldname === `doc_of_authorized_signatory`);
    if (!doc_of_authorized_signatory) {
      throw new Error(`File missing`);
    }
    await InitialCertificats.create({
      uniqueId: cons.randomId(),
      appId: appId,
      stage: "STAGE_I",
      keyName: cons.Certificat.DOC_OF_AUTHORIZED_SIGNATORY,
      document: doc_of_authorized_signatory.fieldname,
      upload_datetime: cons.currentDate,
    }, { transaction: t });


    // doc_of_authorized_signatory
    const doc_of_land_earmarking = req.files.find(f => f.fieldname === `doc_of_land_earmarking`);
    if (!doc_of_land_earmarking) {
      throw new Error(`File missing`);
    }
    await InitialCertificats.create({
      uniqueId: cons.randomId(),
      appId: appId,
      stage: "STAGE_I",
      keyName: cons.Certificat.DOC_OF_LAND_EARMARKING,
      document: doc_of_land_earmarking.fieldname,
      upload_datetime: cons.currentDate,
    }, { transaction: t });



    //Saving SecretaryChairpersonPresidentIdInfo
    for (const [index, item] of formData.id_proof_scp.entries()) {
      const document = req.files.find(f => f.fieldname === `id_proof_scp[${index}].document`);
      if (!document) {
        throw new Error(`File missing`);
      }
      const { designation, id_proof_type, id_proof_number, } = item;



      const newInfo = await InitialSecretaryChairpersonPresidentIdInfo.create({
        uniqueId: cons.randomId(),
        appId: appId,
        designation: designation,
        id_proof_type: id_proof_type, // e.g., 1 = Aadhaar, 2 = Passport
        id_proof_number: id_proof_number,
        document: document.fieldname,
        uploaded_datetime: cons.currentDate // maps to MySQL DATETIME
        // timestamp will auto-set
      });

    }



    // Updating Application Flows
    await AppFlow.update({ stepStatus: cons.SL.COMPLETED, status: cons.STAGE_I__DOCUMENT_UPLOADED }, {
      where: { appId, step: cons.STAGE_I_DOCUMENT_UPLAOD },
      transaction: t,
    });

    await AppFlow.update({ stepStatus: cons.SL.COMPLETED, status: cons.STAGE_I__SUBMITED }, {
      where: { appId, step: cons.STAGE_I_SUBMIT },
      transaction: t,
    });

    await AppFlow.update({ stepStatus: 'pending' }, {
      where: { appId, step: cons.STAGE_I__ASSESSMENT },
      transaction: t,
    });


    await FormFlowStageI.update({ status: cons.SL.FILLED }, {
      where: { appId, step: cons.ST1FC.DOCUMENTS_UPLOAD.step },
      transaction: t,
    });

    // throw found;
    t.commit();
  } catch (err) {
    throw err;
  }
  return { msg: "Information Successfully" };
};

export const setSendApplicationStage1ToState = async (req, res) => {
  let connection, userId;
  const t = await sequelize.transaction();
  try {
    const { appId, assessment_id } = req.body;
    userId = req.userInfo.user_id;


    const check1 = await AppAssessmentFlowStageI.findOne({
      where: { assessment_id: assessment_id, appId: appId, recordType: cons.SL.PRESENT, actor: cons.SL.APPLICANT }
    });
    if (!check1) {
      throw "FLow Not Found";
    }



    await AssessmentStatus.update(
      { pendingAt: cons.SL.PENDING_AT_ASSESSOR },
      { where: { appId: appId, assessment_id: assessment_id }, transaction: t }
    );




    // 2. Marks as Completed Review Step fo Assessment Flow 
    AppAssessmentFlowStageI.update(
      { step: cons.ST1FC.REVIEW_ASSESSMENT.step, status: cons.SL.COMPLETED },
      {
        where:
        {
          appId: appId,
          assessment_id: assessment_id,
          step: cons.ST1FC.REVIEW_ASSESSMENT.step,
          actor: cons.SL.APPLICANT,
          recordType: cons.SL.PRESENT
        }, transaction: t
      }
    );
    //End



    // 3. Mark as History Current Assessment
    AppAssessmentFlowStageI.update(
      { recordType: cons.SL.HISTORY },
      { where: { appId: appId, assessment_id: assessment_id, recordType: cons.SL.PRESENT }, transaction: t }
    );
    // End



    // 4. Generate New Flow for Applicnat 
    const flowList = await AppAssessmentFlowStageI.findAll({
      where: { assessment_id: assessment_id, appId: appId, recordType: cons.SL.PRESENT, actor: cons.SL.APPLICANT }
    });

    // throw flowList;
    const mainStepsData = flowList.map((step) => {
      const obj = step.get({ plain: true }); // plain object
      delete obj.completionDate;
      delete obj.DA;
      delete obj.slno;

      let rObj = {
        referenceNumber: step.uniqueID,
        appId: appId,
        assessment_id: assessment_id,
        uniqueID: cons.randomId(),
        actor: cons.SL.ASSESSOR,
        recordType: cons.SL.PRESENT,
        status: cons.SL.PENDING,
        forwarded_by: cons.SL.APPLICANT
      }
      return { ...obj, ...rObj };  // <-- use obj not step
    });

    // throw mainStepsData;

    await AppAssessmentFlowStageI.bulkCreate(mainStepsData, { transaction: t });
    await t.commit();
    // await t.rollback();

  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    console.log('reached to final')
  }
  return { msg: "Information Successfully" };
};





export const setAppFlow = async ({ appId, step, status, connection }) => {
  // Update the app flow status
  // const db = await initDB();
  let smt1 = await connection.prepare('SELECT * FROM `' + cons.APP_FLOW + '` WHERE step=? and appId = ?');
  let up_stm1 = await connection.prepare('UPDATE `' + cons.APP_FLOW + '` SET `status`=?,	`stepStatus`=? WHERE appId=? and step=?;');
  let [smt1_result] = await smt1.execute([step, appId]);

  if (smt1_result.length == 0 || smt1_result.length < 0) {
    throw "App FLow Not Found";
  }

  switch (step) {
    case cons.STAGE_I_FORM_FILLING:
      await up_stm1.execute([cons.STAGE_I__FILLED, status, appId, step]);
      break;
    case cons.STAGE_I_FEE:
      let result1 = await getProposedInstDetailByAppId(appId, connection);
      switch (result1.pro_insti_details.type_of_institute) {
        case "Government":
          await up_stm1.execute([cons.STAGE_I__FEE_EXEMPTED, status, appId, step]);
          break;
        case "Private":
          await up_stm1.execute([cons.STAGE_I__FEE_PAID, status, appId, step]);
      }
      break;
    case cons.STAGE_I_DOCUMENT_UPLAOD:
      await up_stm1.execute([cons.STAGE_I__DOCUMENT_UPLOADED, status, appId, step]);
      break;
    case cons.STAGE_I_SUBMIT:
      await up_stm1.execute([cons.STAGE_I__SUBMITED, status, appId, step]);
      break;
    case cons.STAGE_I__ASSESSMENT:
      await up_stm1.execute([cons.STAGE_I__ASSESSMENT_COMPLETED, status, appId, step]);
      break;
    case cons.NOC_ISSUANCE:
      await up_stm1.execute([cons.NOC_ISSUANCE_ISSUED, status, appId, step]);
      break;
    case cons.STAGE_II_FORM_FILLING:
      await up_stm1.execute([cons.STAGE_II__FILLED, status, appId, step]);
      break;
    case cons.STAGE_II_FEE:
      await up_stm1.execute([cons.STAGE_II__FEE_PAID, status, appId, step]);
      break;
    case cons.STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS:
      await up_stm1.execute([cons.STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_COMPLETED, status, appId, step]);
      break;
    case cons.STAGE_II_DOCUMENT_UPLAOD:
      await up_stm1.execute([cons.STAGE_II__DOCUMENT_UPLOADED, status, appId, step]);
      break;
    case cons.STAGE_II_SUBMIT:
      await up_stm1.execute([cons.STAGE_II__SUBMITED, status, appId, step]);
      break;
    case cons.STAGE_II__ASSESSMENT:
      await up_stm1.execute([cons.STAGE_II__ASSESSMENT_COMPLETED, status, appId, step]);
      break;
    case cons.STAFF_DETAILS:
      await up_stm1.execute([cons.STAFF_DETAILS_COMPLETED, status, appId, step]);
      break;
    case cons.INSP_SLOT_SELECTION:
      await up_stm1.execute([cons.INSP_SLOT_SELECTION_COMPLETED, status, appId, step]);
      break;
    case cons.INSPENCTION:
      throw new Error("To be Continue....");
      break;
    default:
      throw new Error("App FLow Step Does not Match");
      break;
  }
};


export const getInstTradeDetails = async (req, res) => {
  let finalResult, userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;
    const List = await MasterTradeInfo.findAll({
      attributes: ["trade_id", "trade_name", "is_new_age"], // 👈 only these two columns
      where: { /* optionally filter by appId if needed */ }
    }); finalResult = List
  } catch (err) {
    throw err;
  }
  return finalResult;
};