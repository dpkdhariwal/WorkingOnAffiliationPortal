import { Sequelize } from 'sequelize';
import Village from '../models/Village.js';

export const getDistricts = async (req, res) => {
  try {
    const { stateCode } = req.body;
    if (!stateCode) {
      return res.status(400).json({ message: 'stateCode is required' });
    }
    const districts = await Village.findAll({
      where: { stateCode },
      attributes: [
        [Sequelize.fn('DISTINCT', Sequelize.col('districtCode')), 'districtCode'],
        'districtNameEnglish'
      ],
      group: ['districtCode', 'districtNameEnglish'],
      order: [['districtNameEnglish', 'ASC']]
    });
    res.json(districts);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching districts data', error: error.message });
  }
};
