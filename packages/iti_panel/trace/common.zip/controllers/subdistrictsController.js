import { Sequelize } from 'sequelize';
import Village from '../models/Village.js';

export const getSubdistricts = async (req, res) => {
  try {
    const { stateCode, districtCode } = req.body;
    if (!stateCode || !districtCode) {
      return res.status(400).json({ message: 'stateCode and districtCode are required' });
    }
    const subdistricts = await Village.findAll({
      where: { stateCode, districtCode },
      attributes: [
        [Sequelize.fn('DISTINCT', Sequelize.col('subdistrictCode')), 'subdistrictCode'],
        'subdistrictNameEnglish',
        'districtCode',
        'districtNameEnglish',
        'stateCode'
      ],
      group: ['subdistrictCode', 'subdistrictNameEnglish', 'districtCode', 'districtNameEnglish', 'stateCode'],
      order: [['subdistrictNameEnglish', 'ASC']]
    });
    res.json(subdistricts);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching subdistricts data', error: error.message });
  }
};
