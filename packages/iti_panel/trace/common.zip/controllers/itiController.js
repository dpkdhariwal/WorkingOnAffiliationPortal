import ITI from '../models/ITI.js';


export const createITI = async (req, res) => {
  try {
    const { misCode, name, category, address, affiliatedTrades } = req.body;

    // Check if ITI with misCode exists
    const existingITI = await ITI.findOne({ where: { misCode } });
    if (existingITI) {
      return res.status(400).json({ message: 'ITI with this MIS Code already exists' });
    }

    // Create ITI
    const iti = await ITI.create({
      misCode,
      name,
      category,
      address,
      affiliatedTrades: Array.isArray(affiliatedTrades) ? affiliatedTrades : [],
    });

    res.status(201).json({ message: 'ITI created successfully', iti });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

export const searchITIByMisCode = async (req, res) => {
  try {
    const { misCode } = req.params;

    if (!misCode) {
      return res.status(400).json({ message: 'MIS Code is required' });
    }

    const iti = await ITI.findOne({ where: { misCode } });

    if (!iti) {
      return res.status(404).json({ message: 'ITI not found with the given MIS Code' });
    }

    res.json({ iti });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};
