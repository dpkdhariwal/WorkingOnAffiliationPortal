import Village from '../models/Village.js';

export const getVillages = async (req, res) => {
  try {
    const { stateCode, districtCode, subdistrictCode } = req.body;
    if (!stateCode || !districtCode || !subdistrictCode) {
      return res.status(400).json({ message: 'stateCode, districtCode, and subdistrictCode are required' });
    }
    const villages = await Village.findAll({
      where: { stateCode, districtCode, subdistrictCode },
      attributes: ['villageCode','villageNameEnglish', 'pincode'],
      order: [['villageNameEnglish', 'ASC']]
    });
    res.json(villages);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching villages data', error: error.message });
  }
};
