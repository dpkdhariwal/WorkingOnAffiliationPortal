// Route for user login
import express from "express";
const router = express.Router();
import { pKeyPath } from "../common/common.js";
import fs from "fs";
import jwt from "jsonwebtoken";
const privateKey = fs.readFileSync(pKeyPath, "utf8");
router.use(express.json());

import * as apli from "../database/models/applicant.js";
import * as gen from "../database/models/general.js";

import { checkUser } from "../database/models/auth.js";
import { authenticateToken } from "../database/models/token.js";

import { applicantToken } from '../Middleware/auth.js';
import multer from "multer";
const upload = multer(); // no file saving, just parse fields



// Application Stage I Form Submission
router.post("/getAppFlowStepInfoByStep", upload.none(), async (req, res) => {
  try {
    const result = await gen.getAppFlowStepInfoByStep(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});

// Application Stage I Form Submission
router.post("/setNewStatusOfAppByStep", upload.none(), async (req, res) => {
  try {
    const result = await gen.setNewStatusOfAppByStep(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});

// Application Stage I Form Submission
router.post("/getAssessmentStatus", upload.none(), async (req, res) => {
  try {
    const result = await gen.getAssessmentStatus(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

router.post("/getAppStatus", upload.none(), async (req, res) => {
  try {
    const result = await gen.getAppStatus(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


// Application Stage I Form Submission
router.post("/getDetails", upload.none(), async (req, res) => {
  try {
    const result = await gen.getDetails(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

// Application Stage I Form Submission
router.post("/getEntityDetails", upload.none(), async (req, res) => {
  try {
    const result = await gen.getEntityDetails(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

// Application Stage I Form Submission
router.post("/getProposedInstDetails", upload.none(), async (req, res) => {
  try {
    const result = await gen.getProposedInstDetails(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


// Application Stage I Form Submission
router.post("/getAppFlowByAppId", upload.none(), async (req, res) => {
  try {
    const result = await gen.getAppFlowByAppId(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


// getTradeUnitsInfo
router.post("/getTradeUnitsInfo", upload.none(), async (req, res) => {
  try {
    const result = await gen.getTradeUnitsInfo(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

router.post("/geLanguages", upload.none(), async (req, res) => {
  try {
    const result = await gen.geLanguages(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


router.post("/getMasters", upload.none(), async (req, res) => {
  try {
    const result = await gen.getMasters(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

router.post("/getApplicationInfo", upload.none(), async (req, res) => {
  try {
    const result = await gen.getApplicationInfo(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});





export default router;
