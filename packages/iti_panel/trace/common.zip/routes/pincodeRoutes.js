import express from 'express';
import { getPincode } from '../controllers/pincodeController.js';

const router = express.Router();

router.post('/v1', getPincode);

export default router;
