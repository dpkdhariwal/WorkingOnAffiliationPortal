import express from 'express';
import { getStates } from '../controllers/statesController.js';

const router = express.Router();

router.post('/v1', getStates);

export default router;
