// Route for user login
import express from "express";
const router = express.Router();
import { pKeyPath } from "../common/common.js";
import fs from "fs";
import jwt from "jsonwebtoken";
const privateKey = fs.readFileSync(pKeyPath, "utf8");
router.use(express.json());

import * as apli from "../database/models/applicant.js";
import * as gen from "../database/models/general.js";
import * as stateModel from "../database/models/stateModel.js"
import { checkUser } from "../database/models/auth.js";
import { authenticateToken } from "../database/models/token.js";

import { applicantToken } from '../Middleware/auth.js';
import multer from "multer";
const upload = multer(); // no file saving, just parse fields
import * as cons from "../constant/constants.js";
import { upload2 } from "../services/multer/configs.js";

// Application Stage I Form Submission
router.post("/getAppListByStateUser", upload.none(), async (req, res) => {
  try {
    const result = await apli.getAppListByStateUser(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


// Application Stage I Form Submission
router.post("/setNewStatusOfAppByStep", upload.none(), async (req, res) => {
  try {
    const result = await gen.setNewStatusOfAppByStep(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


// Application Stage I Form Submission
router.post("/setStageIAssessmentFlow", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.setStageIAssessmentFlow(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

router.post("/setStageIIAssessmentFlow", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.setStageIIAssessmentFlow(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


router.post("/getBasicDetail_asmt", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.getBasicDetail_asmt(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


router.post("/getCivilInfrastructure_asmt", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.getCivilInfrastructure_asmt(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

router.post("/getAmenitiesArea_asmt", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.getAmenitiesArea_asmt(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});
router.post("/getSignageBoards_asmt", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.getSignageBoards_asmt(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});
router.post("/getElectricityDetails_asmt", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.getElectricityDetails_asmt(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});



router.post("/getAsmtFlowForStageII", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.getAsmtFlowForStageII(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


// Application Stage I Form Submission
router.post("/getAssessmentStageIFlowById", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.getAssessmentStageIFlowById(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

router.post("/getAssessmentStageIIFlowById", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.getAssessmentStageIIFlowById(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


// Application Stage I Form Submission
router.post("/get_da_status_possasion_of_land", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.get_da_status_possasion_of_land(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});



// Application Stage I Form Submission
router.post("/markAsCompleteStageAssessmentFlow", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.markAsCompleteStageAssessmentFlow(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


// get_da_status_possasion_of_land
router.post("/get_da_status_possasion_of_land", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.get_da_status_possasion_of_land(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

// get_da_status_possasion_of_land
router.post("/get_vrf_list_land_to_be_used", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.get_vrf_list_land_to_be_used(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});




router.post("/save_da_doc_verification_remarks", upload2.any(), async (req, res) => {
  try {
    let result;
    const userType = cons.getUserTypeByString(req.userInfo.userType);

    switch (userType) {
      case 'ASSESSOR':
        result = await stateModel.save_da_doc_verification_remarks(req, res);  // waits for promise to resolve
        break;
      case 'applicant':
        // throw userType;
        result = await stateModel.save_reply_da_doc_verification_remarks(req, res);  // waits for promise to resolve
        break;
      default:
        throw "Invalid User";
        break;
    }
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});






// get_da_status_possasion_of_land
router.post("/getAssessmentProgressStatus", upload.none(), async (req, res) => {
  try {
    const userType = cons.getUserTypeByString(req.userInfo.userType);
    // throw userType;
    switch (userType) {
      case 'ASSESSOR':
        {
          const result = await stateModel.getAssessmentProgressStatus(req, res);
          res.status(200).json(result);       // success response
        }
        break;
      default:
        throw "Invalid User";
        break;
    }
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

router.post("/getAssessmentProgressStatusApplicant", upload.none(), async (req, res) => {
  try {
    const userType = cons.getUserTypeByString(req.userInfo.userType);
    // throw userType;
    switch (userType) {
      case 'applicant':
        {
          const result = await stateModel.getAssessmentProgressStatusApplicant(req, res);
          res.status(200).json(result);       // success response
        }
        break;
      default:
        throw "Invalid User";
        break;
    }
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

// set_da_status_possasion_of_land
router.post("/set_da_status_possasion_of_land", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.set_da_status_possasion_of_land(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

// get_da_status_land_area
router.post("/get_da_status_land_area", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.get_da_status_land_area(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


// get_da_status
router.post("/get_da_status", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.get_da_status(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


// set_da_status
router.post("/set_da_status", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.set_da_status(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


// updateAssessmentStatus
router.post("/updateAssessmentStatus", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.updateAssessmentStatus(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


router.post("/markAsCompleteAssessment", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.markAsCompleteAssessment(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


router.post("/generateNoc", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.generateNoc(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


router.post("/setSendApplicationToApplicant", upload.none(), async (req, res) => {
  try {
    const result = await stateModel.setSendApplicationToApplicant(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

















export default router;
