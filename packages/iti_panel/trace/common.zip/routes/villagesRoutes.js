import express from 'express';
import { getVillages } from '../controllers/villagesController.js';

const router = express.Router();

router.post('/v1', getVillages);

export default router;
