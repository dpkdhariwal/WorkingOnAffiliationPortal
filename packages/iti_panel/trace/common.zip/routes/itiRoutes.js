import express from 'express';
import { searchITIByMisCode } from '../controllers/itiController.js';

const router = express.Router();

router.get('/:misCode', searchITIByMisCode);

export default router;
