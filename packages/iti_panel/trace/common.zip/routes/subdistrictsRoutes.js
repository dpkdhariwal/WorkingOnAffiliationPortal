import express from 'express';
import { getSubdistricts } from '../controllers/subdistrictsController.js';

const router = express.Router();

router.post('/v1', getSubdistricts);

export default router;
