// Route for user login
import express from "express";
const router = express.Router();
import { pKeyPath } from "../common/common.js";
import fs from "fs";
import jwt from "jsonwebtoken";
const privateKey = fs.readFileSync(pKeyPath, "utf8");
router.use(express.json());
import multer from "multer";
const upload = multer(); // no file saving, just parse fields

import { checkUser } from "../database/models/auth.js";
import { authenticateToken } from "../database/models/token.js";
import User from "../database/Sequelize/User.js";
import UserProfile from "../database/Sequelize/UserProfile.js";
import { sequelize } from "../config/database.js";

// router.post("/login", async (req, res) => {
//   try {
//     const data = await checkUser(req, res);  // waits for promise to resolve
//     console.log(data);
//     res.status(200).json(data);         // success response
//   } catch (error) {
//     res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
//   }
// });


// router.post("/login", (req, res) => {
//   const refreshToken = jwt.sign({ userId: 123 }, "refreshSecret", { expiresIn: "7d" });

//   res.cookie("refreshToken", refreshToken, {
//     httpOnly: true,       // ✅ cannot be accessed by JS
//     secure: false,        // ✅ set true only in production with HTTPS
//     sameSite: "lax",      // ✅ allows cookies in same-site POSTs
//     path: "/",            // ✅ cookie available on all routes
//   });

//   res.json({ message: "Login successful" });
// });

router.post("/login", upload.none(), async (req, res) => {
  try {
    let data = await checkUser(req, res);
    res.status(200).json(data);
  } catch (error) {
    res.status(400).json({ error });
  }
});

// Register route - only allow role 'applicant'
router.post("/register", upload.none(), async (req, res) => {
  try {
    const { name,email, password, phone, state, userType } = req.body;

    // basic validation
    if (!name) {
      return res.status(400).json({ status: false, msg: "Name is required" });
    }
    if (!email) {
      return res.status(400).json({ status: false, msg: "Email is required" });
    }
    if (!password) {
      return res.status(400).json({ status: false, msg: "Password is required" });
    }
    if (!phone) {
      return res.status(400).json({ status: false, msg: "Phone is required" });
    }
    if (!state) {
      return res.status(400).json({ status: false, msg: "State is required" });
    }

    // enforce role applicant only
    if (userType && userType !== "applicant") {
      return res.status(403).json({ status: false, msg: "Registration allowed for role 'applicant' only" });
    }

    // check duplicate
    const existing = await User.findOne({ where: { email } });
    if (existing) {
      return res.status(409).json({ status: false, msg: "User with this email already exists" });
    }

    // create token
    const token = jwt.sign({ email, password }, privateKey, { expiresIn: "10d", algorithm: "RS256" });

    // generate unique 8-digit numeric user_id
    let generatedId;
    const maxAttempts = 5;
    let attempt = 0;
    while (attempt < maxAttempts) {
      // generate number between 10000000 and 99999999 (8 digits)
      const candidate = Math.floor(10000000 + Math.random() * 90000000);
      // check collision
      // eslint-disable-next-line no-await-in-loop
      const existsById = await User.findOne({ where: { user_id: candidate } });
      if (!existsById) {
        generatedId = candidate;
        break;
      }
      attempt += 1;
    }
    if (!generatedId) {
      return res.status(500).json({ status: false, msg: "Could not generate unique user id, try again" });
    }

    // create user and profile in a single sequelize transaction
    const t = await sequelize.transaction();
    let newUser;
    try {
      newUser = await User.create({
        user_id: generatedId,
        userType: "applicant",
        email,
        password,
        token,
        status: "active",
      }, { transaction: t });

      const state_code = state;
      const fullname = name || req.body.fullname || "";

      await UserProfile.create({
        user_id: generatedId,
        id: generatedId,
        state_code,
        status: "active",
        fullname,
        email,
        phone,
      }, { transaction: t });

      await t.commit();
    } catch (profileErr) {
      console.error("Error creating user/profile in transaction:", profileErr);
      try {
        await t.rollback();
      } catch (rbErr) {
        console.error("Rollback error:", rbErr);
      }
      return res.status(500).json({ status: false, msg: "Failed to create user and profile", error: profileErr });
    }

    // set cookie
    res.cookie("token", token, {
      httpOnly: true,
      secure: false,
      sameSite: "lax",
      path: "/",
      expires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    });

    return res.status(201).json({ status: true, msg: "User Successfully Registered", token, info: { ...newUser.get({ plain: true }), role: ["applicant"] } });
  } catch (err) {
    console.error("Error in /register:", err);
    return res.status(500).json({ status: false, error: err });
  }
});


router.post("/tokenValidation", async (req, res) => {
  const authHeader = req.headers["authorization"];
  if (authHeader) {
    // eslint-disable-next-line no-unused-vars
    jwt.verify(authHeader, privateKey, (err, decodedToken) => {
      if (err) {
        return res.status(403).json({ error: "Invalid token" });
      }
      // req.user = decodedToken;
      res.status(200);
      res.json({ validate: true });
    });
  } else {
    return res.status(401).json({ error: "Authorization header missing" });
  }
});

export default router;
