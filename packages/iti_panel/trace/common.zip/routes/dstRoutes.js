import express from 'express';
import {
  getAllDst,
  getDstById,
  createDst,
  updateDst,
  deleteDst,
} from '../controllers/dstController.js';
import { authenticate } from '../Middleware/auth.js';

const router = express.Router();

// All DST routes require authentication
router.use(authenticate);

// GET /api/dst - Get all DST records for the authenticated user
router.get('/', getAllDst);

// GET /api/dst/:id - Get a specific DST record by ID
router.get('/:id', getDstById);

// POST /api/dst - Create a new DST record
router.post('/', createDst);

// PUT /api/dst/:id - Update a DST record by ID
router.put('/:id', updateDst);

// DELETE /api/dst/:id - Delete a DST record by ID
router.delete('/:id', deleteDst);

export default router;
