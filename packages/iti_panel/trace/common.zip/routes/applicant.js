// Route for user login
import express from "express";
const router = express.Router();
import { pKeyPath } from "../common/common.js";
import fs from "fs";
import jwt from "jsonwebtoken";
const privateKey = fs.readFileSync(pKeyPath, "utf8");
router.use(express.json());
import path from "path";

import * as apli from "../database/models/applicant.js";
import { checkUser } from "../database/models/auth.js";
import { authenticateToken } from "../database/models/token.js";

import { applicantToken } from '../Middleware/auth.js';
import multer from "multer";
import { multerErrorHandler, stageISubmitDocuments, test_upload_multer, upload2, uploadProposedInstituteFiles } from "../services/multer/configs.js";
const upload = multer(); // no file saving, just parse fields



router.post("/getFilledTrades", upload.none(), async (req, res) => {
  try {
    const result = await apli.getFilledTrades(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});
// Application Stage I Form Submission
router.post("/setEntityDetails", upload.none(), async (req, res) => {
  try {
    const result = await apli.setEntityDetails(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});


router.post("/getDbEntityDetails", upload.none(), async (req, res) => {
  try {
    const result = await apli.getDbEntityDetails(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});
// Application Stage I Form Submission
router.post("/getAppListByUserId", upload.none(), async (req, res) => {
  try {
    const result = await apli.getAppListByUserId(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});
// Application Stage I Form Submission
router.post("/setProposedInstDetails", uploadProposedInstituteFiles, async (req, res) => {
  try {
    const result = await apli.setProposedInstDetails(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});


// Application Stage I Form Submission
router.post("/getProposedInstDetailsForAutoFill", upload.none(), async (req, res) => {
  try {
    const result = await apli.getProposedInstDetailsForAutoFill(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});


// Application Stage I Form Submission
router.post("/getStage1FormFlow", upload.none(), async (req, res) => {
  try {
    const result = await apli.getStage1FormFlow(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});


router.post("/getStage2FormFlow", upload.none(), async (req, res) => {
  try {
    const result = await apli.getStage2FormFlow(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});







// setInstTradeDetails
router.post("/setInstTradeDetails", upload.none(), async (req, res) => {
  try {
    const result = await apli.setInstTradeDetails(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

// setInstLandDetails
router.post("/setInstLandDetails", upload.none(), async (req, res) => {
  try {
    const result = await apli.setInstLandDetails(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

router.post("/getInstLandDetails", upload.none(), async (req, res) => {
  try {
    const result = await apli.getInstLandDetails(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});

router.post("/landInfo", upload.none(), async (req, res) => {
  try {
    const result = await apli.landInfo(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });    // failure response (better to use 400/500 than 200)
  }
});







// Application Stage I Form Submission
router.post("/getFeeInfo", upload.none(), async (req, res) => {
  try {
    const result = await apli.getFeeInfo(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});
router.post("/getStage1ApplicationInfo", upload.none(), async (req, res) => {
  try {
    const result = await apli.getStage1ApplicationInfo(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});



// setAsExemptedStageI
router.post("/setAsExemptedStageI", upload.none(), async (req, res) => {
  try {
    const result = await apli.setAsExemptedStageI(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});

router.post("/setAsExemptedStageII", upload.none(), async (req, res) => {
  try {
    const result = await apli.setAsExemptedStageII(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});



// setAsExemptedStageI
router.post("/getInstTradeDetails", upload.none(), async (req, res) => {
  try {
    const result = await apli.getInstTradeDetails(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});





// stageISubmitDocuments // Middleware to handle file uploads
router.post("/setUploadDocumentStageI", upload2.any(), async (req, res) => {
  try {
    const result = await apli.setUploadDocumentStageI(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});

router.post("/setSendApplicationStage1ToState", upload2.any(), async (req, res) => {
  try {
    const result = await apli.setSendApplicationStage1ToState(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});


router.post("/cleareForResubmitDeficiency", upload2.any(), async (req, res) => {
  try {
    const result = await apli.cleareForResubmitDeficiency(req, res);
    res.status(200).json(result);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});







/////////////////////////////////////////////////////
router.post("/Cookies", (req, res) => {
  console.log("Cookies:", req.cookies);
  console.log("Refresh Token:", req.cookies.refreshToken);
  res.json({ message: "Check server console for refresh token", cookies: req.cookies });
});


router.post("/tokenValidation", async (req, res) => {
  const authHeader = req.headers["authorization"];
  if (authHeader) {
    // eslint-disable-next-line no-unused-vars
    jwt.verify(authHeader, privateKey, (err, decodedToken) => {
      if (err) {
        return res.status(403).json({ error: "Invalid token" });
      }
      // req.user = decodedToken;
      res.status(200);
      res.json({ validate: true });
    });
  } else {
    return res.status(401).json({ error: "Authorization header missing" });
  }
});



//Test File Uploads
router.post("/test-file-uploads", test_upload_multer.any(), async (req, res) => {
  try {
    // const isDev = process.env.NODE_ENV !== "production";
    // throw process.env.NODE_ENV;
    res.status(200).json(req.files);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error });
  }
});



// State II
router.post("/setBuildingDetail", upload2.any(), async (req, res) => {
  try {
    const result = await apli.setBuildingDetail(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});


router.post("/saveTradewiseWorkShop", upload2.any(), async (req, res) => {
  try {
    const result = await apli.saveTradewiseWorkShop(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});
router.post("/saveTradewiseClassRooms", upload2.any(), async (req, res) => {
  try {
    const result = await apli.saveTradewiseClassRooms(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});


router.post("/getTradewiseClassRooms", upload2.any(), async (req, res) => {
  try {
    const result = await apli.getTradewiseClassRooms(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});



router.post("/saveItLabSpecifications", upload2.any(), async (req, res) => {
  try {
    const result = await apli.saveItLabSpecifications(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});
router.post("/getITLabSpecifications", upload2.any(), async (req, res) => {
  try {
    const result = await apli.getITLabSpecifications(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});

router.post("/getTradewiseWorkShop", upload.none(), async (req, res) => {
  try {
    const result = await apli.getTradewiseWorkShop(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});


router.post("/getStatusFillingMte", upload.none(), async (req, res) => {
  try {
    const result = await apli.getStatusFillingMte(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});

router.post("/getMachineryToolEquipments", upload.none(), async (req, res) => {
  try {
    const result = await apli.getMachineryToolEquipments(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});

router.post("/saveMachineToolEquipmentQty", upload.none(), async (req, res) => {
  try {
    const result = await apli.saveMachineToolEquipmentQty(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});


router.post("/getAmenities", upload.none(), async (req, res) => {
  try {
    const result = await apli.getAmenities(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});

router.post("/saveAmenities", upload2.any(), async (req, res) => {
  try {
    const result = await apli.saveAmenities(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});

router.post("/getSignageBoards", upload2.any(), async (req, res) => {
  try {
    const result = await apli.getSignageBoards(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});

router.post("/saveSignageBoards", upload2.any(), async (req, res) => {
  try {
    const result = await apli.saveSignageBoards(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});

router.post("/saveElectricityDetails", upload2.any(), async (req, res) => {
  try {
    const result = await apli.saveElectricityDetails(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});
router.post("/getElectricityDetails", upload2.any(), async (req, res) => {
  try {
    const result = await apli.getElectricityDetails(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});

router.post("/getDocuments", upload2.any(), async (req, res) => {
  try {
    const result = await apli.getDocuments(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});

router.post("/saveDocumentNcompleteStageII", upload2.any(), async (req, res) => {
  try {
    const result = await apli.saveDocumentNcompleteStageII(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});



router.post("/getParticulars", upload.none(), async (req, res) => {
  try {
    const result = await apli.getParticulars(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});

router.post("/saveParticularDetails", upload2.any(), async (req, res) => {
  try {
    const result = await apli.saveParticularDetails(req, res);  // waits for promise to resolve
    res.status(200).json(result);       // success response
  } catch (error) {
    console.error(error);
    res.status(400).json({ error }); // corrected
  }
});




// Global error handler
router.use(multerErrorHandler);

export default router;
