import express from 'express';
import { getDistricts } from '../controllers/districtsController.js';

const router = express.Router();

router.post('/v1', getDistricts);

export default router;
