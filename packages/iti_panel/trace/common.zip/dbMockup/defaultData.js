export const defaultSampleData = {
  users: [
    {
      userName: "aff01",
      email: "applicant@gmail.com",
      userId: "ABCD0001",
      password: "Abcd@1234",
    },
    {
      userName: "aff02",
      email: "assessor@gmail.com",
      userId: "ABCD0002",
      password: "Abcd@1234",
    },
  ],
};
