// import fs from "fs";
// import path from "path";
// import Busboy from "busboy";

// export const handleBusboyUpload = (req, uploadFolder = "uploads") => {
//   return new Promise((resolve, reject) => {
//     const uploadedFiles = [];

//     const busboy = new Busboy({ headers: req.headers });

//     busboy.on("land_original_documents", (fieldname, file, filename) => {
//       const uploadDir = path.join(process.cwd(), uploadFolder);
//       if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

//       const saveTo = path.join(uploadDir, filename);
//       const writeStream = fs.createWriteStream(saveTo);

//       file.pipe(writeStream);

//       writeStream.on("finish", () => {
//         uploadedFiles.push({ fieldname, filename, path: saveTo });
//       });

//       writeStream.on("error", (err) => {
//         console.error("File write error:", err);
//         file.resume(); // discard remaining data
//         reject(err);
//       });

//       file.on("error", (err) => {
//         console.error("File stream error:", err);
//         reject(err);
//       });
//     });

//     busboy.on("finish", () => {
//       resolve(uploadedFiles);
//     });

//     busboy.on("error", (err) => {
//       console.error("Busboy error:", err);
//       reject(err);
//     });

//     req.pipe(busboy);
//   });
// };
