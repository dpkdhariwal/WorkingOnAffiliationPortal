import multer from "multer";
import fs from "fs";
import path from "path";

import mysql from 'mysql';
import dotenv from "dotenv";
// Load correct .env file based on NODE_ENV
dotenv.config({
  path: `.env.${process.env.NODE_ENV || "development"}`,
});

const baseUploadPath = process.env.TEMP_FILES_UPLOAD_PATH || "uploads";
const isDev = process.env.NODE_ENV !== "production";

// Allowed file types (edit as needed)
const ALLOWED_MIME = ["image/jpeg", "image/png", "application/pdf"];

// Disk storage with dynamic destination + filename
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // You can drive this from extra params you send in form-data
    const userId = req.body.userId || "guest";
    const docType = req.body.docType || "general";

    // e.g. uploads/<docType>/<userId>
    const uploadPath = path.join("uploads", docType, userId);

    // Ensure the folder exists
    fs.mkdirSync(uploadPath, { recursive: true });
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    // Keep extension from original name
    const ext = path.extname(file.originalname);
    // Custom unique filename
    const custom = `${req.body.userId || "guest"}-${Date.now()}${ext}`;
    cb(null, custom);
  },
});

const fileFilter = (req, file, cb) => {
  if (ALLOWED_MIME.includes(file.mimetype)) return cb(null, true);
  cb(new Error(`File type not allowed: ${file.mimetype}`));
};

export const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB per file
    files: 10,                  // max 10 files
  },
});



const storage2 = multer.diskStorage({
  destination: function (req, file, cb) {
    console.log(req, file);
    // console.log(68, process.env.TEMP_FILES_UPLOAD_PATH);
    cb(null, process.env.TEMP_FILES_UPLOAD_PATH || "/")
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const customName = `temp_${Date.now()}-${crypto.randomUUID()}${ext}`;
    cb(null, customName);
  },
})

export const upload2 = multer({ storage: storage2 });

export const stageISubmitDocuments = upload2.fields([
  { name: "doc_of_registration_cert_of_applicant_org", maxCount: 1 },
  { name: "doc_iti_resolution", maxCount: 1 },
  { name: "doc_of_authorized_signatory", maxCount: 1 },
  { name: "doc_of_land_earmarking", maxCount: 1 },
  { name: "id_proof_scp", maxCount: 1 },
  { name: "id_proof_docs_of_authorized_signatory", maxCount: 1 },
  { name: "lease_deed_documents", maxCount: 10 },
  { name: "land_conversion_certificate", maxCount: 10 },
  { name: "onwed_land_documents", maxCount: 10 },
  { name: "land_notarised_documents", maxCount: 10 }
]);


// --- Global Error Handler Middleware ---
export function multerErrorHandler(err, req, res, next) {

  // Multer-specific errors
  if (err instanceof multer.MulterError) {
    switch (err.code) {
      case "LIMIT_FILE_SIZE":
        return res.status(400).json({ error: "File too large" });
      case "LIMIT_FILE_COUNT":
        return res.status(400).json({ error: "Too many files uploaded" });
      case "LIMIT_UNEXPECTED_FILE":
        return res.status(400).json({ error: "Unexpected field/file uploaded" });
      default:
        return res.status(400).json({ error: err.message });
    }
  }

  // Custom errors thrown in your fileFilter or controllers
  if (err instanceof Error) {
    return res.status(400).json({ error: err.message });
  }

  // Fallback for unknown errors
  res.status(500).json({ error: "Internal Server Error" });
}


export const uploadProposedInstituteFiles = upload2.fields([
  { name: "Falls_Under_Hill_Area_Hill__Supporting_Doc", maxCount: 10 },
  { name: "Falls_Under_Border_District__Supporting_Doc", maxCount: 10 },
]);


// Utility: move file
function moveFile(oldPath, newPath) {
  return new Promise((resolve, reject) => {
    fs.rename(oldPath, newPath, (err) => {
      if (err) reject(err);
      else resolve();
    });
  });
}


const test_storage = multer.diskStorage({
  destination: function (req, file, cb) {
    let uploadPath;

    switch (process.env.NODE_ENV) {
      case "production":
        // Production: use only env path
        uploadPath = baseUploadPath;
        break;
      case "development":
        // Development: inside project folder
        uploadPath = path.join(process.cwd(), baseUploadPath);
        break;
      case "test":
        // Test: you can define a separate folder
        uploadPath = path.join(process.cwd(), "test_uploads");
        break;
      default:
        return cb(new Error("Unknown NODE_ENV, cannot determine upload path"));
    }

    // Ensure folder exists
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }

    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const customName = `temp_${Date.now()}-${crypto.randomUUID()}${ext}`;
    cb(null, customName);
  },
});
// File filter to allow only PDFs
const pdfFileFilter = (req, file, cb) => {
  if (file.mimetype === "application/pdf") {
    cb(null, true);
  } else {
    cb(new Error("Only PDF files are allowed"), false);
  }
};
export const test_upload_multer = multer({
  storage: test_storage,
  fileFilter: pdfFileFilter,
});
