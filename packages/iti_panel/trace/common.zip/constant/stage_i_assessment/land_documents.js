import * as C from "../constants.js";
import * as yup from "yup";
export const intiValues = { as_per_norms: "", reason: "", assessor_comments: "", }
export const ValidationSchema = {
    as_per_norms: yup
        .string()
        .required("Select whether Land Document is as per norms"),
    reason: yup
        .string()
        .when("as_per_norms", {
            is: "no",
            then: (schema) => schema.required("Please select a category"),
            otherwise: (schema) => schema.notRequired(),
        }),
    assessor_comments: yup
        .string()
        .test(
            "required-if-no",
            "Enter Assessor Remark",
            function (value) {
                const { as_per_norms, reason } = this.parent; // 👈 here you can use it
                console.log(this.parent);
                if (as_per_norms === "no" && reason == "other") {
                    return !!value?.trim();
                }
                return true;
            }
        ),
}
export const valSchema = yup.object(ValidationSchema)


