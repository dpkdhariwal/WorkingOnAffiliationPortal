import * as yup from "yup";
export const intiValues = {
  WORKSHOPS: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  CLASSROOMS: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  MULTIPURPOSE_HALL: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  IT_LAB: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  LIBRARY: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  PLACEMENT_AND_COUNSELLING_ROOM: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  PRINCIPAL_ROOM: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  RECEPTION_CUM: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  STAFF_ROOM: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  ADMINISTRATIVE_HALL_SECTION: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
}
const roomSchema = yup.object({
  as_per_norms: yup.string().required("Please select Yes or No"),
  reason: yup
    .string()
    .nullable()
    .when("as_per_norms", {
      is: "no",
      then: (schema) => schema.required("Please select a reason"),
      otherwise: (schema) => schema.nullable(),
    }),
  assessor_comments: yup
    .string()
    .nullable()
    .when("reason", {
      is: (val) => val === "other",
      then: (schema) => schema.required("Please enter assessor comments"),
      otherwise: (schema) => schema.nullable(),
    }),
});

export const ValSchema = yup.object({
  MULTIPURPOSE_HALL: roomSchema,
  IT_LAB: roomSchema,
  LIBRARY: roomSchema,
  PLACEMENT_AND_COUNSELLING_ROOM: roomSchema,
  PRINCIPAL_ROOM: roomSchema,
  RECEPTION_CUM: roomSchema,
  STAFF_ROOM: roomSchema,
  ADMINISTRATIVE_HALL_SECTION: roomSchema,
  WORKSHOPS: roomSchema,
  CLASSROOMS: roomSchema,

});
