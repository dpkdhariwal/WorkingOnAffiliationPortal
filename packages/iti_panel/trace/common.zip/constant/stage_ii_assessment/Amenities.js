import * as yup from "yup";
export const intiValues = {
  FIRST_AID_ROOM: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  LIBRARY_AND_READING_ROOM: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  PLAYGROUND: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  DRINKING_WATER_FACILITY: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  AVAILABILITY_OF_STAIRCASES: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  TOILETS_WATER_CLOSETS: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  GENERAL_PARKING_DETAILS: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
}

const roomSchema = yup.object({
  as_per_norms: yup.string().required("Please select Yes or No"),
  reason: yup
    .string()
    .nullable()
    .when("as_per_norms", {
      is: "no",
      then: (schema) => schema.required("Please select a reason"),
      otherwise: (schema) => schema.nullable(),
    }),
  assessor_comments: yup
    .string()
    .nullable()
    .when("reason", {
      is: (val) => val === "other",
      then: (schema) => schema.required("Please enter assessor comments"),
      otherwise: (schema) => schema.nullable(),
    }),
});

export const ValSchema = yup.object({
  FIRST_AID_ROOM: roomSchema,
  LIBRARY_AND_READING_ROOM: roomSchema,
  PLAYGROUND: roomSchema,
  DRINKING_WATER_FACILITY: roomSchema,
  AVAILABILITY_OF_STAIRCASES: roomSchema,
  TOILETS_WATER_CLOSETS: roomSchema,
  GENERAL_PARKING_DETAILS: roomSchema,
});
