import * as yup from "yup";
export const intiValues = {
  ELECTRICITY_CONNECTION: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  PHOTO_OF_BACKUP_POWER: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  PURCHASE_RELATED_DOCUMENTS: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },

  FIRE_AND_SAFETY_CERTIFICATE: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },

}

const roomSchema = yup.object({
  as_per_norms: yup.string().required("Please select Yes or No"),
  reason: yup
    .string()
    .nullable()
    .when("as_per_norms", {
      is: "no",
      then: (schema) => schema.required("Please select a reason"),
      otherwise: (schema) => schema.nullable(),
    }),
  assessor_comments: yup
    .string()
    .nullable()
    .when("reason", {
      is: (val) => val === "other",
      then: (schema) => schema.required("Please enter assessor comments"),
      otherwise: (schema) => schema.nullable(),
    }),
});

export const ValSchema = yup.object({
  ELECTRICITY_CONNECTION: roomSchema,
  PHOTO_OF_BACKUP_POWER: roomSchema,
 
});
