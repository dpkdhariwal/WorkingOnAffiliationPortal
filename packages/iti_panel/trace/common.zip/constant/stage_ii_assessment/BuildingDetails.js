import * as yup from "yup";
export const intiValues = {
    building_plan: {
        as_per_norms: "", reason: "", assessor_comments: "",
    },
    building_completion_certificate: {
        documents: [{
            as_per_nor: '', // yes || no
            language:'', // prefilled - disabled
            document:'',  // prefilled - disabled
            notarise_document:'',   // prefilled - disabled
            uploaded_date_time:''   // prefilled - disabled
        }],
        as_per_norms: "",  // radio - yes || no
        reason: "", // selection - list
        assessor_comments: "", // assessor_comments required if reason is other
    },
    building_photos: {
        photos: [{
            as_per_nor: '', // yes || no
            photo:'', // prefilled - disabled
            uploaded_date_time:''   // prefilled - disabled
        }],
        as_per_norms: "",  // radio - yes || no
        reason: "", // selection - list
        assessor_comments: "", // assessor_comments required if reason is other
    },
}

export const ValSchema = yup.object({
  building_plan: yup.object({
    as_per_norms: yup.string().required("Please select Yes or No"),
    reason: yup
      .string()
      .nullable()
      .when("as_per_norms", {
        is: "no",
        then: (schema) => schema.required("Please select a reason"),
        otherwise: (schema) => schema.nullable(),
      }),
    assessor_comments: yup
      .string()
      .nullable()
      .when("reason", {
        is: (val) => val === "other",
        then: (schema) => schema.required("Please enter assessor comments"),
        otherwise: (schema) => schema.nullable(),
      }),
  }),

  building_completion_certificate: yup.object({
    // documents: yup.array().of(
    //   yup.object({
    //     as_per_nor: yup.string().required("Please select Yes or No"),
    //     language: yup.string().nullable(),
    //     document: yup.string().nullable(),
    //     notarise_document: yup.string().nullable(),
    //     uploaded_date_time: yup.string().nullable(),
    //   })
    // ),
    as_per_norms: yup.string().required("Please select Yes or No"),
    reason: yup
      .string()
      .nullable()
      .when("as_per_norms", {
        is: "no",
        then: (schema) => schema.required("Please select a reason"),
        otherwise: (schema) => schema.nullable(),
      }),
    assessor_comments: yup
      .string()
      .nullable()
      .when("reason", {
        is: (val) => val === "other",
        then: (schema) => schema.required("Please enter assessor comments"),
        otherwise: (schema) => schema.nullable(),
      }),
  }),

  building_photos: yup.object({
    photos: yup.array().of(
      yup.object({
        as_per_norms: yup.string().required("Please select Yes or No"),
        photo: yup.string().nullable(),
        uploaded_date_time: yup.string().nullable(),
      })
    ),
    as_per_norms: yup.string().required("Please select Yes or No"),
    reason: yup
      .string()
      .nullable()
      .when("as_per_norms", {
        is: "no",
        then: (schema) => schema.required("Please select a reason"),
        otherwise: (schema) => schema.nullable(),
      }),
    assessor_comments: yup
      .string()
      .nullable()
      .when("reason", {
        is: (val) => val === "other",
        then: (schema) => schema.required("Please enter assessor comments"),
        otherwise: (schema) => schema.nullable(),
      }),
  }),
});
