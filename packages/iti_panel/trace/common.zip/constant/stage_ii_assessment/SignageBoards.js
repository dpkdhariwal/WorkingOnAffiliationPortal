import * as yup from "yup";
export const intiValues = {
  SIGNAGE_BOARD_ON_PLOT_ENTRANCE: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  SIGNAGE_BOARD_ON_INSTITUTE_BUILDING: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  SIGNAGE_BOARDS: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  TRADE_DETAILS_BOARD: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  STAFF_DETAILS_BOARD: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  EXIT_BOARD: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  BOARD_INDICATING_DANGER_SIGNS: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  PROHIBITED_AREA_INDICATORS: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
  SEXUAL_HARASSMENT_REDRESSAL_COMMITTEE_NOTICE: {
    initial_detail: "",
    latest_detail: "",
    as_per_norms: "", reason: "", assessor_comments: "",
  },
}

const roomSchema = yup.object({
  as_per_norms: yup.string().required("Please select Yes or No"),
  reason: yup
    .string()
    .nullable()
    .when("as_per_norms", {
      is: "no",
      then: (schema) => schema.required("Please select a reason"),
      otherwise: (schema) => schema.nullable(),
    }),
  assessor_comments: yup
    .string()
    .nullable()
    .when("reason", {
      is: (val) => val === "other",
      then: (schema) => schema.required("Please enter assessor comments"),
      otherwise: (schema) => schema.nullable(),
    }),
});

export const ValSchema = yup.object({
  SIGNAGE_BOARD_ON_PLOT_ENTRANCE: roomSchema,
  SIGNAGE_BOARD_ON_INSTITUTE_BUILDING: roomSchema,
  SIGNAGE_BOARDS: roomSchema,
  TRADE_DETAILS_BOARD: roomSchema,
  STAFF_DETAILS_BOARD: roomSchema,
  EXIT_BOARD: roomSchema,
  BOARD_INDICATING_DANGER_SIGNS: roomSchema,
  PROHIBITED_AREA_INDICATORS: roomSchema,
  SEXUAL_HARASSMENT_REDRESSAL_COMMITTEE_NOTICE: roomSchema,
});
