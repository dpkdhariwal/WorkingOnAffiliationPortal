import * as C from "../constants.js";
import * as yup from "yup";
export const intiValues = {
    trades: [{ trade: "", units_in_shift_1: "", units_in_shift_2: "", units_in_shift_3: "" },
    { trade: "", units_in_shift_1: "", units_in_shift_2: "", units_in_shift_3: "" },
    { trade: "", units_in_shift_1: "", units_in_shift_2: "", units_in_shift_3: "" },
    { trade: "", units_in_shift_1: "", units_in_shift_2: "", units_in_shift_3: "" }
    ],
};

export const valSchema = yup.object().shape({
    trades: yup.array()
        .of(
            yup.object({
                trade: yup.string()
                    .required("Select Trade"),
                units_in_shift_1: yup.string()
                    .required("Enter Units in Shift 1"),
                units_in_shift_2: yup.string()
                    .required("Enter Units in Shift 2"),
                units_in_shift_3: yup.mixed()
                    .test("dst", "Invalid", (value) => true)
            })
        )
        .min(4, "Minimum of 4 trades required for New ITI"),
});