import * as C from "../constants.js";

export const initialValues = {
  possession_of_land: "",
  land_area_in_square_metres: "",
  land_owner_name: "",
  land_registration_number: "",
  name_of_lessor: "",
  name_of_lessee: "",
  lease_deed_number: "",
  date_of_commencement: "",
  date_of_expiry: "",
};