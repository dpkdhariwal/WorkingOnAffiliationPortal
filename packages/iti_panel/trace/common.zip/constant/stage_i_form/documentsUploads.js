import * as C from "../constants.js";
import * as yup from "yup";
export const intiValues = {

    possession_of_land: null,

    onwed_land_documents: [{ land_documents_language: '', land_documents: null, land_notarised_documents: null }], // default one document
    lease_deed_documents: [{ language: '', documents: null, notarised_documents: null }], // default one document
    land_conversion_certificate: [{ language: '', documents: null, notarised_documents: null }], // default one document

    // Authorized Signatory
    name_of_authorized_signatory: "",

    email_id_of_authorized_signatory: "",
    is_verified_email_id_of_authorized_signatory: false,

    mobile_number_of_authorized_signatory: "",
    is_verified_mobile_number_of_authorized_signatory: false,

    id_proof_of_authorized_signatory: "",
    id_proof_number_of_authorized_signatory: "",
    id_proof_docs_of_authorized_signatory: null,
    // Authorized Signatory Ends Here


    doc_of_registration_cert_of_applicant_org: null,

    id_proof_scp: [{ designation: "", id_proof_type: "", id_proof_number: "", id_proof_doc: null }], // default one document

    doc_iti_resolution: null,
    doc_of_authorized_signatory: null,
    doc_of_land_earmarking: null,

    acceptTerms: false
}

export const ValidationSchema = {
    possession_of_land: yup.string().required("Possession of Land is Missing"), // "owned" or "leased"
    onwed_land_documents: yup
        .array().when("possession_of_land", {
            is: (val) => val === "owned",
            then: (schema) => schema.of(
                yup.object({
                    land_documents_language: yup.string()
                        .required("Select Document Language"),
                    land_documents: yup.mixed()
                        .required("Select Land Document File")
                        .test("fileSize", "File too large", (value) => {
                            return value ? value.size <= 2 * 1024 * 1024 : true; // 2MB
                        })
                        .test("fileType", "Unsupported File Format", (value) => {
                            return value
                                ? ["application/pdf", "image/jpeg", "image/png"].includes(
                                    value.type
                                )
                                : true;
                        }),
                    land_notarised_documents: yup
                        .mixed()
                        .when("land_documents_language", {
                            is: (lang) => lang !== "Hindi" && lang !== "English", // ✅ condition
                            then: (schema) =>
                                schema
                                    .required("Select Notarized Document")
                                    .test("fileSize", "File too large", (value) =>
                                        value ? value.size <= 2 * 1024 * 1024 : true
                                    )
                                    .test("fileType", "Unsupported File Format", (value) =>
                                        value
                                            ? ["application/pdf", "image/jpeg", "image/png"].includes(
                                                value.type
                                            )
                                            : true
                                    ),
                            otherwise: (schema) => schema.notRequired(), // ✅ skip validation
                        }),
                })
            ).min(1, "At least one document is required"),
            otherwise: (schema) => schema.notRequired(),
        }),
    lease_deed_documents: yup.array().when("possession_of_land", {
        is: (val) => val === "leased",
        then: (schema) => schema.of(
            yup.object({
                language: yup.string()
                    .required("Select Document Language"),
                documents: yup.mixed()
                    .required("Select Land Document File")
                    .test("fileSize", "File too large", (value) => {
                        return value ? value.size <= 2 * 1024 * 1024 : true; // 2MB
                    })
                    .test("fileType", "Unsupported File Format", (value) => {
                        return value
                            ? ["application/pdf", "image/jpeg", "image/png"].includes(
                                value.type
                            )
                            : true;
                    }),
                notarised_documents: yup
                    .mixed()
                    .when("language", {
                        is: (lang) => lang !== "Hindi" && lang !== "English", // ✅ condition
                        then: (schema) =>
                            schema
                                .required("Select Notarized Document")
                                .test("fileSize", "File too large", (value) =>
                                    value ? value.size <= 2 * 1024 * 1024 : true
                                )
                                .test("fileType", "Unsupported File Format", (value) =>
                                    value
                                        ? ["application/pdf", "image/jpeg", "image/png"].includes(
                                            value.type
                                        )
                                        : true
                                ),
                        otherwise: (schema) => schema.notRequired(), // ✅ skip validation
                    }),
            })
        ).min(1, "At least one document is required"),
        otherwise: (schema) => schema.notRequired(),
    }),

    land_conversion_certificate: yup.array()
        .of(
            yup.object({

                language: yup.string()
                    .required("Select Document Language"),
                documents: yup.mixed()
                    .required("Select Land Document File")
                    .test("fileSize", "File too large", (value) => {
                        return value ? value.size <= 2 * 1024 * 1024 : true; // 2MB
                    })
                    .test("fileType", "Unsupported File Format", (value) => {
                        return value
                            ? ["application/pdf", "image/jpeg", "image/png"].includes(
                                value.type
                            )
                            : true;
                    }),
                notarised_documents: yup
                    .mixed()
                    .when("language", {
                        is: (lang) => lang !== "Hindi" && lang !== "English", // ✅ condition
                        then: (schema) =>
                            schema
                                .required("Select Notarized Document")
                                .test("fileSize", "File too large", (value) =>
                                    value ? value.size <= 2 * 1024 * 1024 : true
                                )
                                .test("fileType", "Unsupported File Format", (value) =>
                                    value
                                        ? ["application/pdf", "image/jpeg", "image/png"].includes(
                                            value.type
                                        )
                                        : true
                                ),
                        otherwise: (schema) => schema.notRequired(), // ✅ skip validation
                    }),
            })
        )
        .min(1, "At least one document is required"),
    name_of_authorized_signatory: yup.string()
        .required("Name of authorized signatory is required"),

    email_id_of_authorized_signatory: yup
        .string()
        .email("Invalid email address")
        .required("Email is required")
        .test(
            "email-verified",
            "Email must be verified",
            function (value) {
                // `this.parent` gives access to other fields
                return value && this.parent.is_verified_email_id_of_authorized_signatory;
            }
        ),

    is_verified_email_id_of_authorized_signatory: yup.boolean().oneOf([true], "Please verify your email before submitting").default(false),

    mobile_number_of_authorized_signatory: yup.string()
        .matches(/^[0-9]{10}$/, "Enter a valid 10-digit mobile number")
        .required("Mobile number is required").test(
            "mobile-verified",
            "Mobile must be verified",
            function (value) {
                // `this.parent` gives access to other fields
                return value && this.parent.is_verified_mobile_number_of_authorized_signatory;
            }
        ),
    is_verified_mobile_number_of_authorized_signatory: yup.boolean().oneOf([true], "Please verify your Mobile before submitting").default(false),


    id_proof_of_authorized_signatory: yup.string()
        .required("Select ID proof type"),
    id_proof_number_of_authorized_signatory: yup.string()
        .required("Enter ID proof number"),
    id_proof_docs_of_authorized_signatory: yup.mixed()
        .required("Upload ID proof document")
        .test("fileSize", "File too large", (value) =>
            value ? value.size <= C.MAX_FILE_SIZE : true
        )
        .test("fileType", "Unsupported File Format", (value) =>
            value ? C.SUPPORTED_FORMATS.includes(value.type) : true
        ),
    doc_of_registration_cert_of_applicant_org: yup.mixed()
        .required("Upload ID proof document")
        .test("fileSize", "File too large", (value) =>
            value ? value.size <= C.MAX_FILE_SIZE : true
        )
        .test("fileType", "Unsupported File Format", (value) =>
            value ? C.SUPPORTED_FORMATS.includes(value.type) : true
        ),

    id_proof_scp: yup.array()
        .of(
            yup.object({
                designation: yup.string()
                    .required("Select Document Language"),
                id_proof_type: yup.string()
                    .required("Select Document Language"),
                id_proof_number: yup.string()
                    .required("Select Document Language"),
                id_proof_doc: yup.mixed()
                    .required("Select Document")
                    .test("fileSize", "File too large", (value) =>
                        value ? value.size <= 2 * 1024 * 1024 : true
                    )
                    .test("fileType", "Unsupported File Format", (value) =>
                        value
                            ? ["application/pdf", "image/jpeg", "image/png"].includes(
                                value.type
                            )
                            : true
                    ),
            })
        )
        .min(1, "At least one document is required"),

    doc_iti_resolution: yup.mixed()
        .required("Upload ID proof document")
        .test("fileSize", "File too large", (value) =>
            value ? value.size <= C.MAX_FILE_SIZE : true
        )
        .test("fileType", "Unsupported File Format", (value) =>
            value ? C.SUPPORTED_FORMATS.includes(value.type) : true
        ),

    doc_of_authorized_signatory: yup.mixed()
        .required("Upload ID proof document")
        .test("fileSize", "File too large", (value) =>
            value ? value.size <= C.MAX_FILE_SIZE : true
        )
        .test("fileType", "Unsupported File Format", (value) =>
            value ? C.SUPPORTED_FORMATS.includes(value.type) : true
        ),
    doc_of_land_earmarking: yup.mixed()
        .required("Upload ID proof document")
        .test("fileSize", "File too large", (value) =>
            value ? value.size <= C.MAX_FILE_SIZE : true
        )
        .test("fileType", "Unsupported File Format", (value) =>
            value ? C.SUPPORTED_FORMATS.includes(value.type) : true
        ),
    acceptTerms: yup
        .boolean()
        .oneOf([true], "You must accept the terms to continue")
        .required("You must accept the terms to continue"),

};
export const valSchema = yup.object(ValidationSchema)



// Only for Land Documents
export const intiValuesForLandDocuments = {
    possession_of_land: null,
    onwed_land_documents: [{ land_documents_language: '', land_documents: null, land_notarised_documents: null },
    { land_documents_language: '', land_documents: null, land_notarised_documents: null },
    ], // default one document
}
export const valSchemaForLandDocuments = yup.object({
    onwed_land_documents: yup
        .array()
        .of(
            yup.object({
                land_documents_language: yup.string()
                    .required("Select Document Language"),

                land_documents: yup.mixed()
                    .required("Select Land Document File")
                    .test("fileSize", "File too large", (value) => {
                        return value ? value.size <= 2 * 1024 * 1024 : true; // 2MB
                    })
                    .test("fileType", "Unsupported File Format", (value) => {
                        return value
                            ? ["application/pdf", "image/jpeg", "image/png"].includes(value.type)
                            : true;
                    }),

                land_notarised_documents: yup.mixed().when("land_documents_language", {
                    is: (lang) => lang !== "Hindi" && lang !== "English", // ✅ condition
                    then: (schema) =>
                        schema
                            .required("Select Notarized Document")
                            .test("fileSize", "File too large", (value) =>
                                value ? value.size <= 2 * 1024 * 1024 : true
                            )
                            .test("fileType", "Unsupported File Format", (value) =>
                                value
                                    ? ["application/pdf", "image/jpeg", "image/png"].includes(value.type)
                                    : true
                            ),
                    otherwise: (schema) => schema.notRequired(),
                }),
            })
        )
        .min(1, "At least one document is required"), // ✅ always at least 1 doc
})



// Authorized Signatory
// Only for Land Documents
export const intiValuesAuthorizedSignatory = {
    name_of_authorized_signatory: intiValues.name_of_authorized_signatory,
    email_id_of_authorized_signatory: intiValues.email_id_of_authorized_signatory,
    // is_verified_email_id_of_authorized_signatory: intiValues.is_verified_email_id_of_authorized_signatory,
    mobile_number_of_authorized_signatorym: intiValues.mobile_number_of_authorized_signatorym,
    // is_verified_mobile_number_of_authorized_signatory: intiValues.is_verified_mobile_number_of_authorized_signatory,
    id_proof_of_authorized_signatory: intiValues.id_proof_of_authorized_signatory,
    id_proof_number_of_authorized_signatory: intiValues.id_proof_number_of_authorized_signatory,
    id_proof_docs_of_authorized_signatory: intiValues.id_proof_docs_of_authorized_signatory,
}
export const valSchemaForAuthorizedSignatory = yup.object({
    name_of_authorized_signatory: ValidationSchema.name_of_authorized_signatory,
    email_id_of_authorized_signatory: ValidationSchema.email_id_of_authorized_signatory,
    is_verified_email_id_of_authorized_signatory: ValidationSchema.is_verified_email_id_of_authorized_signatory,
    mobile_number_of_authorized_signatory: ValidationSchema.mobile_number_of_authorized_signatory,
    is_verified_mobile_number_of_authorized_signatory: ValidationSchema.is_verified_mobile_number_of_authorized_signatory,
    id_proof_of_authorized_signatory: ValidationSchema.id_proof_of_authorized_signatory,
    id_proof_number_of_authorized_signatory: ValidationSchema.id_proof_number_of_authorized_signatory,
    id_proof_docs_of_authorized_signatory: ValidationSchema.id_proof_docs_of_authorized_signatory,
});



// Registration Certificate of Orgnanization
export const intiValuesRegistrationCertificateOrg = {
    doc_of_registration_cert_of_applicant_org: intiValues.doc_of_registration_cert_of_applicant_org
}
export const valSchemaForRegistrationCertificateOrg = yup.object({
    doc_of_registration_cert_of_applicant_org: ValidationSchema.doc_of_registration_cert_of_applicant_org,
});


// Start Resolution
export const intiValuesResolutionForStartingITI = {
    doc_iti_resolution: intiValues.doc_iti_resolution
}
export const valSchemaResolutionForStartingITI = yup.object({
    doc_iti_resolution: ValidationSchema.doc_iti_resolution,
});








