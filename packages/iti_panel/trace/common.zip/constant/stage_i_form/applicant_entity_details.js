import * as C from "../constants.js";
export const runningITI_Obj = {
    run_AffiliationNo: "",
    run_ITIName: "",
    run_MISCode: "",
    run_State: "",
    run_District: "",
    run_SubDistrict: "",
    run_village: "",
    run_TownCity: "",
    run_Pincode: "",
    run_PlotNumber_KhasaraNumber: "",
    run_Landmark: "",
}

export const initialValues = {
    //Affiliation Category
    aff_category: "",
    aff_sub_category: "",

    // Entity Category
    category: "",
    name_of_applicant_entity: "",

    // Address of Applicant Entity
    ApplicantEntityState: "",
    ApplicantEntityDistrict: "",
    ApplicantEntitySubDistrict: "",
    ApplicantEntityVillage: "",
    ApplicantEntityPincode: "",
    ApplicantEntityPlotNumber_KhasaraNumber_GataNumber: "",
    ApplicantEntityLandmark: "",
    ApplicantEntityTown_City: "",
    ApplicantEntityAddressBlock:"",
    //End

    // Entity Email and Contacts
    ApplicantEntityEmailId: "",
    isApplicantEntityEmailIdVerified: false,
    ApplicantContactNumber: "",
    isApplicantEntityMobileNumberVerified: false,
    // End


    // Is the Entity Running Any Other ITI?
    Is_the_applicant_running_any_other_iti: "",
    runningITIs: [{
        run_AffiliationNo: "",
        run_ITIName: "",
        run_MISCode: "",
        run_State: "",
        run_District: "",
        run_SubDistrict: "",
        run_Village: "",
        run_TownCity: "",
        run_Pincode: "",
        run_PlotNumber_KhasaraNumber: "",
        run_Landmark: "",
    }],
    // End
};


export const app_cat_list = [
    {
        cat: C.aff_cat.Society_Trust
    },
    {
        cat: C.aff_cat.Private_Limited_Company
    },
    {
        cat: C.aff_cat.Sole_Proprietor
    },
    {
        cat: C.aff_cat.Private_Institution_Individual
    },
    {
        cat: C.aff_cat.Public_Sector_Undertaking
    },
    {
        cat: C.aff_cat.Central_State_Government_Union_Territory_Administration
    },
];




export const AffiliationCategory = [
    C.af_cats.NEW_ITIS,
    C.af_cats.MSTI,
    C.af_cats.NEW_AGE,
    C.af_cats.DST,
    C.af_cats.Surrender_Trade_Units,
    {
        ...C.af_cats.Existing_ITIs,
        subCate: [
            C.EXT_ITI_SUBCATE.Addition_Trades_Units,
            C.EXT_ITI_SUBCATE.Name_Change,
            C.EXT_ITI_SUBCATE.Shifting_Relocation,
            C.EXT_ITI_SUBCATE.Merger_of_ITIs,
            C.EXT_ITI_SUBCATE.SCVT_to_NCVET,
            C.EXT_ITI_SUBCATE.Renewal
        ]
    }
];
