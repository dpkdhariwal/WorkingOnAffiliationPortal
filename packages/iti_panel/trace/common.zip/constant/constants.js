import dayjs from "dayjs";
import utc from "dayjs/plugin/utc.js";
import timezone from "dayjs/plugin/timezone.js";
// import crypto from "crypto";
import { v4 as uuidv4 } from "uuid";
import { nanoid } from "nanoid";


dayjs.extend(utc);
dayjs.extend(timezone);
let updateDate, currentDate;
export const formattedDate = dayjs().tz("Asia/Kolkata").toISOString();
export const submitDate = updateDate = currentDate = dayjs().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
// export const randomId = () => crypto.randomUUID();
export const randomIdLong = () => uuidv4();
export const randomId = () => nanoid(8);


// Abbreviations
export const FILLED = "FILLED";
export const NOT_FILLED = "NOT_FILLED";
export const LAST = "LAST";

export const abbreviation = {
  STAGE_I: { key: "STAGE_I" },
  STAGE_II: { key: "STAGE_II" },
}

// User Type
export const UserType = {
  APPLICANT: "APPLICANT",
  STATE_ADMIN: "STATE_ADMIN",
  RDSDE: "RDSDE",
  DGT_ADMIN: "DGT_ADMIN",
  STATE_ASSESSOR: "STATE_ASSESSOR",
}

export const getUserTypeByString = (string) => {
  switch (string) {
    case "state_assessor":
      return SL.ASSESSOR;
    default:
      return string;
  }
}

export const TRADEWISE_MACHINERY_TOOLS_EQUIPMENT = "TRADEWISE_MACHINERY_TOOLS_EQUIPMENT";

// Civil Infrastructure Details KEYS
export const CIK = {
  MULTIPURPOSE_HALL: "MULTIPURPOSE_HALL",
  IT_LAB: "IT_LAB",
  LIBRARY: "LIBRARY",
  SPECIFICATIONS_OF_IT_LAB: "SPECIFICATIONS_OF_IT_LAB",
  TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS: "TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS",
  PLACEMENT_AND_COUNSELLING_ROOM: "PLACEMENT_AND_COUNSELLING_ROOM",
  PRINCIPAL_ROOM: "PRINCIPAL_ROOM",
  RECEPTION_CUM_WAITING_LOBBY: "RECEPTION_CUM_WAITING_LOBBY",
  STAFF_ROOM: "STAFF_ROOM",
  ADMINISTRATIVE_HALL_SECTION: "ADMINISTRATIVE_HALL_SECTION"
};

// Status List
export const SL = {

  COMPLETED: "COMPLETED",
  ON_PROGRESS: "ON_PROGRESS",
  ON_PROGRESS_2: "ON-PROGRESS",
  ACTIVE: "ACTIVE",
  IN_ACTIVE: "IN_ACTIVE",
  VERIFIED: "VERIFIED",
  NC: "NC",
  PENDING_FOR_VERIFICATION: "PENDING_FOR_VERIFICATION",
  PENDING: "PENDING",
  YES: "yes",
  NO: "no",
  PENDING_AT_APPLICANT: "PENDING_AT_APPLICANT",
  PENDING_AT_ASSESSOR: "PENDING_AT_ASSESSOR",
  PENDING_AT_RDSDE: "PENDING_AT_RDSDE",
  NULL: null,

  REVIEWED: "REVIEWED",
  REPLIED: "REPLIED",

  FORM: "FORM",
  VIEW: "VIEW",
  ASSESSOR: "ASSESSOR",
  APPLICANT: "APPLICANT",

  CURRENT: "CURRENT",
  HISTORY: "HISTORY",
  PRESENT: "PRESENT",
  FUTURE: "FUTURE",
  UPCOMING: "UPCOMING",

  LATEST: "LATEST",
  NOW: "NOW",
  FILLED: "FILLED",
  NOT_FILLED: "NOT_FILLED"
}

export const MastersKey = {
  ID_PROOF: "ID_PROOF",
  DESIGNATION: "DESIGNATION",
}


// These Below Constants are used in the registration process of the ITI panel new application.
export const SAVE_APP_CATEGORY = "SAVE_APP_CATEGORY";
export const UPDATE_APP_CATEGORY = "UPDATE_APP_CATEGORY";

//Applicant Entity Details
export const SAVE_APPLICANT_ENTITY_DETAILS = "SAVE_APPLICANT_ENTITY_DETAILS";
export const UPDATE_APPLICANT_ENTITY_DETAILS = "SAVE_APPLICANT_ENTITY_DETAILS";

export const entityCategories = [
  {
    label: "Society / Trust",
    metaInfo: {
      i: "An entity registered under the Societies Registration Act, 1860 as amended from time to time or any other relevant Acts, through the Chairman/ Secretary of Society.",
    },
  },
  {
    label: "Private Limited Company",
    metaInfo: {
      i: "A company incorporated under the Companies Act, 2013, having limited liability, where ownership is restricted to a small group of shareholders, primarily for non-governmental, commercial, or educational initiatives.",
    },
  },
  {
    label: "Public Limited Company",
    metaInfo: {
      i: "A company incorporated under the Companies Act, 2013, where shares are publicly traded on stock exchanges.",
    },
  },
  {
    label: "Sole Proprietor",
    metaInfo: {
      i: "An individual owning, managing, and controlling an unincorporated business, assuming full responsibility for liabilities and operations, including running an ITI",
    },
  },
  {
    label: "Private Institution / Individual",
    metaInfo: { i: "" },
  },
  {
    label: "Public Sector Undertaking",
    metaInfo: {
      i: "A Public Sector Undertaking (PSU) is a governmentowned corporation, company, or statutory body in which the Central Government, State Government, or Union Territory Government holds more than 51% of the paid-up share capital",
    },
  },
  {
    label: "Central / State Government / Union Territory Administration",
    metaInfo: { i: "" },
  },
];

export const stateList = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal",
  "Andaman and Nicobar Islands",
  "Chandigarh",
  "Dadra and Nagar Haveli and Daman and Diu",
  "Delhi",
  "Jammu and Kashmir",
  "Ladakh",
  "Lakshadweep",
  "Puducherry",
];

export const IndianStates = [
  {
    value: "",
    label: "Select State",
    districts: [],
  },
  {
    value: "Andhra Pradesh",
    label: "Andhra Pradesh",
    districts: [
      "Anantapur",
      "Chittoor",
      "East Godavari",
      "Guntur",
      "Kadapa",
      "Krishna",
      "Kurnool",
      "Nellore",
      "Prakasam",
      "Srikakulam",
      "Visakhapatnam",
      "Vizianagaram",
      "West Godavari",
    ],
  },
  {
    value: "Arunachal Pradesh",
    label: "Arunachal Pradesh",
    districts: [
      "Tawang",
      "West Kameng",
      "East Kameng",
      "Papum Pare",
      "Kurung Kumey",
      "Lower Subansiri",
      "Upper Subansiri",
    ],
  },
  {
    value: "Assam",
    label: "Assam",
    districts: [
      "Baksa",
      "Barpeta",
      "Bongaigaon",
      "Cachar",
      "Darrang",
      "Dhemaji",
      "Dhubri",
      "Dibrugarh",
      "Goalpara",
      "Golaghat",
      "Guwahati",
      "Hailakandi",
      "Jorhat",
      "Kamrup",
      "Karbi Anglong",
      "Karimganj",
      "Kokrajhar",
    ],
  },
  {
    value: "Bihar",
    label: "Bihar",
    districts: [
      "Araria",
      "Arwal",
      "Aurangabad",
      "Banka",
      "Begusarai",
      "Bhagalpur",
      "Bhojpur",
      "Darbhanga",
      "Gaya",
      "Gopalganj",
      "Jamui",
      "Jehanabad",
      "Katihar",
      "Khagaria",
      "Kishanganj",
      "Lakhisarai",
      "Madhepura",
      "Madhubani",
    ],
  },
  {
    value: "Chhattisgarh",
    label: "Chhattisgarh",
    districts: [
      "Balod",
      "Baloda Bazar",
      "Balrampur",
      "Bastar",
      "Bemetara",
      "Bijapur",
      "Bilaspur",
      "Dantewada",
      "Dhamtari",
      "Durg",
      "Gariaband",
      "Janjgir-Champa",
      "Jashpur",
    ],
  },
  {
    value: "Goa",
    label: "Goa",
    districts: ["North Goa", "South Goa"],
  },
  {
    value: "Gujarat",
    label: "Gujarat",
    districts: [
      "Ahmedabad",
      "Amreli",
      "Anand",
      "Aravalli",
      "Banaskantha",
      "Bharuch",
      "Bhavnagar",
      "Botad",
      "Chhota Udaipur",
      "Dahod",
      "Dang",
      "Devbhoomi Dwarka",
      "Gandhinagar",
    ],
  },
  {
    value: "Haryana",
    label: "Haryana",
    districts: [
      "Ambala",
      "Bhiwani",
      "Charkhi Dadri",
      "Faridabad",
      "Fatehabad",
      "Gurugram",
      "Hisar",
      "Jhajjar",
      "Jind",
      "Kaithal",
      "Karnal",
    ],
  },
  {
    value: "Himachal Pradesh",
    label: "Himachal Pradesh",
    districts: [
      "Bilaspur",
      "Chamba",
      "Hamirpur",
      "Kangra",
      "Kinnaur",
      "Kullu",
      "Lahaul and Spiti",
      "Mandi",
      "Shimla",
      "Sirmaur",
      "Solan",
      "Una",
    ],
  },
  {
    value: "Jharkhand",
    label: "Jharkhand",
    districts: [
      "Bokaro",
      "Chatra",
      "Deoghar",
      "Dhanbad",
      "Dumka",
      "East Singhbhum",
      "Garhwa",
      "Giridih",
      "Godda",
      "Gumla",
      "Hazaribagh",
      "Jamtara",
      "Khunti",
    ],
  },
  {
    value: "Karnataka",
    label: "Karnataka",
    districts: [
      "Bagalkot",
      "Ballari",
      "Belagavi",
      "Bengaluru Rural",
      "Bengaluru Urban",
      "Bidar",
      "Chamarajanagar",
      "Chikballapur",
      "Chikkamagaluru",
      "Chitradurga",
      "Dakshina Kannada",
      "Davanagere",
    ],
  },
  {
    value: "Kerala",
    label: "Kerala",
    districts: [
      "Alappuzha",
      "Ernakulam",
      "Idukki",
      "Kannur",
      "Kasaragod",
      "Kollam",
      "Kottayam",
      "Kozhikode",
      "Malappuram",
      "Palakkad",
      "Pathanamthitta",
      "Thiruvananthapuram",
      "Thrissur",
      "Wayanad",
    ],
  },
  {
    value: "Madhya Pradesh",
    label: "Madhya Pradesh",
    districts: [
      "Bhopal",
      "Indore",
      "Jabalpur",
      "Gwalior",
      "Rewa",
      "Sagar",
      "Ujjain",
      "Satna",
      "Ratlam",
    ],
  },
  {
    value: "Maharashtra",
    label: "Maharashtra",
    districts: [
      "Ahmednagar",
      "Akola",
      "Amravati",
      "Aurangabad",
      "Beed",
      "Bhandara",
      "Buldhana",
      "Chandrapur",
      "Dhule",
      "Gadchiroli",
      "Gondia",
      "Hingoli",
      "Jalgaon",
    ],
  },
  {
    value: "Manipur",
    label: "Manipur",
    districts: [
      "Bishnupur",
      "Chandel",
      "Churachandpur",
      "Imphal East",
      "Imphal West",
      "Senapati",
      "Tamenglong",
      "Thoubal",
      "Ukhrul",
    ],
  },
  {
    value: "Meghalaya",
    label: "Meghalaya",
    districts: [
      "East Garo Hills",
      "East Jaintia Hills",
      "East Khasi Hills",
      "North Garo Hills",
      "Ri Bhoi",
      "South Garo Hills",
      "South West Garo Hills",
      "South West Khasi Hills",
      "West Garo Hills",
      "West Jaintia Hills",
      "West Khasi Hills",
    ],
  },
  {
    value: "Mizoram",
    label: "Mizoram",
    districts: [
      "Aizawl",
      "Champhai",
      "Kolasib",
      "Lawngtlai",
      "Lunglei",
      "Mamit",
      "Saiha",
      "Serchhip",
    ],
  },
  {
    value: "Nagaland",
    label: "Nagaland",
    districts: [
      "Dimapur",
      "Kiphire",
      "Kohima",
      "Longleng",
      "Mokokchung",
      "Mon",
      "Peren",
      "Phek",
      "Tuensang",
      "Wokha",
      "Zunheboto",
    ],
  },
  {
    value: "Odisha",
    label: "Odisha",
    districts: [
      "Angul",
      "Balangir",
      "Balasore",
      "Bargarh",
      "Bhadrak",
      "Boudh",
      "Cuttack",
      "Deogarh",
      "Dhenkanal",
      "Gajapati",
      "Ganjam",
      "Jagatsinghpur",
      "Jajpur",
    ],
  },
  {
    value: "Punjab",
    label: "Punjab",
    districts: [
      "Amritsar",
      "Barnala",
      "Bathinda",
      "Faridkot",
      "Fatehgarh Sahib",
      "Fazilka",
      "Ferozepur",
      "Gurdaspur",
      "Hoshiarpur",
      "Jalandhar",
    ],
  },
  {
    value: "Rajasthan",
    label: "Rajasthan",
    districts: [
      "Ajmer",
      "Alwar",
      "Banswara",
      "Baran",
      "Barmer",
      "Bharatpur",
      "Bhilwara",
      "Bikaner",
      "Bundi",
      "Chittorgarh",
      "Churu",
      "Dausa",
      "Dholpur",
    ],
  },
  {
    value: "Sikkim",
    label: "Sikkim",
    districts: ["East Sikkim", "North Sikkim", "South Sikkim", "West Sikkim"],
  },
  {
    value: "Tamil Nadu",
    label: "Tamil Nadu",
    districts: [
      "Chennai",
      "Coimbatore",
      "Cuddalore",
      "Dharmapuri",
      "Dindigul",
      "Erode",
      "Kanchipuram",
      "Kanyakumari",
      "Karur",
      "Madurai",
      "Nagapattinam",
      "Namakkal",
    ],
  },
  {
    value: "Telangana",
    label: "Telangana",
    districts: [
      "Adilabad",
      "Bhadradri Kothagudem",
      "Hyderabad",
      "Jagtial",
      "Jangaon",
      "Jayashankar Bhupalpally",
      "Jogulamba Gadwal",
      "Kamareddy",
      "Karimnagar",
    ],
  },
  {
    value: "Tripura",
    label: "Tripura",
    districts: [
      "Dhalai",
      "Gomati",
      "Khowai",
      "North Tripura",
      "Sepahijala",
      "South Tripura",
      "Unakoti",
      "West Tripura",
    ],
  },
  {
    value: "Uttar Pradesh",
    label: "Uttar Pradesh",
    districts: [
      "Agra",
      "Aligarh",
      "Allahabad",
      "Ambedkar Nagar",
      "Amethi",
      "Amroha",
      "Auraiya",
      "Azamgarh",
      "Baghpat",
      "Bahraich",
    ],
  },
  {
    value: "Uttarakhand",
    label: "Uttarakhand",
    districts: [
      "Almora",
      "Bageshwar",
      "Chamoli",
      "Champawat",
      "Dehradun",
      "Haridwar",
      "Nainital",
      "Pauri Garhwal",
      "Pithoragarh",
      "Rudraprayag",
    ],
  },
  {
    value: "West Bengal",
    label: "West Bengal",
    districts: [
      "Alipurduar",
      "Bankura",
      "Birbhum",
      "Cooch Behar",
      "Dakshin Dinajpur",
      "Darjeeling",
      "Hooghly",
      "Howrah",
      "Jalpaiguri",
      "Jhargram",
    ],
  },
];
export const getDistrictsByState = (state) => {
  const stateObj = IndianStates.find((s) => s.value === state);
  return stateObj ? stateObj.districts : [];
};

// Stage II Start
export const UPDATE_BUILDING_DETAILS = "UPDATE_BUILDING_DETAILS";
export const UPDATE_ELECTRICTY_CONNECTION_DETAILS =
  "UPDATE_ELECTRICTY_CONNECTION_DETAILS";

// Stage II End

// Form Applicant Entity Details
export const UPDATE_ENTITY_DETAILS = "UPDATE_ENTITY_DETAILS";
export const UPDATE_PURPOSED_INSTI_INFO = "UPDATE_PURPOSED_INSTI_INFO";

// Details of Trade(s)/Unit(s) for Affiliation
export const ADD_MORE_TRADE = "ADD_MORE_TRADE";
export const UPDATE_TRADE_UNIT = "UPDATE_TRADE_UNIT";

// Details of the Land to be used for the ITI
export const UPDATE_LAND_INFO = "UPDATE_LAND_INFO";

export const UPDATE_LAND_DOCUMENT_INFO = "UPDATE_LAND_DOCUMENT_INFO";
export const ADD_MORE_LAND_DOCUMENT = "ADD_MORE_LAND_DOCUMENT";

export const UPDATE_LEASE_DEED_DOCUMENT_INFO =
  "UPDATE_LEASE_DEED_DOCUMENT_INFO";
export const ADD_MORE_LEASE_DOCUMENT = "ADD_MORE_LEASE_DOCUMENT";

export const LANGUAGES = [
  "Hindi",
  "English",
  "Bengali",
  "Telugu",
  "Marathi",
  "Tamil",
  "Urdu",
  "Gujarati",
  "Kannada",
  "Odia",
  "Malayalam",
  "Punjabi",
];
export const languages = [
  "",
  "Hindi",
  "English",
  "Bengali",
  "Telugu",
  "Marathi",
  "Tamil",
  "Urdu",
  "Gujarati",
  "Kannada",
  "Odia",
  "Malayalam",
  "Punjabi",
];

export const ACTIVE = "ACTIVE";
export const IN_ACTIVE = "IN_ACTIVE";



export const ID_Proof_Doc_list = [
  "Aadhaar Card",
  "PAN Card",
  "Passport",
  "Voter ID Card",
  "Driving License",
];

export const designation = ["Secretary", "Chairperson", "President"];

export const ctsTrades = [
  "Select Trade",
  "Electrician",
  "Fitter",
  "Turner",
  "Machinist",
  "Welder (Gas and Electric)",
  "Mechanic (Motor Vehicle)",
  "Mechanic Diesel",
  "Electronics Mechanic",
  "Refrigeration and Air Conditioning Technician",
  "Instrument Mechanic",
  "Information & Communication Technology System Maintenance",
  "Computer Operator and Programming Assistant (COPA)",
  "Draughtsman (Mechanical)",
  "Draughtsman (Civil)",
  "Wireman",
  "Surveyor",
  "Tool and Die Maker (Press Tools, Jigs & Fixtures)",
  "Plumber",
  "Carpenter",
  "Foundryman",
  "Painter (General)",
  "Sheet Metal Worker",
  "Mechanic (Tractor)",
  "Mechanic (Auto Electrical and Electronics)",
  "Fashion Design & Technology",
  "Dress Making",
  "Stenographer & Secretarial Assistant (English)",
  "Stenographer & Secretarial Assistant (Hindi)",
  "Baker and Confectioner",
  "Food Production (General)",
  "Health Sanitary Inspector",
  "Hair & Skin Care",
  "Sewing Technology",
];

// export const AffiliationCategory = [
//   { name: "Application for Establishment of New ITIs", master: "01" },
//   {
//     name: "Application for opening Mini Skill Training Institute",
//     master: "02",
//   },
//   {
//     name: "Establishment of New Age ITIs or Adoption of existing ITIs by industry entities",
//     master: "03",
//   },
//   {
//     name: "Application for Existing ITIs",
//     master: "04",
//     subCate: [
//       { name: "Addition of New Trades/Units", master: "01" },
//       { name: "Name Change of the ITI", master: "02" },
//       { name: "Shifting/Relocation or Merger of ITIs", master: "03" },
//       {
//         name: "SCVT to NCVET conversion of Trades (for existing Government ITIs)",
//         master: "04",
//       },
//       { name: "Renewal of Affiliation", master: "05" },
//       {
//         name: "Affiliation under the Dual System of Training (DST)",
//         master: "06",
//       },
//       { name: "Surrender of Trade/Units", master: "07" },
//     ],
//   },
// ];
export const AffiliationCategory = [
  { name: "Application for Establishment of New ITIs", master: "01" },
  {
    name: "Application for opening Mini Skill Training Institute",
    master: "02",
  },
  {
    name: "Establishment of New Age ITIs or Adoption of existing ITIs by industry entities",
    master: "03",
  },
  {
    name: "Affiliation under the Dual System of Training (DST)",
    master: "04",
  },
  { name: "Surrender of Trade/Units", master: "05" },
  {
    name: "Application for Existing ITIs",
    master: "06",
    subCate: [
      { name: "Addition of New Trades/Units", master: "01" },
      { name: "Name Change of the ITI", master: "02" },
      { name: "Shifting/Relocation", master: "03" },
      { name: "Merger of ITIs", master: "04" },
      {
        name: "SCVT to NCVET conversion of Trades (for existing Government ITIs)",
        master: "05",
      },
      { name: "Renewal of Affiliation", master: "06" },
    ],
  },
];

export const UPDATE_SET_FEE_STATUS = "UPDATE_SET_FEE_STATUS";
export const UPDATE_STAGE_II_SET_FEE_STATUS = "UPDATE_STAGE_II_SET_FEE_STATUS";

export const UPDATE_STAGE_I_FEE_PAID = "UPDATE_STAGE_I_FEE_PAID";
export const UPDATE_STAGE_II_FEE_PAID = "UPDATE_STAGE_II_FEE_PAID";
export const SET_STAGE_I__DOCUMENT_STATUS = "SET_STAGE_I__DOCUMENT_STATUS";

// App Flow
export const STAGE_I__NOT_FILLED = "STAGE_I__NOT_FILLED";
export const STAGE_I__FILLED = "STAGE_I__FILLED";
export const STAGE_II__FILLED = "STAGE_II__FILLED";
export const STAGE_II__ON_PROGRESS = "STAGE_II__ON_PROGRESS";
export const STAGE_II__PENDING = "STAGE_II__PENDING";

export const STAGE_I__FEE_PENDING = "STAGE_I__FEE_PENDING";
export const STAGE_II__FEE_PENDING = "STAGE_II__FEE_PENDING";

export const STAGE_I__FEE_PAID = "STAGE_I__FEE_PAID";
export const STAGE_II__FEE_PAID = "STAGE_II__FEE_PAID";

export const STAGE_I__FEE_EXEMPTED = "STAGE_I__FEE_EXEMPTED";
export const STAGE_II__FEE_EXEMPTED = "STAGE_II__FEE_EXEMPTED";

export const STAGE_I__DOCUMENT_PENDING = "STAGE_I__DOCUMENT_PENDING";
export const STAGE_II__DOCUMENT_PENDING = "STAGE_I__DOCUMENT_PENDING";
export const STAGE_II__DOCUMENT_UPLOADED = "STAGE_II__DOCUMENT_UPLOADED";

export const STAGE_I__DOCUMENT_UPLOADED = "STAGE_I__DOCUMENT_UPLOADED";

export const STAGE_I__SUBMIT_PENDING = "STAGE_I__SUBMIT_PENDING";
export const STAGE_II__SUBMIT_PENDING = "STAGE_II__SUBMIT_PENDING";
export const STAGE_II__SUBMITED = "STAGE_II__SUBMITED";

export const STAGE_I__SUBMITED = "STAGE_I__SUBMITED";

// export const STAGE_I__APP_SUBMIT_PENDING = "STAGE_I__APP_SUBMIT_PENDING";
// export const STAGE_I__APP_SUBMITED = "STAGE_I__APP_SUBMITED";
export const STAGE_I__ASSESSMENT_PENDING = "STAGE_I__ASSESSMENT_PENDING";
export const STAGE_I__ASSESSMENT_ON_PROGRESS = "STAGE_I__ASSESSMENT_ON_PROGRESS";
export const STAGE_I__ASSESSMENT_COMPLETED = "STAGE_I__ASSESSMENT_COMPLETED";

// export const AppFlow = {
//   feepaid: {
//     status: "Paid", // Paid | Un-paid
//   },
// };

export const STAGE_I_FORM_FILLING = "STAGE_I_FORM_FILLING";

export const STAGE_II_FORM_FILLING = "STAGE_II_FORM_FILLING";

export const STAGE_I_FEE = "STAGE_I_FEE";
export const STAGE_II_FEE = "STAGE_II_FEE";

export const STAGE_I_DOCUMENT_UPLAOD = "STAGE_I_DOCUMENT_UPLAOD";
export const STAGE_I_SUBMIT = "STAGE_I_SUBMIT";
export const STAGE_I__ASSESSMENT = "STAGE_I__ASSESSMENT";

// @dpkdhariwal old
// export const AppFlow = [
//   {
//     step: STAGE_I_FORM_FILLING,
//     status: STAGE_I__NOT_FILLED, // STAGE_I__FILLED || STAGE_I__NOT_FILLED
//   },
//   {
//     step: STAGE_I_FEE,
//     status: STAGE_I__FEE_PENDING, //  STAGE_I__FEE_PENDING || STAGE_I__FEE_PAID || STAGE_I__FEE_EXEMPTED
//   },
//   {
//     step: STAGE_I_DOCUMENT_UPLAOD,
//     status: STAGE_I__DOCUMENT_PENDING, // STAGE_I__DOCUMENT_PENDING|| STAGE_I__DOCUMENT_UPLOADED
//   },
//   {
//     step: STAGE_I_SUBMIT,
//     status: STAGE_I__SUBMIT_PENDING, // STAGE_I__SUBMIT_PENDING || STAGE_I__SUBMITED
//   },
//   {
//     step: STAGE_I__ASSESSMENT,
//     status: STAGE_I__ASSESSMENT_PENDING, // STAGE_I__ASSESSMENT_PENDING || STAGE_I__ASSESSMENT_ON_PROGRESS || STAGE_I__ASSESSMENT_COMPLETED
//   },
// ];

export const NOC_ISSUANCE = "NOC_ISSUANCE";
export const NOC_ISSUANCE_ISSUED = "NOC_ISSUANCE_ISSUED";
export const NOC_ISSUANCE_PENDING = "NOC_ISSUANCE_PENDING";
export const NOC_ISSUANCE_REJECTED = "NOC_ISSUANCE_REJECTED";

export const STAGE_II__NOT_FILLED = "STAGE_II__NOT_FILLED";
export const STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS =
  "STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS";
export const STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_PENDING =
  "STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_PENDING";
export const STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_COMPLETED =
  "STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_COMPLETED";
export const STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_ON_PROGRESS =
  "STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_ON_PROGRESS";
export const STAGE_II_DOCUMENT_UPLAOD = "STAGE_II_DOCUMENT_UPLAOD";
export const STAGE_II_SUBMIT = "STAGE_II_SUBMIT";
export const STAGE_II__ASSESSMENT = "STAGE_II__ASSESSMENT";
export const STAGE_II__ASSESSMENT_PENDING = "STAGE_II__ASSESSMENT_PENDING";
export const STAGE_II__ASSESSMENT_ON_PROGRESS =
  "STAGE_II__ASSESSMENT_ON_PROGRESS";
export const STAGE_II__ASSESSMENT_COMPLETED = "STAGE_II__ASSESSMENT_COMPLETED";
export const STAFF_DETAILS = "STAFF_DETAILS";
export const STAFF_DETAILS_PENDING = "STAFF_DETAILS_PENDING";
export const STAFF_DETAILS_COMPLETED = "STAFF_DETAILS_COMPLETED";
export const INSP_SLOT_SELECTION = "INSP_SLOT_SELECTION";
export const INSP_SLOT_SELECTION_PENDING = "INSP_SLOT_SELECTION_PENDING";
export const INSP_SLOT_SELECTION_COMPLETED = "INSP_SLOT_SELECTION_COMPLETED";
export const INSPENCTION = "INSPENCTION";
export const INSP_SHEDULED = "INSP_SHEDULED";
export const INSP_PENDING = "INSP_PENDING";

export const AppFlow = [
  {
    appId: null,
    userId: null,
    stepNo: 1,
    step: STAGE_I_FORM_FILLING,
    status: STAGE_I__NOT_FILLED, // STAGE_I__FILLED || STAGE_I__PENDING || ON_PROGRESS
    stepStatus: "pending", // inactive || pending || completed || on-progress
    stepTitle: "Stage I Form Filling",
    stepMsg: "Applicant Has to fill stage I Form",
    // stepMsgCompleted: "Stage I Form Completed",
    // stepMsgOnProgress: "stage I Form Filling On Progress",
    assignedTo: ["applicant"],
    actor: "applicant",
    nextStep: STAGE_I_FEE,
  },
  {
    appId: null,
    userId: null,
    stepNo: 2,
    step: STAGE_I_FEE,
    status: STAGE_I__FEE_PENDING, //  STAGE_I__FEE_PENDING || STAGE_I__FEE_PAID || STAGE_I__FEE_EXEMPTED
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "Stage I Fee",
    stepMsg: "Applicant Has to Pay Stage I Fee",
    assignedTo: ["applicant"],
    actor: "applicant",
    nextStep: STAGE_I_DOCUMENT_UPLAOD,
  },
  {
    appId: null,
    userId: null,
    stepNo: 3,
    step: STAGE_I_DOCUMENT_UPLAOD,
    status: STAGE_I__DOCUMENT_PENDING, // STAGE_I__DOCUMENT_PENDING || STAGE_I__DOCUMENT_UPLOADED
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "Stage I Document Upload",
    stepMsg: "Applicant Has to Upload Stage I Documents",
    assignedTo: ["applicant"],
    actor: "applicant",
    nextStep: STAGE_I_SUBMIT,
  },
  {
    appId: null,
    userId: null,
    stepNo: 4,
    step: STAGE_I_SUBMIT,
    status: STAGE_I__SUBMIT_PENDING, // STAGE_I__SUBMIT_PENDING || STAGE_I__SUBMITED
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "Stage I Submit",
    stepMsg: "Applicant Has to Submit Stage I Application",
    assignedTo: ["applicant"],
    actor: "applicant",
    nextStep: STAGE_I__ASSESSMENT,
  },
  {
    appId: null,
    userId: null,
    stepNo: 5,
    step: STAGE_I__ASSESSMENT,
    status: STAGE_I__ASSESSMENT_PENDING, // STAGE_I__ASSESSMENT_PENDING || STAGE_I__ASSESSMENT_ON_PROGRESS || STAGE_I__ASSESSMENT_COMPLETED
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "Stage I Verification",
    stepMsg: "State Has to Verify Stage I Application",
    assignedTo: ["state"],
    actor: "state",
    nextStep: NOC_ISSUANCE,
  },
  {
    appId: null,
    userId: null,
    stepNo: 6,
    step: NOC_ISSUANCE,
    status: NOC_ISSUANCE_PENDING, // NOC_ISSUANCE_ISSUED || NOC_ISSUANCE_PENDING || NOC_ISSUANCE_REJECTED
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "NOC Issuance",
    stepMsg: "State Has to Issue No Objection Certificate (NOC)",
    assignedTo: ["state"],
    actor: "state",

    nextStep: STAGE_II_FORM_FILLING,
  },
  {
    appId: null,
    userId: null,
    stepNo: 7,
    step: STAGE_II_FORM_FILLING,
    status: STAGE_II__PENDING, // STAGE_II__FILLED || STAGE_II__PENDING || STAGE_II__ON_PROGRESS
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "Stage II Form Filling",
    stepMsg: "Applicant Has to fill stage II Form",
    assignedTo: ["applicant"],
    actor: "applicant",

    nextStep: STAGE_II_FEE,
  },
  {
    appId: null,
    userId: null,
    stepNo: 8,
    step: STAGE_II_FEE,
    status: STAGE_II__FEE_PENDING, //  STAGE_II__FEE_PENDING || STAGE_II__FEE_PAID || STAGE_II__FEE_EXEMPTED
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "Stage II Fee",
    stepMsg: "Applicant Has to Pay Stage II Fee",
    assignedTo: ["applicant"],
    actor: "applicant",

    nextStep: STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS,
  },
  {
    appId: null,
    userId: null,
    stepNo: 9,
    step: STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS,
    status: STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_PENDING, // STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_PENDING || STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_COMPLETED || STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_ON_PROGRESS
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "Stage II Machine Equipment Tool Details",
    stepMsg: "Applicant Has to fill Stage II Machine Equipment Tool Details",
    assignedTo: ["applicant"],
    actor: "applicant",

    nextStep: STAGE_II_DOCUMENT_UPLAOD,
  },
  {
    appId: null,
    userId: null,
    stepNo: 10,
    step: STAGE_II_DOCUMENT_UPLAOD,
    status: STAGE_II__DOCUMENT_PENDING, // STAGE_II__DOCUMENT_PENDING || STAGE_II__DOCUMENT_UPLOADED
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "Stage II Document Upload",
    stepMsg: "Applicant Has to Upload Stage II Documents",
    assignedTo: ["applicant"],
    actor: "applicant",

    nextStep: STAGE_II_SUBMIT,
  },
  {
    appId: null,
    userId: null,
    stepNo: 11,
    step: STAGE_II_SUBMIT,
    status: STAGE_II__SUBMIT_PENDING, // STAGE_II__SUBMIT_PENDING || STAGE_II__SUBMITED
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "Stage II Application Submit",
    stepMsg: "Applicant Has to Submit Stage II Application",
    assignedTo: ["applicant"],
    actor: "applicant",

    nextStep: STAGE_II__ASSESSMENT,
  },
  {
    appId: null,
    userId: null,
    stepNo: 12,
    step: STAGE_II__ASSESSMENT,
    status: STAGE_II__ASSESSMENT_PENDING, // STAGE_II__ASSESSMENT_PENDING || STAGE_II__ASSESSMENT_ON_PROGRESS || STAGE_II__ASSESSMENT_COMPLETED
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "Stage II Assessment",
    stepMsg: "State has to Assess Stage II Application",
    assignedTo: ["state"],
    actor: "state",

    nextStep: STAFF_DETAILS,
  },
  {
    appId: null,
    userId: null,
    stepNo: 13,
    step: STAFF_DETAILS,
    status: STAFF_DETAILS_PENDING, // STAFF_DETAILS_PENDING || STAFF_DETAILS_COMPLETED
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "Stage II Staff Detail",
    stepMsg: "Applicant Has to fill Staff Details",
    assignedTo: ["applicant"],
    actor: "applicant",

    nextStep: INSP_SLOT_SELECTION,
  },
  {
    appId: null,
    userId: null,
    stepNo: 14,
    step: INSP_SLOT_SELECTION,
    status: INSP_SLOT_SELECTION_PENDING, // INSP_SLOT_SELECTION_PENDING || INSP_SLOT_SELECTION_COMPLETED
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "Inspection Slot Selection",
    stepMsg: "Applicant Has to Select Inspection Slot",
    assignedTo: ["applicant"],
    actor: "applicant",

    nextStep: INSPENCTION,
  },
  {
    appId: null,
    userId: null,
    stepNo: 15,
    step: INSPENCTION,
    status: INSP_PENDING, // INSP_PENDING || INSP_SHEDULED || INSPECTED || INSP_RE_SHEDULED || RE_INSPECTED
    stepStatus: "inactive", // inactive || pending || completed || on-progress
    stepTitle: "Inspection",
    stepMsg: "ITI Institute Inspection",
    assignedTo: ["RDSDE"],
    actor: "RDSDE",
    nextStep: LAST,

  },
];

export const tradeList = [
  {
    tradeId: "tradeId01",
    tradeName: "Fitter",
    UnitStrength: 20,
    WorkshopAreaRequirment: 88,
    WorkshopAreaUnit: 'sq.m',
    PowerNorms: 3.51,
    PowerUnit: 'KW',
    unitInShift1: 2,
    unitInShift2: 1,
    unitInShift3: 0,
  },
  {
    tradeId: "tradeId02",
    tradeName: "Electrician",
    UnitStrength: 20,
    WorkshopAreaRequirment: 98,
    WorkshopAreaUnit: 'sq.m',
    PowerNorms: 3,
    PowerUnit: 'KW',
    unitInShift1: 2,
    unitInShift2: 1,
    unitInShift3: 0,
  },
];

export const work_shop_list = () => {
  const workshopRequired = 2;
  const workshopList = [];

  for (let i = 1; i <= workshopRequired; i++) {
    tradeList.forEach((trade) => {
      workshopList.push({
        ...trade,
        Particulars: 'Workshop ' + i,
        Required_Area_As_per_norms: trade.WorkshopAreaRequirment,
        WorkshopAreaUnit: trade.WorkshopAreaUnit,
      });
    });
  }

  return workshopList.sort((a, b) => a.tradeName.localeCompare(b.tradeName));
};

// Workshop Information to be filled Start
export const work_shop_info_to_be_filled = [
  {
    tradeId: "tradeId01",
    tradeName: "Fitter",
    Particulars: "Workshop 1",
    Required_Area_As_per_norms: "100sqm",
  },
  {
    tradeId: "tradeId02",
    tradeName: "Fitter",
    Particulars: "Workshop 2",
    Required_Area_As_per_norms: "200sqm",
  },
];
export const UPDATE_TRADEWISE_WORKSHOP_DETAILS = "UPDATE_TRADEWISE_WORKSHOP_DETAILS";


// Classroom Information to be filled Start
export const classrooms_info_to_be_filled = [
  {
    tradeId: "tradeId01",
    tradeName: "Fitter",
    Particulars: "Classroom 1",
    Required_Area_As_per_norms: "200sqm",
  },
  {
    tradeId: "tradeId02",
    tradeName: "Fitter",
    Particulars: "Classroom 2",
    Required_Area_As_per_norms: "400sqm",
  },
];
export const UPDATE_TRADEWISE_CLASSROOMS_DETAILS =
  "UPDATE_TRADEWISE_CLASSROOMS_DETAILS";
// Classroom Information to be filled End

// Multipurpose Hall Information to be filled Start
export const multipurposehall_info_to_be_filled = [
  {
    Particulars: "Multipurpose Hall",
    Required_Area_As_per_norms: "200sqm",
  },
];
export const UPDATE_MULTIPURPOSEHALL_DETAILS =
  "UPDATE_TRADEWISE_MULTIPURPOSEHALL_DETAILS";
// Multipurpose Hall Information to be filled End

// IT Lab Information to be filled Start
export const it_lab_info_to_be_filled = [
  {
    Particulars: "IT Lab",
    Required_Area_As_per_norms: "200sqm",
  },
];
export const UPDATE_IT_LAB_DETAILS = "UPDATE_IT_LAB_DETAILS";
// IT Lab Information to be filled End

// Library Information to be filled Start
export const it_library_to_be_filled = [
  {
    Particulars: "Library",
    Required_Area_As_per_norms: "200sqm",
  },
];
export const UPDATE_LIBRARY_DETAILS = "UPDATE_LIBRARY_DETAILS";
// Library Information to be filled End

// Placement and Counselling room Information to be filled Start
export const placement_n_counselling_room_to_be_filled = [
  {
    Particulars: "Placement and Counselling Room",
    Required_Area_As_per_norms: "200sqm",
  },
];
export const UPDATE_PLACEMENT_N_COUNSELLING_ROOM_DETAILS =
  "UPDATE_LIBRARY_DETAILS";
// Placement and Counselling room Information to be filled End

// Placement and Counselling room Information to be filled Start
export const administrativeArea = [
  {
    Particulars: "Principal Room",
    Required_Area_As_per_norms: "20 sq. m",
  },
  {
    Particulars: "Reception cum waiting lobby",
    Required_Area_As_per_norms: "40 sq. m",
  },
  {
    Particulars: "Staff Room",
    Required_Area_As_per_norms: "20 sq. m",
  },
  {
    Particulars: "Administrative Hall/Section",
    Required_Area_As_per_norms: "50 sq. m",
  },
];
export const UPDATE_ADMINISTRATIVE_AREA_DETAILS = "UPDATE_LIBRARY_DETAILS";
// Placement and Counselling room Information to be filled End

// Stage II Document Upload Start
export const UPDATE_STAGE_II_DOCUMENT_UPLOAD =
  "UPDATE_STAGE_II_DOCUMENT_UPLOAD";

export const geo_tagged_photo_of_machinery_tools_equipments = [
  {
    tradeId: "tradeId01",
    tradeName: "Fitter",
    unit: 1,
    Particulars: "Machinery/Tools/Equipments",
  },
  {
    tradeId: "tradeId02",
    tradeName: "Fitter",
    unit: 1,
    Particulars: "Machinery/Tools/Equipments",
  },
  {
    tradeId: "tradeId01",
    tradeName: "Electrician",
    unit: 1,
    Particulars: "Machinery/Tools/Equipments",
  },
  {
    tradeId: "tradeId02",
    tradeName: "Electrician",
    unit: 1,
    Particulars: "Machinery/Tools/Equipments",
  },
];

export const gst_invoices_for_major_machinery_purchase_and_payment_proof = [
  {
    tradeId: "tradeId01",
    tradeName: "Fitter",
    Particulars: "MTE Purchase Bills",
  },
  {
    tradeId: "tradeId02",
    tradeName: "Electrician",
    Particulars: "MTE Purchase Bills",
  },
];
// Stage II Document Upload End

export const STEPPER_STYLE = {
  LineSeparator: () => ({
    backgroundColor: "#8a3b02ff",
  }),
  InActiveNode: () => ({
    backgroundColor: "#8a3b02ff",
    width: "30px",
    height: "30px",
  }),
  ActiveNode: () => ({
    backgroundColor: "#f40000f3",
    width: "30px",
    height: "30px",
    border: "2px solid #470d0df3",
    fontSize: "large",
    // borderStyle: "double",
    // borderWidth: "thick"
  }),

  CompletedNode: () => ({
    backgroundColor: "#028A0F",
    width: "30px",
    height: "30px",
    fontSize: "large",
  }),
  InactiveLineSeparator: (step, stepIndex) => {
    console.log(step, stepIndex);
    return {
      backgroundColor: "#8a0202ff",
    };
  },
  Node: (step, stepIndex) => {
    switch (step.status) {
      case FILLED:
        return { backgroundColor: "#8a0202ff" };
      default:
        break;
    }
  },
};

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
// Database Stores 

export const DB_VERSION = 36;
export const DB_NAME = "AffliationDB";
export const USERS = "users";
export const USER_ROLES = "userroles";
export const APPLIST = "apps";


export const ENTITY_DETAILS_VIEW = "entity_details_view";

export const ENTITY_DETAILS = "ent_entitydetails";

export const ENTITY_ADDRESS = "ent_entityaddress";
export const OTHER_ITI = "ent_otheriti";

export const PROPOSED_INSTI_DETAILS = "proposed_proposedinstitutedetails";
export const PROPOSED_INSTI_ADDRESSES = "proposed_proposedinstituteaddressesdetails";



export const TBL_MASTER_ID_PROOF_LIST = "master_id_proof_list";
export const TBL_MASTER_DESIGNATION = "master_designation";



export const TBL_LANGUAGES = "languages";

export const NEW_INSTI_TRADE_LIST = "trades_newinsttrades";
export const TRADE_INFO_VIEW = "trade_info_view";



export const LAND_INST_DETAILS = "land_landinstdetail";
export const LAND_OWNED_LANDS_DETAILS = "land_owned_lands";
export const LAND_LEASED_LANDS_DETAILS = "land_leased_lands";

export const APP_FLOW = "app_flow";
export const APP_FORM_FLOW_STAGE_I = "form_flow_stage_i";
export const APP_ASSESSMENT_FLOW_STAGE_I = "app_assessment_flow_stage_i";
export const APP_ASSESSMENT_FLOW_STAGE_II = "app_assessment_flow_stage_ii";


export const APP_FORM_FLOW_STAGE_II = "form_flow_stage_ii";
export const APP_FORM_SUB_CIVIL_INFRA = "app_form_sub_civil_infra";

export const BLD_DETAIL = "bld_details";
export const BLD_BUILDING_PLAN = "bld_building_plan";
export const BLD_BCC = "bld_bcc";
export const BLD_PHOTOS = "bld_photos";
// Photo Types
export const FRONT_VIEW_PHOTO_OF_BUILDING = "front_view_photo_of_building";
export const SIDE_VIEW_PHOTO_OF_BUILDING = "side_view_photo_of_building";
export const ENTRANCE_GATE_PHOTO_OF_PLOT_WITH_SIGNAGE_BOARD = "entrance_gate_photo_of_plot_with_signage_board";

// export const Civil_Infrastructure_Detail = "Civil Infrastructure Detail";
// export const Civil_Infrastructure_Detail = "Civil Infrastructure Detail";
export const TRADEWISE_WORKSHOP = "tradewise_workshop";
export const TRADEWISE_CLASSROOMS = "tradewise_classrooms";
export const COMMON_CIVIL_INFRASTRUCTURE = "common_civil_infrastructure";


// Desktop Assessment Table
export const DA_LAND_DOCUMENTS = "da_land_documents";
export const DA_STAGE_I_VERIFICATIONS = "da_stage_i_verifications";

// Sample Assessment Obj
export const TBL_ASSESSMENTS_STATUS = "assessment_status";

export const NOCs = "nocs";




export const SAMPLE_ASSESSMENTS_INITIAL_STATUS = {
  id: null,
  appId: null,
  stage: abbreviation.STAGE_I.key, // 'STAGE_I' | 'STAGE_II'
  assessment_id: null,
  assessment_status: SL.ON_PROGRESS, // 'COMPLETED' | 'ON_PROGRESS' | 'VERIFIED'
  pendingAt: SL.PENDING_AT_ASSESSOR, // 'PENDING_AT_APPLICANT' | 'PENDING_AT_ASSESSOR' | 'PENDING_AT_RDSDE'
};

export const DA_STAGE_I_VERIFICATIONS_CHECKLIST = "da_stage_i_verifications_checklist";
// Sample Users
export const SAMPLE_USERS = [
  {
    userType: "applicant",
    role: ["applicant"],
    email: "applicant@gmail.com",
    password: "123",
    total_applications: 0,
  },
  {
    userType: "rdsde",
    role: ["rdsde"],
    email: "rdsde@gmail.com",
    password: "123",
  },
  {
    userType: "dgt",
    role: ["dgt"],
    email: "dgt@gmail.com",
    password: "123",
  },
  {
    userType: "state_admin",
    role: ["state_admin"],
    email: "state_admin@gmail.com",
    password: "123",
  },
  {
    userType: "state_assessor",
    role: ["state_assessor"],
    email: "state_assessor@gmail.com",
    password: "123",
  },
  {
    userType: "state_assessor",
    role: ["test"],
    email: "vivek@gmail.com",
    password: "123",
  },
];

//------------------------------------------//



export const BUILDING_DETAIL = "Building Detail";
export const CIVIL_INFRASTRUCTURE_DETAIL = "Civil Infrastructure Detail";
export const AMENITIES_AREA = "Amenities Area";

export const SIGNAGE_BOARDS = "Signage Boards";
export const ELECTRICITY_CONNECTION_DETAILS = "Electricity Connection Details";
export const MISCELLANEOUS = "Miscellaneous";
export const FEE_PAYMENT_FOR_STAGEII = "Fee Payment For StageII";
export const TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS =
  "Tradewise Machinery/Tools/Equipment Details";
export const DOCUMENT_UPLOADS = "Document Uploads";

export const CIC = {
  TRADEWISE_WORKSHOP: "Tradewise Workshop",
  TRADEWISE_CLASSROOMS: "TradeWise Classrooms",
  MULTIPURPOSE_HALL: "Multipurpose hall",
  IT_LAB: "IT Lab",
  LIBRARY: "Library",
  PLACEMENT_AND_COUNSELLING_ROOM: "Placement and counselling room",
  ADMINISTRATIVE_AREA: "Administrative Area",
};
export const STAGE_II_APP_FORM_FLOW = [
  {
    stepNo: 1,
    step: BUILDING_DETAIL,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: "Building Detail",
    nextStep: CIVIL_INFRASTRUCTURE_DETAIL,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
  },
  {
    stepNo: 2,
    step: CIVIL_INFRASTRUCTURE_DETAIL,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: "Civil Infrastructure Detail",
    nextStep: AMENITIES_AREA,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
    subSteps: [
      {
        stepNo: 1,
        step: CIC.TRADEWISE_WORKSHOP,
        status: NOT_FILLED, // FILLED || NOT_FILLED 
        stepTitle: "Tradewise Workshop",
        nextStep: CIC.TRADEWISE_CLASSROOMS,
        stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE

      },
      {
        stepNo: 2,
        step: CIC.TRADEWISE_CLASSROOMS,
        status: NOT_FILLED, // NOT_FILLED
        stepTitle: "TradeWise Classrooms",
        nextStep: CIC.MULTIPURPOSE_HALL,
        stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
      },
      {
        stepNo: 3,
        step: CIC.MULTIPURPOSE_HALL,
        status: NOT_FILLED, // NOT_FILLED
        stepTitle: "Multipurpose hall",
        nextStep: CIC.IT_LAB,
        stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE

      },
      {
        stepNo: 4,
        step: CIC.IT_LAB,
        status: NOT_FILLED, // NOT_FILLED
        stepTitle: "IT Lab",
        nextStep: CIC.LIBRARY,
        stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE

      },
      {
        stepNo: 5,
        step: CIC.LIBRARY,
        status: NOT_FILLED, // NOT_FILLED
        stepTitle: "Library",
        nextStep: CIC.PLACEMENT_AND_COUNSELLING_ROOM,
        stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE

      },
      {
        stepNo: 6,
        step: CIC.PLACEMENT_AND_COUNSELLING_ROOM,
        status: NOT_FILLED, // NOT_FILLED
        stepTitle: "Placement and counselling room",
        nextStep: CIC.ADMINISTRATIVE_AREA,
        stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE

      },
      {
        stepNo: 8,
        step: CIC.ADMINISTRATIVE_AREA,
        status: NOT_FILLED, // NOT_FILLED
        stepTitle: "Administrative Area",
        nextStep: LAST,
        stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE

      },
    ],
  },
  {
    stepNo: 3,
    step: AMENITIES_AREA,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: "Amenities Area",
    nextStep: SIGNAGE_BOARDS,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
  },
  {
    stepNo: 4,
    step: SIGNAGE_BOARDS,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: "Signage Boards",
    nextStep: ELECTRICITY_CONNECTION_DETAILS,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE

  },
  {
    stepNo: 5,
    step: ELECTRICITY_CONNECTION_DETAILS,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: "Electricity Connection Details",
    nextStep: FEE_PAYMENT_FOR_STAGEII,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE

  },
  {
    stepNo: 6,
    step: FEE_PAYMENT_FOR_STAGEII,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: "Fee Payment For StageII",
    nextStep: TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE

  },
  {
    stepNo: 7,
    step: TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: "Tradewise Machinery/Tools/Equipment Details",
    nextStep: DOCUMENT_UPLOADS,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
    subSteps: [
      {
        stepNo: 1,
        step: CIK.SPECIFICATIONS_OF_IT_LAB,
        status: NOT_FILLED, // FILLED || NOT_FILLED 
        stepTitle: "Fill Specifications of IT lab",
        nextStep: CIK.TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS,
        stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE

      },
      {
        stepNo: 2,
        step: CIK.TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS,
        status: NOT_FILLED, // NOT_FILLED
        stepTitle: "Fill Machinery/Tools/Equipment Details",
        nextStep: LAST,
        stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
      },
    ],
  },
  {
    stepNo: 8,
    step: DOCUMENT_UPLOADS,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: "Document Uploads",
    nextStep: LAST,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
  },
];

// Stage 1 Form Constants
export const ST1FC = {
  APPLICANT_ENTITY_DETAILS: {
    label: "Applicant Entity Details",
    step: "APPLICANT_ENTITY_DETAILS",
  },
  DETAILS_OF_THE_PROPOSED_INSTITUTE: {
    label: "Details of the Proposed Institute",
    step: "DETAILS_OF_THE_PROPOSED_INSTITUTE",
  },
  DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION: {
    label: "Details of Trade(s)/Unit(s) for Affiliation",
    step: "DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION",
  },
  DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI: {
    label: "Details of the Land to be used for the ITI",
    step: "DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI",
  },
  FEE_PAYMENT: { label: "Fee Payment", step: "FEE_PAYMENT" },
  DOCUMENTS_UPLOAD: { label: "Documents Upload", step: "DOCUMENTS_UPLOAD" },
  REVIEW_ASSESSMENT: { label: "Review Assessment", step: "REVIEW_ASSESSMENT" },
};

export const ST2FC = {
  BUILDING_DETAIL: { label: "Building Detail", step: "BUILDING_DETAIL" },
  CIVIL_INFRASTRUCTURE_DETAIL: { label: "Civil Infrastructure Detail", step: "CIVIL_INFRASTRUCTURE_DETAIL" },
  AMENITIES_AREA: { label: "Amenities Area", step: "AMENITIES_AREA" },
  SIGNAGE_BOARDS: { label: "Signage Boards", step: "SIGNAGE_BOARDS" },
  ELECTRICITY_CONNECTION_DETAILS: { label: "Electricity Connection Details", step: "ELECTRICITY_CONNECTION_DETAILS" },
  TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS: { label: "Tradewise Machinery Tools Equipment Details", step: "TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS" },
  REVIEW_ASSESSMENT: { label: "Review Assessment", step: "REVIEW_ASSESSMENT" },
};
export const STAGE_I_APP_FORM_FLOW = [
  {
    appId: null,
    userId: null,
    stepNo: 1,
    step: ST1FC.APPLICANT_ENTITY_DETAILS.step,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: ST1FC.APPLICANT_ENTITY_DETAILS.label,
    nextStep: ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step,
    submitDate: null,
    updateDate: null,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.CURRENT // CURRENT || PREVIOUS || HISTORY
  },
  {
    appId: null,
    userId: null,
    stepNo: 2,
    step: ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.label,
    nextStep: ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step,
    submitDate: null,
    updateDate: null,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.CURRENT // CURRENT || PREVIOUS || HISTORY
  },
  {
    appId: null,
    userId: null,
    stepNo: 3,
    step: ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.label,
    nextStep: ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step,
    submitDate: null,
    updateDate: null,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.CURRENT // CURRENT || PREVIOUS || HISTORY
  },
  {
    appId: null,
    userId: null,
    stepNo: 4,
    step: ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.label,
    nextStep: ST1FC.FEE_PAYMENT.step,
    submitDate: null,
    updateDate: null,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.CURRENT // CURRENT || PREVIOUS || HISTORY

  },
  {
    appId: null,
    userId: null,
    stepNo: 5,
    step: ST1FC.FEE_PAYMENT.step,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: ST1FC.FEE_PAYMENT.label,
    nextStep: ST1FC.DOCUMENTS_UPLOAD.step,
    submitDate: null,
    updateDate: null,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.CURRENT // CURRENT || PREVIOUS || HISTORY

  },
  {
    appId: null,
    userId: null,
    stepNo: 6,
    step: ST1FC.DOCUMENTS_UPLOAD.step,
    status: NOT_FILLED, // NOT_FILLED
    stepLabel: ST1FC.DOCUMENTS_UPLOAD.label,
    nextStep: LAST,
    submitDate: null,
    updateDate: null,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.CURRENT // CURRENT || PREVIOUS || HISTORY

  },
];

export const DA1_KEYS = {
  LAND_DOCUMENT: "LAND_DOCUMENTS",
  LAND_AREA: "LAND_AREA",
  ID_PROOF_OF_AUTHORIZED_SIGNATORY: "ID Proof of Authorized Signatory",
  REGISTRATION_CERTIFICATE_OF_APPLICANT_ORGANIZATION: "Registration Certificate of Applicant Organization",
  ID_PROOF_OF_SECRETARY_CHAIRPERSON_PRESIDENT: "ID Proof of Secretary/Chairperson/President",
  RESOLUTION_CERTIFICATE: "Resolution Certificate"
}



export const DA2_KEYS = {
  // Building Infor
  BUILDING_PLAN: "BUILDING_PLAN",
  BUILDING_COMPLETION_CERTIFICATE: "BUILDING_COMPLETION_CERTIFICATE",
  BUILDING_PHOTOS: "BUILDING_PHOTOS",
  
  // Civil Infra
  MULTIPURPOSE_HALL: "MULTIPURPOSE_HALL",
  IT_LAB: "IT_LAB",
  LIBRARY: "LIBRARY",
  PLACEMENT_AND_COUNSELLING_ROOM: "PLACEMENT_AND_COUNSELLING_ROOM",
  PRINCIPAL_ROOM: "PRINCIPAL_ROOM",
  RECEPTION_CUM_WAITING_LOBBY: "RECEPTION_CUM",
  STAFF_ROOM: "STAFF_ROOM",
  ADMINISTRATIVE_HALL_SECTION: "ADMINISTRATIVE_HALL_SECTION",
  WORKSHOPS: "WORKSHOPS", // DYNAMIC
  CLASSROOMS: "CLASSROOMS"  //// DYNAMIC
}


// Assessment 
//1. Building Details 
export const asmt_building_details = [DA2_KEYS.BUILDING_PLAN, DA2_KEYS.BUILDING_COMPLETION_CERTIFICATE, DA2_KEYS.BUILDING_PHOTOS];

//2. Civil Infra 
export const asmt_civil_infra = [DA2_KEYS.MULTIPURPOSE_HALL, DA2_KEYS.IT_LAB, DA2_KEYS.LIBRARY, DA2_KEYS.PLACEMENT_AND_COUNSELLING_ROOM, DA2_KEYS.PRINCIPAL_ROOM, DA2_KEYS.RECEPTION_CUM_WAITING_LOBBY, DA2_KEYS.STAFF_ROOM, DA2_KEYS.ADMINISTRATIVE_HALL_SECTION, DA2_KEYS.WORKSHOPS, DA2_KEYS.CLASSROOMS];












// Workshop
// Workshop

const WORKSHOP_1 = "WORKSHOP_1";
const WORKSHOP_2 = "WORKSHOP_2";
const WORKSHOP_3 = "WORKSHOP_3";
const WORKSHOP_4 = "WORKSHOP_4";
const WORKSHOP_5 = "WORKSHOP_5";
const WORKSHOP_6 = "WORKSHOP_6";
const WORKSHOP_7 = "WORKSHOP_7";
const WORKSHOP_8 = "WORKSHOP_8";
const WORKSHOP_9 = "WORKSHOP_9";
const WORKSHOP_10 = "WORKSHOP_10";
const WORKSHOP_11 = "WORKSHOP_11";
const WORKSHOP_12 = "WORKSHOP_12";
const WORKSHOP_13 = "WORKSHOP_13";
const WORKSHOP_14 = "WORKSHOP_14";
const WORKSHOP_15 = "WORKSHOP_15";
const WORKSHOP_16 = "WORKSHOP_16";
const WORKSHOP_17 = "WORKSHOP_17";
const WORKSHOP_18 = "WORKSHOP_18";
const WORKSHOP_19 = "WORKSHOP_19";
const WORKSHOP_20 = "WORKSHOP_20";

export const WorkshopName = {
  0: WORKSHOP_1,
  1: WORKSHOP_2,
  2: WORKSHOP_3,
  3: WORKSHOP_4,
  4: WORKSHOP_5,
  5: WORKSHOP_6,
  6: WORKSHOP_7,
  7: WORKSHOP_8,
  8: WORKSHOP_9,
  9: WORKSHOP_10,
  10: WORKSHOP_11,
  11: WORKSHOP_12,
  12: WORKSHOP_13,
  13: WORKSHOP_14,
  14: WORKSHOP_15,
  15: WORKSHOP_16,
  16: WORKSHOP_17,
  17: WORKSHOP_18,
  18: WORKSHOP_19,
  19: WORKSHOP_20
}



// Classrooms
const CLASSROOM_1 = "CLASSROOM_1";
const CLASSROOM_2 = "CLASSROOM_2";
const CLASSROOM_3 = "CLASSROOM_3";
const CLASSROOM_4 = "CLASSROOM_4";
const CLASSROOM_5 = "CLASSROOM_5";
const CLASSROOM_6 = "CLASSROOM_6";
const CLASSROOM_7 = "CLASSROOM_7";
const CLASSROOM_8 = "CLASSROOM_8";
const CLASSROOM_9 = "CLASSROOM_9";
const CLASSROOM_10 = "CLASSROOM_10";
const CLASSROOM_11 = "CLASSROOM_11";
const CLASSROOM_12 = "CLASSROOM_12";
const CLASSROOM_13 = "CLASSROOM_13";
const CLASSROOM_14 = "CLASSROOM_14";
const CLASSROOM_15 = "CLASSROOM_15";
const CLASSROOM_16 = "CLASSROOM_16";
const CLASSROOM_17 = "CLASSROOM_17";
const CLASSROOM_18 = "CLASSROOM_18";
const CLASSROOM_19 = "CLASSROOM_19";
const CLASSROOM_20 = "CLASSROOM_20";

export const ClassroomName = {
  0: CLASSROOM_1,
  1: CLASSROOM_2,
  2: CLASSROOM_3,
  3: CLASSROOM_4,
  4: CLASSROOM_5,
  5: CLASSROOM_6,
  6: CLASSROOM_7,
  7: CLASSROOM_8,
  8: CLASSROOM_9,
  9: CLASSROOM_10,
  10: CLASSROOM_11,
  11: CLASSROOM_12,
  12: CLASSROOM_13,
  13: CLASSROOM_14,
  14: CLASSROOM_15,
  15: CLASSROOM_16,
  16: CLASSROOM_17,
  17: CLASSROOM_18,
  18: CLASSROOM_19,
  19: CLASSROOM_20
};





export const units = { sqm: "sq. m", };
// Common Area
export const MULTIPURPOSE_HALL = { particular: CIK.MULTIPURPOSE_HALL, RequiredArea: 110, AreaUnit: units.sqm, info: "Minimum width of multipurpose hall / courtyard shall be 5m." };
export const IT_LAB = { particular: CIK.IT_LAB, RequiredArea: 200, AreaUnit: units.sqm, info: "minimum width of multipurpose hall / courtyard shall be 5m." };
export const LIBRARY = { particular: CIK.LIBRARY, RequiredArea: 200, AreaUnit: units.sqm };
export const PLACEMENT_AND_COUNSELLING_ROOM = { particular: CIK.PLACEMENT_AND_COUNSELLING_ROOM, RequiredArea: 200, AreaUnit: units.sqm };

export const COMMON_AREA = [MULTIPURPOSE_HALL, IT_LAB, LIBRARY, PLACEMENT_AND_COUNSELLING_ROOM];

// Administrative Area
export const Principal_Room = { particular: CIK.PRINCIPAL_ROOM, RequiredArea: 200, AreaUnit: units.sqm };
export const Reception_cum_waiting_lobby = { particular: CIK.RECEPTION_CUM_WAITING_LOBBY, RequiredArea: 200, AreaUnit: units.sqm };
export const Staff_Room = { particular: CIK.STAFF_ROOM, RequiredArea: 200, AreaUnit: units.sqm };
export const Administrative_Hall_Section = { particular: CIK.ADMINISTRATIVE_HALL_SECTION, RequiredArea: 200, AreaUnit: units.sqm };
export const ADMINISTRATIVE_AREA = [Principal_Room, Reception_cum_waiting_lobby, Staff_Room, Administrative_Hall_Section]


// Amenities
export const AMNT = {
  LIBRARY_AND_READING_ROOM: "Library & reading room",
  FIRST_AID_ROOM: "First-Aid Room",
  PLAYGROUND: "Playground",
  DRINKING_WATER_FACILITY: "Drinking water facility",
  AVAILABILITY_OF_STAIRCASES: "Availability of staircases",
  TOILETS_WATER_CLOSETS: "Toilets/Water Closets",
  GENERAL_PARKING_DETAILS: "General Parking Details",
};
export const A_LIBRARY_AND_READING_ROOM = { key: 'LIBRARY_AND_READING_ROOM', particular: AMNT.LIBRARY_AND_READING_ROOM, RequiredArea: 200, AreaUnit: units.sqm };
export const A_FIRST_AID_ROOM = { key: 'FIRST_AID_ROOM', particular: AMNT.FIRST_AID_ROOM, RequiredArea: 200, AreaUnit: units.sqm };
export const AMENITIES_AREAS = [A_FIRST_AID_ROOM, A_LIBRARY_AND_READING_ROOM]



export const A_PLAYGROUND = {
  key: 'PLAYGROUND',
  particular: AMNT.PLAYGROUND,
  instruction: "Dedicated playground, as per Local Building Bye- Laws/NBC of India"
};
export const A_DRINKING_WATER_FACILITY = {
  key: 'DRINKING_WATER_FACILITY',
  particular: AMNT.DRINKING_WATER_FACILITY,
  instruction: "Institute shall provide treated drinking water facility at all floors and workshops as per the local building bye-laws/ Latest NBC of India "
};
export const A_AVAILABILITY_OF_STAIRCASES = {
  key: 'AVAILABILITY_OF_STAIRCASES',
  particular: AMNT.AVAILABILITY_OF_STAIRCASES,
  instruction: "As per local building bye-laws/As per latest National Building Code of India  "
};
export const A_TOILETS_WATER_CLOSETS = {
  key: 'TOILETS_WATER_CLOSETS',
  particular: AMNT.TOILETS_WATER_CLOSETS,
  instruction: "Institutes must provide separate toilets for staff, boys, girls and differently abled individuals as per local building bye-laws/NBC of India "
};
export const A_GENERAL_PARKING_DETAILS = {
  key: 'GENERAL_PARKING_DETAILS',
  particular: AMNT.GENERAL_PARKING_DETAILS,
  instruction: "The parking area should be provided as per local building bye-laws or as per the National Building Code for two-wheelers, bicycles etc. \n The parking area specified for different trades, such as Mechanic Diesel, in the workshop norms is separate from this general parking area."
};


export const AMENITIES_PARTICULARS = [A_FIRST_AID_ROOM, A_LIBRARY_AND_READING_ROOM, A_PLAYGROUND, A_DRINKING_WATER_FACILITY, A_AVAILABILITY_OF_STAIRCASES, A_TOILETS_WATER_CLOSETS, A_GENERAL_PARKING_DETAILS]




export const STAGE_II = {
  AppFormStepper: {
    BUILDING_DETAIL: { key: 'BUILDING_DETAIL', label: BUILDING_DETAIL },
    CIVIL_INFRASTRUCTURE_DETAIL: { key: 'CIVIL_INFRASTRUCTURE_DETAIL', label: CIVIL_INFRASTRUCTURE_DETAIL },
    AMENITIES_AREA: { key: 'AMENITIES_AREA', label: AMENITIES_AREA },
    SIGNAGE_BOARDS: { key: 'SIGNAGE_BOARDS', label: SIGNAGE_BOARDS },
    ELECTRICITY_CONNECTION_DETAILS: { key: 'ELECTRICITY_CONNECTION_DETAILS', label: ELECTRICITY_CONNECTION_DETAILS },
    MISCELLANEOUS: { key: 'MISCELLANEOUS', label: MISCELLANEOUS },
    FEE_PAYMENT_FOR_STAGEII: { key: 'FEE_PAYMENT_FOR_STAGEII', label: FEE_PAYMENT_FOR_STAGEII },
    TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS: {
      key: 'TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS',
      label: TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS
    },
    DOCUMENT_UPLOADS: { key: 'DOCUMENT_UPLOADS', label: DOCUMENT_UPLOADS },
  }
};




export const ASSESSMENT_STAGE_II_FLOW = [
  {
    stepNo: 1,
    stepLabel: "Building Detail",
    step: BUILDING_DETAIL,
    status: SL.COMPLETED, //SL.COMPLETED || SL.ON_PROGRESS
    nextStep: CIVIL_INFRASTRUCTURE_DETAIL,
    stepStatus: SL.ACTIVE, // SL.ACTIVE || SL.IN_ACTIVE
    subSteps: [
      {
        stepNo: 1,
        stepLabel: "Building Detail",
        step: "Building Plan",
        status: SL.VERIFIED, // SL.VERIFIED ||  SL.NC ||  SL.PENDING_FOR_VERIFICATION 
        nextStep: CIC.TRADEWISE_CLASSROOMS,
        stepStatus: SL.ACTIVE, // SL.ACTIVE || SL.IN_ACTIVE
      },
      {
        stepNo: 2,
        stepLabel: "Building Completion Certificate (BCC)",
        step: "Building Completion Certificate (BCC)",
        status: SL.VERIFIED, // SL.VERIFIED ||  SL.NC ||  SL.PENDING_FOR_VERIFICATION 
        nextStep: CIC.MULTIPURPOSE_HALL,
        stepStatus: SL.ACTIVE, // SL.ACTIVE || SL.IN_ACTIVE
      },
      {
        stepNo: 3,
        stepLabel: "Photos of Building",
        step: "Photos of Building",
        status: SL.VERIFIED, // SL.VERIFIED ||  SL.NC ||  SL.PENDING_FOR_VERIFICATION 
        nextStep: CIC.IT_LAB,
        stepStatus: SL.ACTIVE, // SL.ACTIVE || SL.IN_ACTIVE
      },
    ],
  },
  {
    stepNo: 2,
    stepLabel: "Civil Infrastructure Detail",
    step: CIVIL_INFRASTRUCTURE_DETAIL,
    status: SL.COMPLETED, // SL.ON_PROGRESS
    nextStep: AMENITIES_AREA,
    stepStatus: SL.ACTIVE, // SL.ACTIVE || SL.IN_ACTIVE
    subSteps: [
      {
        stepNo: 1,
        step: CIC.TRADEWISE_WORKSHOP,
        status: NOT_FILLED, // FILLED || NOT_FILLED 
        stepTitle: "Tradewise Workshop",
        nextStep: CIC.TRADEWISE_CLASSROOMS,
        stepStatus: SL.ACTIVE, // SL.ACTIVE || SL.IN_ACTIVE
        workshopList: [
          {
            TradeName: 'Fitter',
            Particulars: 'WORKSHOP_1',
            status: SL.VERIFIED, // SL.VERIFIED ||  SL.NC ||  SL.PENDING_FOR_VERIFICATION 
          },
          {
            TradeName: 'Fitter',
            Particulars: 'WORKSHOP_2',
            status: SL.VERIFIED, // SL.VERIFIED ||  SL.NC ||  SL.PENDING_FOR_VERIFICATION 
          },
        ]
      },
      {
        stepNo: 2,
        step: CIC.TRADEWISE_CLASSROOMS,
        status: NOT_FILLED, // NOT_FILLED
        stepTitle: "TradeWise Classrooms",
        nextStep: CIC.MULTIPURPOSE_HALL,
        stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
        classroomList: [
          {
            TradeName: 'Fitter',
            Particulars: 'CLASSROOM_1',
            status: SL.VERIFIED, // SL.VERIFIED ||  SL.NC ||  SL.PENDING_FOR_VERIFICATION 
          },
          {
            TradeName: 'Fitter',
            Particulars: 'CLASSROOM_2',
            status: SL.VERIFIED, // SL.VERIFIED ||  SL.NC ||  SL.PENDING_FOR_VERIFICATION 
          },
        ]
      },
      {
        stepNo: 3,
        step: CIC.MULTIPURPOSE_HALL,
        status: NOT_FILLED, // NOT_FILLED
        stepTitle: "Multipurpose hall",
        nextStep: CIC.IT_LAB,
        stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
      },
      {
        stepNo: 4,
        step: CIC.IT_LAB,
        status: NOT_FILLED, // NOT_FILLED
        stepTitle: "IT Lab",
        nextStep: CIC.LIBRARY,
        stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE

      },
      {
        stepNo: 5,
        step: CIC.LIBRARY,
        status: NOT_FILLED, // NOT_FILLED
        stepTitle: "Library",
        nextStep: CIC.PLACEMENT_AND_COUNSELLING_ROOM,
        stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE

      },
      {
        stepNo: 6,
        step: CIC.PLACEMENT_AND_COUNSELLING_ROOM,
        status: NOT_FILLED, // NOT_FILLED
        stepTitle: "Placement and counselling room",
        nextStep: CIC.ADMINISTRATIVE_AREA,
        stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE

      },
      {
        stepNo: 8,
        step: CIC.ADMINISTRATIVE_AREA,
        status: NOT_FILLED, // NOT_FILLED
        stepTitle: "Administrative Area",
        nextStep: null,
        stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE

      },
    ],
  },
  {
    stepNo: 3,
    stepLabel: "Amenities Area",
    step: AMENITIES_AREA,
    status: SL.COMPLETED, // SL.ON_PROGRESS
    nextStep: SIGNAGE_BOARDS,
    stepStatus: SL.ACTIVE, // SL.ACTIVE || SL.IN_ACTIVE
  },
  {
    stepNo: 4,
    stepLabel: "Signage Boards",
    step: SIGNAGE_BOARDS,
    status: SL.COMPLETED, // SL.ON_PROGRESS
    nextStep: ELECTRICITY_CONNECTION_DETAILS,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE

  },
  {
    stepNo: 5,
    stepLabel: "Electricity Connection Details",
    step: ELECTRICITY_CONNECTION_DETAILS,
    status: SL.COMPLETED, // SL.ON_PROGRESS
    nextStep: FEE_PAYMENT_FOR_STAGEII,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
  },
  {
    stepNo: 6,
    stepLabel: "Miscellaneous",
    step: MISCELLANEOUS,
    status: SL.COMPLETED, // SL.ON_PROGRESS
    nextStep: FEE_PAYMENT_FOR_STAGEII,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
  },
  {
    stepNo: 7,
    stepLabel: "Fee Payment For StageII",
    step: FEE_PAYMENT_FOR_STAGEII,
    status: SL.COMPLETED, // SL.ON_PROGRESS
    nextStep: TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
  },
  {
    stepNo: 8,
    stepLabel: "Tradewise Machinery/Tools/Equipment Details",
    step: TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS,
    status: SL.COMPLETED, // SL.ON_PROGRESS
    nextStep: null,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
  },
  {
    stepNo: 9,
    stepLabel: "Document Uploads",
    step: DOCUMENT_UPLOADS,
    status: SL.COMPLETED, // SL.ON_PROGRESS
    nextStep: null,
    stepStatus: IN_ACTIVE, // ACTIVE || IN_ACTIVE
  },
];




export const ASSESSMENT_STAGE_I_KEYS = {
  POSSESSION_OF_LAND: "POSSESSION_OF_LAND",
  LAND_DOCUMENTS: "LAND_DOCUMENTS",
  LAND_USE_LAND_CONVERSION_CERTIFICATE: "LAND_USE_LAND_CONVERSION_CERTIFICATE",
  LEASE_DEED_DOCUMENTS: "LEASE_DEED_DOCUMENTS",
  LAND_AREA: "LAND_AREA",
  ID_PROOF_OF_AUTHORIZED_SIGNATORY: "ID Proof of Authorized Signatory",
  REGISTRATION_CERTIFICATE_OF_APPLICANT_ORGANIZATION: "Registration Certificate of Applicant Organization",
  ID_PROOF_OF_SECRETARY_CHAIRPERSON_PRESIDENT: "ID Proof of Secretary/Chairperson/President",
  RESOLUTION_CERTIFICATE: "Resolution Certificate"
}


export const ASSESSMENT_STAGE_II_FLOW_NEW = [
  {
    stepNo: 1,
    step: ST2FC.BUILDING_DETAIL.step,
    status: SL.PENDING, //SL.COMPLETED || SL.ON_PROGRESS ||  SL.PENDING
    stepLabel: ST2FC.BUILDING_DETAIL.label,
    nextStep: ST2FC.CIVIL_INFRASTRUCTURE_DETAIL.step,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    DA: false,
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.PRESENT, // CURRENT || PRESENT
    referenceNumber: null,
    VerificationList: [],
  },
  {
    stepNo: 2,
    step: ST2FC.CIVIL_INFRASTRUCTURE_DETAIL.step,
    status: SL.PENDING, //SL.COMPLETED || SL.ON_PROGRESS ||  SL.PENDING
    stepLabel: ST2FC.CIVIL_INFRASTRUCTURE_DETAIL.label,
    nextStep: ST2FC.AMENITIES_AREA.step,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    DA: false,
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.PRESENT, // CURRENT || PRESENT
    referenceNumber: null,
    VerificationList: [],
  },
  {
    stepNo: 3,
    step: ST2FC.AMENITIES_AREA.step,
    status: SL.PENDING, //SL.COMPLETED || SL.ON_PROGRESS ||  SL.PENDING
    stepLabel: ST2FC.AMENITIES_AREA.label,
    nextStep: SIGNAGE_BOARDS,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    DA: false,
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.PRESENT, // CURRENT || PRESENT
    referenceNumber: null,
    VerificationList: []
  },
  {
    stepNo: 4,
    step: ST2FC.SIGNAGE_BOARDS.step,
    status: SL.PENDING, //SL.COMPLETED || SL.ON_PROGRESS ||  SL.PENDING
    stepLabel: ST2FC.SIGNAGE_BOARDS.label,
    nextStep: ST2FC.ELECTRICITY_CONNECTION_DETAILS.step,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    DA: false,
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.PRESENT, // CURRENT || PRESENT
    referenceNumber: null,
    VerificationList: []
  },
  {
    stepNo: 5,
    step: ST2FC.ELECTRICITY_CONNECTION_DETAILS.step,
    status: SL.PENDING, //SL.COMPLETED || SL.ON_PROGRESS
    stepLabel: ST2FC.ELECTRICITY_CONNECTION_DETAILS.label,
    nextStep: ST2FC.TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS.step,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    DA: true,
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.PRESENT, // CURRENT || PRESENT
    referenceNumber: null,
    VerificationList: []
  },
  {
    stepNo: 6,
    step: ST2FC.TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS.step,
    status: SL.PENDING, //SL.COMPLETED || SL.ON_PROGRESS
    stepLabel: ST2FC.TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS.label,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    nextStep: ST2FC.REVIEW_ASSESSMENT.step,
    DA: true,
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.PRESENT, // CURRENT || PRESENT
    referenceNumber: null,
    VerificationList: [
    ]
  },
  {
    stepNo: 7,
    step: ST2FC.REVIEW_ASSESSMENT.step,
    status: SL.PENDING, //SL.COMPLETED || SL.ON_PROGRESS
    stepLabel: ST2FC.REVIEW_ASSESSMENT.label,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    nextStep: LAST,
    DA: true,
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.PRESENT, // CURRENT || PRESENT
    referenceNumber: null,
    VerificationList: []
  },
];

export const ASSESSMENT_STAGE_I_FLOW = [
  {
    stepNo: 1,
    step: ST1FC.APPLICANT_ENTITY_DETAILS.step,
    status: SL.COMPLETED, //SL.COMPLETED || SL.ON_PROGRESS ||  SL.PENDING
    stepLabel: ST1FC.APPLICANT_ENTITY_DETAILS.label,
    nextStep: ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    DA: false,
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.PRESENT, // CURRENT || PRESENT
    referenceNumber: null,
    VerificationList: [],
  },
  {
    stepNo: 2,
    step: ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step,
    status: SL.COMPLETED, //SL.COMPLETED || SL.ON_PROGRESS ||  SL.PENDING
    stepLabel: ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.label,
    nextStep: ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    DA: false,
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.PRESENT, // CURRENT || PRESENT
    referenceNumber: null,
    VerificationList: []
  },
  {
    stepNo: 3,
    step: ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step,
    status: SL.COMPLETED, //SL.COMPLETED || SL.ON_PROGRESS ||  SL.PENDING
    stepLabel: ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.label,
    nextStep: ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    DA: false,
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.PRESENT, // CURRENT || PRESENT
    referenceNumber: null,
    VerificationList: []
  },
  {
    stepNo: 4,
    step: ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step,
    status: SL.PENDING, //SL.COMPLETED || SL.ON_PROGRESS
    stepLabel: ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.label,
    nextStep: ST1FC.DOCUMENTS_UPLOAD.step,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    DA: true,
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.PRESENT, // CURRENT || PRESENT
    referenceNumber: null,
    VerificationList: [
      {
        assessment_id: null,
        checkName: DA1_KEYS.LAND_DOCUMENT,
        check: DA1_KEYS.LAND_DOCUMENT,
        da_status: SL.PENDING, stage: abbreviation.STAGE_I.key,
        step: ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step,
      },
      {
        assessment_id: null,
        checkName: ASSESSMENT_STAGE_I_KEYS.LAND_AREA,
        check: ASSESSMENT_STAGE_I_KEYS.LAND_AREA,
        da_status: SL.PENDING,
        stage: abbreviation.STAGE_I.key,
        step: ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step,
      }
    ]
  },
  {
    stepNo: 5,
    step: ST1FC.DOCUMENTS_UPLOAD.step,
    status: SL.PENDING, //SL.COMPLETED || SL.ON_PROGRESS
    stepLabel: ST1FC.DOCUMENTS_UPLOAD.label,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    nextStep: ST1FC.REVIEW_ASSESSMENT.step,
    DA: true,
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.PRESENT, // CURRENT || PRESENT
    referenceNumber: null,
    VerificationList: [
      {
        assessment_id: null,
        checkName: ASSESSMENT_STAGE_I_KEYS.ID_PROOF_OF_AUTHORIZED_SIGNATORY,
        check: ASSESSMENT_STAGE_I_KEYS.ID_PROOF_OF_AUTHORIZED_SIGNATORY,
        da_status: SL.PENDING,
        stage: abbreviation.STAGE_I.key,
        step: ST1FC.DOCUMENTS_UPLOAD.step
      },
      {
        assessment_id: null,
        checkName: ASSESSMENT_STAGE_I_KEYS.REGISTRATION_CERTIFICATE_OF_APPLICANT_ORGANIZATION,
        check: ASSESSMENT_STAGE_I_KEYS.REGISTRATION_CERTIFICATE_OF_APPLICANT_ORGANIZATION,
        da_status: SL.PENDING,
        stage: abbreviation.STAGE_I.key,
        step: ST1FC.DOCUMENTS_UPLOAD.step
      },
      {
        assessment_id: null,
        checkName: ASSESSMENT_STAGE_I_KEYS.ID_PROOF_OF_SECRETARY_CHAIRPERSON_PRESIDENT,
        check: ASSESSMENT_STAGE_I_KEYS.ID_PROOF_OF_SECRETARY_CHAIRPERSON_PRESIDENT,
        da_status: SL.PENDING,
        stage: abbreviation.STAGE_I.key,
        step: ST1FC.DOCUMENTS_UPLOAD.step
      },
      {
        assessment_id: null,
        checkName: ASSESSMENT_STAGE_I_KEYS.RESOLUTION_CERTIFICATE,
        check: ASSESSMENT_STAGE_I_KEYS.RESOLUTION_CERTIFICATE,
        da_status: SL.PENDING,
        stage: abbreviation.STAGE_I.key,
        step: ST1FC.DOCUMENTS_UPLOAD.step
      },
    ]
  },
  {
    stepNo: 6,
    step: ST1FC.REVIEW_ASSESSMENT.step,
    status: SL.PENDING, //SL.COMPLETED || SL.ON_PROGRESS
    stepLabel: ST1FC.REVIEW_ASSESSMENT.label,
    stepStatus: ACTIVE, // ACTIVE || IN_ACTIVE
    nextStep: LAST,
    DA: true,
    for: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    actor: SL.ASSESSOR, // APPLICANT || ASSESSOR || RDSDE
    recordType: SL.PRESENT, // CURRENT || PRESENT
    referenceNumber: null,
    VerificationList: []
  },
];
// window.ASSESSMENT_STAGE_I_FLOW = ASSESSMENT_STAGE_I_FLOW;

export const ASSESSMENT_STATUS = {
  assessment_id: randomId(),
  assessment_status: SL.ON_PROGRESS, // COMPLETED || ON_PROGRESS || PENDING
  pendingAt: SL.PENDING_AT_ASSESSOR
}




export const MaxData = [
  { value: "Document is not legible", label: "Document is not legible" },
  { value: "Document is irrelevant", label: "Document is irrelevant" },
  {
    value: "Document lacks required information",
    label: "Document lacks required information",
  },
  {
    value:
      "Document is not approved by the competent authority in the State/ UT",
    label:
      "Document is not approved by the competent authority in the State/ UT",
  },
  {
    value:
      "Address on the document does not match with the proposed land/ building address",
    label:
      "Address on the document does not match with the proposed land/ building address",
  },
  {
    value:
      "Document does not indicate the workshop for all trade/units, classrooms, IT Lab, Administrative area, Amenities area etc.",
    label:
      "Document does not indicate the workshop for all trade/units, classrooms, IT Lab, Administrative area, Amenities area etc.",
  },
  {
    value: "other",
    label: "Any other reason, please specify",
  },
];


export { currentDate };


export const MAX_FILE_SIZE = 2 * 1024 * 1024; // 2 MB
export const SUPPORTED_FORMATS = ["application/pdf", "image/jpeg", "image/png"];




// Entity Categories
export const aff_cat = {
  Society_Trust: {
    label: "Society / Trust",
    value: "Society / Trust"
  },
  Private_Limited_Company: {
    label: "Private Limited Company",
    value: "Private Limited Company"
  },
  Public_Limited_Company: {
    label: "Public Limited Company",
    value: "Public Limited Company"
  },
  Sole_Proprietor: {
    label: "Sole Proprietor",
    value: "Sole Proprietor"
  },
  Private_Institution_Individual: {
    label: "Private Institution / Individual",
    value: "Private Institution / Individual"
  },
  Public_Sector_Undertaking: {
    label: "Public Sector Undertaking",
    value: "Public Sector Undertaking"
  },
  Central_State_Government_Union_Territory_Administration: {
    label: "Central / State Government / Union Territory Administration",
    value: "Central / State Government / Union Territory Administration"
  },
}


// Affiliation Categories

export const af_cats = {
  NEW_ITIS: {
    name: "Application for Establishment of New ITIs",
    master: "01"
  },
  MSTI: {
    name: "Application for opening Mini Skill Training Institute",
    master: "02",
  },
  NEW_AGE: {
    name: "Establishment of New Age ITIs or Adoption of existing ITIs by industry entities",
    master: "03",
  },
  DST: {
    name: "Affiliation under the Dual System of Training (DST)",
    master: "04",
  },
  Surrender_Trade_Units: {
    name: "Surrender of Trade/Units",
    master: "05"
  },
  Existing_ITIs: {
    name: "Application for Existing ITIs",
    master: "06",
  },
};

export const EXT_ITI_SUBCATE = {
  Addition_Trades_Units: {
    name: "Addition of New Trades/Units",
    master: "01"
  },
  Name_Change: {
    name: "Name Change of the ITI",
    master: "02"
  },
  Shifting_Relocation: {
    name: "Shifting/Relocation",
    master: "03"
  },
  Merger_of_ITIs: {
    name: "Merger of ITIs",
    master: "04"
  },
  SCVT_to_NCVET: {
    name: "SCVT to NCVET conversion of Trades (for existing Government ITIs)",
    master: "05",
  },
  Renewal: {
    name: "Renewal of Affiliation",
    master: "06"
  },
}



export const LAND_DOCUMENT_TYPES = {
  LEASED: "LEASED",
  OWNED: "OWNED",
  LAND_CONVERSION_CERTIFICATE: "LAND_CONVERSION_CERTIFICATE"
}

export const Certificat = {
  REGISTRATION_CERTIFICATE: "REGISTRATION_CERTIFICATE",
  DOC_OF_AUTHORIZED_SIGNATORY: "DOC_OF_AUTHORIZED_SIGNATORY",
  DOC_OF_LAND_EARMARKING: "DOC_OF_LAND_EARMARKING",
  DOC_ITI_RESOLUTION: "DOC_ITI_RESOLUTION"
}



export const TypeOfInst = {
  PRIVATE: "Private",
  GOVERNMENT: "Government"
}



// export const generateUniqueID = () => crypto.randomBytes(16).toString("hex");
// export const photo_list = [{ photoView: FRONT_VIEW_PHOTO_OF_BUILDING, photo_pth: bld_photos.front_view_photo_of_building, }, { photoView: SIDE_VIEW_PHOTO_OF_BUILDING, photo_pth: bld_photos.side_view_photo_of_building, }, { photoView: ENTRANCE_GATE_PHOTO_OF_PLOT_WITH_SIGNAGE_BOARD, photo_pth: bld_photos.entrance_gate_photo_of_plot_with_signage_board, },];
export const AREA_FOR_ONE_STUDENT = 0.6875;
export const roundUpToNextTen = (num) => {
  return Math.ceil(num / 10) * 10;
}

export const AREA_FOR_ONE_STUDENT_FOR_IT_LAB = 0.25;
export const AREA_FOR_ONE_STUDENT_FOR_LIBRARY = 0.25;

// export const AREA_FOR_ONE_STUDENT_FOR_ADMINISTRATIVE_AREA = 0.3125;
export const AREA_FOR_ONE_STUDENT_FOR_STAFF_ROOM = 0.125;
export const AREA_FOR_ONE_STUDENT_FOR_COUNSELLING_ROOM = 0.125;
export const AREA_FOR_ONE_STUDENT_FOR_PRINCIPAL_ROOM = 0.125;
export const AREA_FOR_ONE_STUDENT_FOR_RECEPTION_CUM_WAITING_LOBBY = 0.25;
export const AREA_FOR_ONE_STUDENT_FOR_ADMINISTRATIVE_HALL_SECTION = 0.3125;

export const AREA_FOR_FIRST_AID_ROOM = 15;

export const AREA_FOR_ONE_STUDENT_FOR_LIBRARY_AND_READING_ROOM = 0.25;


// Electricity






export const electricity_particulars_keys = {
  ELECTRICITY_CONNECTION: {
    key: 'ELECTRICITY_CONNECTION',
    title: "",
    instruction: "",
  },
  PHOTO_OF_BACKUP_POWER: {
    key: "PHOTO_OF_BACKUP_POWER",
    title: "",
    instruction: "",
  }
  ,
  PURCHASE_RELATED_DOCUMENTS: {
    key: "PURCHASE_RELATED_DOCUMENTS",
    title: "",
    instruction: "",
  }
  ,
  FIRE_AND_SAFETY_CERTIFICATE: {
    key: "FIRE_AND_SAFETY_CERTIFICATE",
    title: "",
    instruction: "",
  }
}

export const electricity_particulars = [
  {
    key: electricity_particulars_keys.ELECTRICITY_CONNECTION.key,
    instruction: electricity_particulars_keys.ELECTRICITY_CONNECTION.instruction,
  },
  {
    key: electricity_particulars_keys.PHOTO_OF_BACKUP_POWER.key,
    instruction: electricity_particulars_keys.PHOTO_OF_BACKUP_POWER.instruction,
  },
  {
    key: electricity_particulars_keys.PURCHASE_RELATED_DOCUMENTS.key,
    instruction: electricity_particulars_keys.PURCHASE_RELATED_DOCUMENTS.instruction,
  },
  {
    key: electricity_particulars_keys.FIRE_AND_SAFETY_CERTIFICATE.key,
    instruction: electricity_particulars_keys.FIRE_AND_SAFETY_CERTIFICATE.instruction,
  },
];



export const common_infra_category = {
  CIVIL: "CIVIL",
  AMENITIES: "AMENITIES"
}
export const iti_lab_particulars_keys = {
  DESKTOP_COMPUTER_WITH_LATEST_CONFIGURATION: {
    key: 'DESKTOP_COMPUTER_WITH_LATEST_CONFIGURATION',
    title: "Desktop computer with latest configuration",
    instruction: "Each ITI shall be equipped with desktop computers of the latest configuration to ensure effective digital learning. \n i.	A minimum of 10 computers shall be required for an ITI having a seating capacity of up to 100 trainees in either the first or second shift. \n ii.	For every additional 20 trainees beyond the initial 100, 2 additional computers shall be required",
  },
  INTERNET_CONNECTION: {
    key: "INTERNET_CONNECTION",
    title: "Internet connection",
    instruction: "Minimum 40 Mbps connection or high speed Wifi connection"
  }
  ,
  COMPUTER_WITH_MULTIMEDIA_ANTI_VIRUS_ETC: {
    key: "COMPUTER_WITH_MULTIMEDIA_ANTI_VIRUS_ETC",
    title: "Computer with multimedia, anti-virus software, latest operating software (Licensed software) with UPS",
    instruction: "Mandatory"
  }
  ,
  LAN_CABLING_ETC: {
    key: "LAN_CABLING_ETC",
    title: "LAN Cabling, LAN Switch",
    instruction: "As required"
  }
  ,
  PRINTER_LASER: {
    key: "PRINTER_LASER",
    title: "Printer (Laser)",
    instruction: "As required"
  }
  ,
  SCANNER: {
    key: "SCANNER",
    title: "Scanner",
    instruction: "As required"
  }
  ,
  SERVER: {
    key: "SERVER",
    title: "Server",
    instruction: "As required"
  }
  ,
  EXTERNAL_HARD_DISK_1TB: {
    key: "EXTERNAL_HARD_DISK_1TB",
    title: "External Hard Disk – 1TB",
    instruction: "1 no."
  }
  ,
  INSTRUCTOR_OFFICE_CHAIR: {
    key: "INSTRUCTOR_OFFICE_CHAIR",
    title: "Instructor/ Office Chair",
    instruction: "1 no."
  }
  ,
  INSTRUCTOR_OFFICE_TABLE: {
    key: "INSTRUCTOR_OFFICE_TABLE",
    title: "Instructor/ Office Table",
    instruction: "1 no."
  }
  ,
  TRAINEES_COMPUTER_CHAIRS: {
    key: "TRAINEES_COMPUTER_CHAIRS",
    title: "Trainees/Computer Chairs",
    instruction: "20 nos."
  }
  ,
  TRAINEES_COMPUTER_TABLES: {
    key: "TRAINEES_COMPUTER_TABLES",
    title: "Trainees/ Computer Tables",
    instruction: "10 nos."
  }
  ,
  BLACK_WHITE_BOARD_4X6_FEET: {
    key: "BLACK_WHITE_BOARD_4X6_FEET",
    title: "Black/ White Board 4X6 Feet",
    instruction: "1 no."
  }
}

export const iti_lab_particulars = [
  {
    key: iti_lab_particulars_keys.DESKTOP_COMPUTER_WITH_LATEST_CONFIGURATION.key,
    instruction: iti_lab_particulars_keys.DESKTOP_COMPUTER_WITH_LATEST_CONFIGURATION.instruction,
  },
  {
    key: iti_lab_particulars_keys.INTERNET_CONNECTION.key,
    instruction: iti_lab_particulars_keys.INTERNET_CONNECTION.instruction,
  },
  {
    key: iti_lab_particulars_keys.COMPUTER_WITH_MULTIMEDIA_ANTI_VIRUS_ETC.key,
    instruction: iti_lab_particulars_keys.COMPUTER_WITH_MULTIMEDIA_ANTI_VIRUS_ETC.instruction,
  }, {
    key: iti_lab_particulars_keys.LAN_CABLING_ETC.key,
    instruction: iti_lab_particulars_keys.LAN_CABLING_ETC.instruction,
  }, {
    key: iti_lab_particulars_keys.PRINTER_LASER.key,
    instruction: iti_lab_particulars_keys.PRINTER_LASER.instruction,
  }, {
    key: iti_lab_particulars_keys.SCANNER.key,
    instruction: iti_lab_particulars_keys.SCANNER.instruction,
  }, {
    key: iti_lab_particulars_keys.SERVER.key,
    instruction: iti_lab_particulars_keys.SERVER.instruction,
  }, {
    key: iti_lab_particulars_keys.EXTERNAL_HARD_DISK_1TB.key,
    instruction: iti_lab_particulars_keys.EXTERNAL_HARD_DISK_1TB.instruction,
  }, {
    key: iti_lab_particulars_keys.INSTRUCTOR_OFFICE_CHAIR.key,
    instruction: iti_lab_particulars_keys.INSTRUCTOR_OFFICE_CHAIR.instruction,
  }, {
    key: iti_lab_particulars_keys.INSTRUCTOR_OFFICE_TABLE.key,
    instruction: iti_lab_particulars_keys.INSTRUCTOR_OFFICE_TABLE.instruction,
  }, {
    key: iti_lab_particulars_keys.TRAINEES_COMPUTER_CHAIRS.key,
    instruction: iti_lab_particulars_keys.TRAINEES_COMPUTER_CHAIRS.instruction,
  }, {
    key: iti_lab_particulars_keys.TRAINEES_COMPUTER_TABLES.key,
    instruction: iti_lab_particulars_keys.TRAINEES_COMPUTER_TABLES.instruction,
  }, {
    key: iti_lab_particulars_keys.BLACK_WHITE_BOARD_4X6_FEET.key,
    instruction: iti_lab_particulars_keys.BLACK_WHITE_BOARD_4X6_FEET.instruction,
  },
];


export const Signage_Boards_Keys = {
  SIGNAGE_BOARD_ON_PLOT_ENTRANCE: {
    key: 'SIGNAGE_BOARD_ON_PLOT_ENTRANCE',
    instruction: "The institute must display a signage board at the plot entrance as well as on the institute building, in accordance with the specifications provided in the guidelines below: \n Signage board to be made in English/Hindi/Regional language. The signage should be bilingual. The size of the font should be minimum 75 mm. The size of the board may vary from 2m x 1.5 m or 3m x 1.5 m or 4m x 2.0 m. \n Details needed: ITI's name, MIS code and full address and ITI logo, Skill India Logo & DGT logo."
  },
  SIGNAGE_BOARD_ON_INSTITUTE_BUILDING: {
    key: 'SIGNAGE_BOARD_ON_INSTITUTE_BUILDING',
    instruction: "Details needed: ITI's name, MIS code*, ITI logo, Skill India Logo & DGT logo."
  },
  SIGNAGE_BOARDS: {
    key: 'SIGNAGE_BOARDS',
    instruction: "i.	Directional boards must be displayed to indicate different sections of the building, such as the workshop, administrative building, hostel, scrap yard, etc. \n ii.	Signage boards for important safety information, including three-phase power supply, danger zones, and prohibited areas, must also be prominently displayed."
  },
  TRADE_DETAILS_BOARD: {
    key: 'TRADE_DETAILS_BOARD',

    instruction: "Trade details board shall display the list of DGT affiliated trades, seating capacity and number of trainees enrolled"
  },
  STAFF_DETAILS_BOARD: {
    key: 'STAFF_DETAILS_BOARD',

    instruction: "Staff details board shall display name, qualification/ designation and contact numbers of Principal and Group Instructor/Trade Instructor"
  },
  EXIT_BOARD: {
    key: 'EXIT_BOARD',

    instruction: "Emergency exit routes must be clearly marked with visible signage."
  },
  BOARD_INDICATING_DANGER_SIGNS: {
    key: 'BOARD_INDICATING_DANGER_SIGNS',

    instruction: "Boards indicating Danger Signs must be prominently displayed near: Transformer, Generator Set, heavy Electrical Installation/ Panels"
  },
  PROHIBITED_AREA_INDICATORS: {
    key: 'PROHIBITED_AREA_INDICATORS',

    instruction: "Near running machinery etc."
  },
  SEXUAL_HARASSMENT_REDRESSAL_COMMITTEE_NOTICE: {
    key: 'SEXUAL_HARASSMENT_REDRESSAL_COMMITTEE_NOTICE',
    instruction: "Each ITI must prominently display information about the Sexual Harassment Redressal Committee on notice boards, ensuring awareness and fostering a safe, respectful environment for all students and staff."
  },
}


export const Signage_Boards_Particulars = [
  {
    key: Signage_Boards_Keys.SIGNAGE_BOARD_ON_PLOT_ENTRANCE.key,
    instruction: Signage_Boards_Keys.SIGNAGE_BOARD_ON_PLOT_ENTRANCE.instruction,
  },
  {
    key: Signage_Boards_Keys.SIGNAGE_BOARD_ON_INSTITUTE_BUILDING.key,
    instruction: Signage_Boards_Keys.SIGNAGE_BOARD_ON_INSTITUTE_BUILDING.instruction,
  },
  {
    key: Signage_Boards_Keys.SIGNAGE_BOARDS.key,
    instruction: Signage_Boards_Keys.SIGNAGE_BOARDS.instruction,
  },
  {
    key: Signage_Boards_Keys.TRADE_DETAILS_BOARD.key,
    instruction: Signage_Boards_Keys.TRADE_DETAILS_BOARD.instruction,
  }, {
    key: Signage_Boards_Keys.STAFF_DETAILS_BOARD.key,
    instruction: Signage_Boards_Keys.STAFF_DETAILS_BOARD.instruction,
  },
  {
    key: Signage_Boards_Keys.EXIT_BOARD.key,
    instruction: Signage_Boards_Keys.EXIT_BOARD.instruction,
  }, {
    key: Signage_Boards_Keys.BOARD_INDICATING_DANGER_SIGNS.key,
    instruction: Signage_Boards_Keys.BOARD_INDICATING_DANGER_SIGNS.instruction,
  },
  {
    key: Signage_Boards_Keys.PROHIBITED_AREA_INDICATORS.key,
    instruction: Signage_Boards_Keys.PROHIBITED_AREA_INDICATORS.instruction,
  },
  {
    key: Signage_Boards_Keys.SEXUAL_HARASSMENT_REDRESSAL_COMMITTEE_NOTICE.key,
    instruction: Signage_Boards_Keys.SEXUAL_HARASSMENT_REDRESSAL_COMMITTEE_NOTICE.instruction,
  },
];

