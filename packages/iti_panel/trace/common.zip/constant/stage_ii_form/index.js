export * as buildingDetails from "./BuildingDetails.js";
export * as CivilInfra from "./Civil Infrastructure Detail/index.js";
export * as ItLabSpecifications from "./ITLabSpecifications.js";
export * as MachineryToolEquipment from "./MachineryToolEquipment.js";
export * as Amenities from "./Amenities.js";
export * as SignageBoards from "./SignageBoards.js";
export * as ElectricityDetails from "./ElectricityDetails.js";
export * as DocumentsUpload from "./DocumentsUpload.js";














