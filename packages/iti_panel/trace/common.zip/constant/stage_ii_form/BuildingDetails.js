import * as C from "../constants.js";
import * as yup from "yup";
export const Building_Detail_initialValues = {
    bld_plan_documents: [{ language: '', document: null, notarised_document: null }], // default one document
    bld_completion_cert: [{ language: '', document: null, notarised_document: null }], // default one document
    name_of_bcc_issued_authority: "",
    date_of_bcc_issued: "",
    front_view_photo_of_building: "",
    side_view_photo_of_building: "",
    entrance_gate_photo_of_plot_with_signage_board: "",
};

export const building_detail_yup_object = {
    bld_completion_cert: yup
        .array()
        .of(
            yup.object({
                language: yup
                    .string()
                    .required("Select Language"),

                document: yup
                    .mixed()
                    .required("Select  Document File")
                    .test("fileSize", "File too large", (value) =>
                        value ? value.size <= 2 * 1024 * 1024 : true // 2MB
                    )
                    .test("fileType", "Unsupported File Format", (value) =>
                        value
                            ? ["application/pdf", "image/jpeg", "image/png"].includes(value.type)
                            : true
                    ),
                notarised_document: yup
                    .mixed()
                    .when("language", {
                        is: (lang) => lang !== "Hindi" && lang !== "English",
                        then: (schema) =>
                            schema
                                .required("Select Notarized Document")
                                .test("fileSize", "File too large", (value) =>
                                    value ? value.size <= 2 * 1024 * 1024 : true
                                )
                                .test("fileType", "Unsupported File Format", (value) =>
                                    value
                                        ? ["application/pdf", "image/jpeg", "image/png"].includes(value.type)
                                        : true
                                ),
                        otherwise: (schema) => schema.notRequired(),
                    }),
            })
        )
        .min(1, "At least one document is required"), // optional constraint

    bld_plan_documents: yup
        .array()
        .of(
            yup.object({
                language: yup
                    .string()
                    .required("Select Language"),

                document: yup
                    .mixed()
                    .required("Select  Document File")
                    .test("fileSize", "File too large", (value) =>
                        value ? value.size <= 2 * 1024 * 1024 : true // 2MB
                    )
                    .test("fileType", "Unsupported File Format", (value) =>
                        value
                            ? ["application/pdf", "image/jpeg", "image/png"].includes(value.type)
                            : true
                    ),
                notarised_document: yup
                    .mixed()
                    .when("language", {
                        is: (lang) => lang !== "Hindi" && lang !== "English",
                        then: (schema) =>
                            schema
                                .required("Select Notarized Document")
                                .test("fileSize", "File too large", (value) =>
                                    value ? value.size <= 2 * 1024 * 1024 : true
                                )
                                .test("fileType", "Unsupported File Format", (value) =>
                                    value
                                        ? ["application/pdf", "image/jpeg", "image/png"].includes(value.type)
                                        : true
                                ),
                        otherwise: (schema) => schema.notRequired(),
                    }),
            })
        )
        .min(1, "At least one document is required"), // optional constraint

    name_of_bcc_issued_authority: yup
        .string()
        .required("Please enter the name of the authority issuing the BCC."),
    date_of_bcc_issued: yup
        .string()
        .required("Please enter the date the BCC was issued."),
    front_view_photo_of_building: yup
        .mixed()
        .required("Please upload the front view photo of the building (PDF)."),
    side_view_photo_of_building: yup
        .mixed()
        .required("Please upload the side view photo of the building (PDF)."),
    entrance_gate_photo_of_plot_with_signage_board: yup
        .mixed()
        .required(
            "Please upload the entrance gate photo with signage board (PDF)."
        ),
};