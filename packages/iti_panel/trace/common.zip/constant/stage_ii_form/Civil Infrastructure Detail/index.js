export * as tradewise_workshop from "./TradeWiseWorkshops.js";
export * as tradewise_classroom from "./TradeWiseClassrooms.js";
export * as multipurposehall from "./MultiPurposeHall.js";
export * as itLab from "./ItLab.js";
export * as library from "./Library.js";
export * as placement_n_counselling_room from "./placement_n_counselling_room.js";
export * as administrative_areas from "./AdministrativeArea.js";















