import * as C from "../../constants.js";
import * as yup from "yup";
export const initialValue = {
    "it_lab": []
}


export const ValSchema = yup.object({
    it_lab: yup
        .array()
        .of(
            yup.object({
                available_area: yup
                    .number()
                    .typeError("Enter a valid number")
                    .required("Enter Available Area")
                    .test(
                        "min-area",
                        "Available area cannot be less than required area",
                        function (value) {
                            const requiredArea = Number(this.parent.required_area);
                            if (value === undefined || value === null) return false;
                            return Number(value) >= requiredArea;
                        }
                    ),
                document: yup
                    .mixed()
                    .required("Select Document File")
                    .test("fileSize", "File too large", (value) => {
                        // ✅ Skip validation if it's a string (already uploaded path)
                        if (typeof value === "string") return true;
                        // ✅ Validate if it's a File object
                        return value ? value.size <= 2 * 1024 * 1024 : true; // 2MB
                    }),
            })
        )
        .min(1, "Select Document"),
});
