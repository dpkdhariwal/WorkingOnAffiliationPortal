// import * as C from "../../constants.js";
import * as yup from "yup";
export const initialValue = {
    "particulars_1": [],
    "particulars_2": [],
}

export const ValSchema = yup.object({
    particulars_1: yup
        .array()
        .of(
            yup.object({
                available_area: yup
                    .number()
                    .typeError("Enter a valid number")
                    .required("Enter Available Qty")
                // .test(
                //     "min-qty",
                //     "Available Qty cannot be less than required Qty",
                //     function (value) {
                //         const requiredQty = Number(this.parent.required_qty);
                //         if (value === undefined || value === null) return false;
                //         return Number(value) >= requiredQty;
                //     }
                // ),
            })
        ),
    particulars_2: yup
        .array()
        .of(
            yup.object({
                document: yup
                    .mixed()
                    .required("Select  Document File")
                    .test("fileSize", "File too large", (value) => {
                        // ✅ Skip validation if it's a string (already uploaded path)
                        if (typeof value === "string") return true;
                        // ✅ Validate if it's a File object
                        return value ? value.size <= 2 * 1024 * 1024 : true; // 2MB
                    })
            })
        ),
});
