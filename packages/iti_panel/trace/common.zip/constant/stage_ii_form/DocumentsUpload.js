// import * as C from "../../constants.js";
import * as yup from "yup";
export const initialValue = {
    "mte_photos_per_unit": [],
    "gst_invoices": [],
    iaccept: false,
}

export const ValSchema = yup.object({
    mte_photos_per_unit: yup
        .array()
        .of(
            yup.object({
                photo: yup
                    .mixed()
                    .required("Select  Document File")
                    .test("fileSize", "File too large", (value) => {
                        // ✅ Skip validation if it's a string (already uploaded path)
                        if (typeof value === "string") return true;
                        // ✅ Validate if it's a File object
                        return value ? value.size <= 2 * 1024 * 1024 : true; // 2MB
                    })
            })
        ),
    gst_invoices: yup
        .array()
        .of(
            yup.object({
                document: yup
                    .mixed()
                    .required("Select  Document File")
                    .test("fileSize", "File too large", (value) => {
                        // ✅ Skip validation if it's a string (already uploaded path)
                        if (typeof value === "string") return true;
                        // ✅ Validate if it's a File object
                        return value ? value.size <= 2 * 1024 * 1024 : true; // 2MB
                    })
            })
        ),
    iaccept: yup
        .boolean()
        .oneOf([true], "You must accept the terms and conditions")
        .required("You must accept the terms and conditions"),
});
