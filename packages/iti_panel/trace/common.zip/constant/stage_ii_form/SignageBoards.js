// import * as C from "../../constants.js";
import * as yup from "yup";
export const initialValue = {
    "signage_boards": [],
}

export const ValSchema = yup.object({
    signage_boards: yup
        .array()
        .of(
            yup.object({
                document: yup
                    .mixed()
                    .required("Select  Document File")
                    .test("fileSize", "File too large", (value) => {
                        // ✅ Skip validation if it's a string (already uploaded path)
                        if (typeof value === "string") return true;
                        // ✅ Validate if it's a File object
                        return value ? value.size <= 2 * 1024 * 1024 : true; // 2MB
                    })
            })
        ),
});
