// import * as C from "../../constants.js";
import * as yup from "yup";
export const initialValue = {
    consumer_name: '', // STRING
    consumer_number: '', // NUMBER
    electricity_authority_name: '',  // STRING
    electricity_authority_website: '', // URL
    total_available_sanction_load_in_kw: '', //NUMBER

    latest_electricity_bill_meter_sealing_report: '',
    power_supply_back_power: '', //FILE
    power_supply_purchase_related_documents: '', //FILE
    fire_and_safety_certificate: '', //FILE
}


export const ValSchema = yup.object({
    consumer_name: yup
        .string()
        .required("Enter consumer name")
        .min(3, "Name must be at least 3 characters"),
    consumer_number: yup
        .string()
        .required("Enter consumer number")
        .matches(/^[0-9A-Za-z-]+$/, "Invalid consumer number format"),

    electricity_authority_name: yup
        .string()
        .required("Enter electricity authority name"),
    electricity_authority_website: yup
        .string()
        .required("Enter electricity authority website")
        .url("Enter a valid website URL"),
    total_available_sanction_load_in_kw: yup
        .number()
        .typeError("Enter a valid number")
        .required("Enter sanctioned load (kW)")
        .positive("Value must be greater than 0"),
    latest_electricity_bill_meter_sealing_report: yup
        .mixed()
        .required("Upload power supply backup document (PDF)"),
    power_supply_back_power: yup
        .mixed()
        .required("Upload power supply backup document (PDF)"),
    power_supply_purchase_related_documents: yup
        .mixed()
        .required("Upload power supply purchase document (PDF)"),
    fire_and_safety_certificate: yup
        .mixed()
        .required("Upload fire and safety certificate (PDF)"),
});