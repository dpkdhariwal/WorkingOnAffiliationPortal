// import * as C from "../../constants.js";
import * as yup from "yup";
export const initialValue = {
    "computers": [],
    "equipments": [],
}

export const ValSchema = yup.object({
    computers: yup
        .array()
        .of(
            yup.object({
                available_qty: yup
                    .number()
                    .typeError("Enter a valid number")
                    .required("Enter Available Qty")
                    .test(
                        "min-qty",
                        "Available Qty cannot be less than required Qty",
                        function (value) {
                            const requiredQty = Number(this.parent.required_qty);
                            if (value === undefined || value === null) return false;
                            return Number(value) >= requiredQty;
                        }
                    ),
            })
        ),
    equipments: yup
        .array()
        .of(
            yup.object({
                availability: yup
                    .string()
                    .oneOf(["yes", "no"], "Select Yes or No")
                    .required("Select availability"),
            })
        ),
});
