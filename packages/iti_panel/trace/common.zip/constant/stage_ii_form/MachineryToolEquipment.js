// import * as C from "../../constants.js";
import * as yup from "yup";
export const initialValue = {
    "mte": [],
}

export const ValSchema = yup.object({
    mte: yup
        .array()
        .of(
            yup.object({
                availability: yup.string().required("Select Availability"),
                available_quantity: yup
                    .number()
                    .typeError("Enter a valid number")
                    .transform((value, originalValue, context) => {
                        // If availability is 'no', automatically set available_quantity to 0
                        if (context?.parent?.availability === "no") return 0;
                        return value;
                    })
                    .when("availability", {
                        is: "no",
                        then: (schema) => schema.notRequired().nullable(),
                        otherwise: (schema) =>
                            schema
                                .required("Enter Available Qty")
                                .test(
                                    "min-qty",
                                    "Available Qty cannot be less than required Qty",
                                    function (value) {
                                        const requiredQtyRaw = this.parent.required_quantity;
                                        const requiredQty = Number(requiredQtyRaw);

                                        if (isNaN(requiredQty)) return true;
                                        if (value === undefined || value === null) return false;

                                        return Number(value) >= requiredQty;
                                    }
                                ),
                    }),
            })
        ),
});
