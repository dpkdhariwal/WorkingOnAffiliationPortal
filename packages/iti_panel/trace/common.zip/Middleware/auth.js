import fs from 'fs';
import jwt from 'jsonwebtoken';
import { pKeyPath } from '../common/common.js';
import { getUserByEmail } from '../database/models/auth.js';

const publicKey = fs.readFileSync(pKeyPath, 'utf8');
export const authenticate = function authenticate(req, res, next) {
    const token = req.headers.authorization;
    if (!token) {
        return res.status(401).json({ error: 'Authorization header missing' });
    }

    try {
        const decoded = jwt.verify(token, publicKey);
        req.user = decoded; // Store the decoded user data in the request object
        next();
    }
    catch (err) {
        return res.status(401).json({ error: 'Invalid token' });
    }
};



export const applicantToken = async function authenticate(req, res, next) {
    // console.log("Cookies:", req.cookies); // logs all cookies
    // console.log("Refresh Token:", req.cookies.token);
    console.log(27, req.cookies);
    const token = req.cookies.token
    // console.log(req.headers);

    if (!token) {
        return res.status(401).json({ error: 'Authorization header missing' });
    }
    try {
        const decoded = jwt.verify(token, publicKey);
        req.user = decoded; // Store the decoded user data in the request object
        req.userInfo = await getUserByEmail(req.user.email);
        // return res.status(200).json(req.userInfo);
        next();
    }
    catch (err) {
        return res.status(401).json(err);
    }
};
