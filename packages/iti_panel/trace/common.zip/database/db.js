import mysql from 'mysql';
import dotenv from "dotenv";
// Load correct .env file based on NODE_ENV
dotenv.config({
  path: `.env.${process.env.NODE_ENV || "development"}`,
});
export const dbConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT || 3306
};
export const affDbConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT || 3306
}
console.log(17, process.env.DB_HOST);


// export const masterConfig = { connectionLimit: 10, host: '10.134.19.104', user: 'deepak', password: 'deepak', database: 'affliationdb', port: 3306 };
export const masterConfig = {
    connectionLimit: process.env.DB_CONNECTIONLIMIT,
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT || 3306
};





export const conn = mysql.createConnection(dbConfig);



// eslint-disable-next-line no-unused-vars
// export const getConnection = async (poolCluster, poolId) => {
//     return new Promise((resolve, reject) => {
//         poolCluster.getConnection(poolId, (err, connection) => {
//             if (err) {
//                 reject(err);
//             } else {
//                 resolve(connection);
//             }
//         });
//     });
// };


export const eMsg = { staus: false }
export const sMsg = { staus: true }
export const resp = {};