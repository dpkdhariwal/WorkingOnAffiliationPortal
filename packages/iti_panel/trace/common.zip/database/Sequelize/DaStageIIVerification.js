import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const DaStageIIVerification = sequelize.define("DaStageIIVerification", {
  slno: {
    type: DataTypes.INTEGER(10),
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },
  uniqueId: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  reffNumber: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  appId: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  assessment_id: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  keyName: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  step: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  as_per_norms: {
    type: DataTypes.STRING(255),
    allowNull: true,
  },
  reason: {
    type: DataTypes.STRING(255),
    allowNull: true,
  },
  assessor_comments: {
    type: DataTypes.STRING(255),
    allowNull: true,
  },
  isDraft: {
    type: DataTypes.STRING(255),
    allowNull: true,
  },
  insertDate: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  updateDate: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  recordType: {
    type: DataTypes.ENUM("PRESENT", "HISTORY"),
    allowNull: false,
    defaultValue: "PRESENT",
  },
  reviewDate: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  reff_uniquId: {
    type: DataTypes.STRING(255),
    allowNull: true,
    comment: "app_assessment_flow_stage_i - uniqueID",
  },
}, {
  tableName: "da_stage_ii_verifications",
  timestamps: false,
});

export default DaStageIIVerification;
