import { DataTypes } from "sequelize";
import { sequelize } from "../../config/database.js";

const VilDistrictSubDistrict = sequelize.define(
  "Village",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      allowNull: false,
      autoIncrement: true, // assuming `id` is auto-increment
    },
    villageCode: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    villageNameEnglish: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    subdistrictCode: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    subdistrictNameEnglish: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    districtCode: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    districtNameEnglish: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    stateCode: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    stateNameEnglish: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    pincode: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
    },
  },
  {
    tableName: "villages",
    timestamps: true, // because createdAt/updatedAt exist
  }
);

export default VilDistrictSubDistrict;
