import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const ElectricityDetails = sequelize.define(
  "ElectricityDetails",
  {
    slno: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true, // assuming it's auto-increment
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    userId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    consumer_name: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    consumer_number: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    electricity_authority_name: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    electricity_authority_website: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    total_available_sanction_load_in_kw: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  {
    tableName: "electricity_details",
    timestamps: false, // table doesn’t include createdAt/updatedAt
  }
);

export default ElectricityDetails;
