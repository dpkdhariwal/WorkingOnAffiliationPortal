import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import State from "./State.js";
import District from "./districts.js";
import VilDistrictSubDistrict from "./villages_district_sub_districts.js";

const ProposedInstituteAddressesDetails = sequelize.define(
  "ProposedInstituteAddressesDetails",
  {
    slno: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      allowNull: false,
      autoIncrement: true, // uncomment if slno should auto increment
    },
    state_code: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    state_name: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    district_code: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    district_name: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    sub_district_code: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    sub_district_name: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    village_code: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    village_name: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    pincode: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    plotNumber_khasaraNumber: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    landmark: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    town_city: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    block: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    userId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    tableName: "proposed_proposedinstituteaddressesdetails",
    timestamps: false, // no createdAt / updatedAt in schema
  }
);



ProposedInstituteAddressesDetails.hasMany(District, {
  foreignKey: "stateCode",        // column in Table2
  sourceKey: "state_code",  // column in Table1
  as: "district_list",
  constraints: true,               // <-- enables foreign key in DB
});

ProposedInstituteAddressesDetails.hasMany(VilDistrictSubDistrict, {
  foreignKey: "subdistrictCode",        // column in Table2
  sourceKey: "sub_district_code",  // column in Table1
  as: "sub_district_list",
  constraints: true,               // <-- enables foreign key in DB
});

ProposedInstituteAddressesDetails.hasMany(VilDistrictSubDistrict, {
  foreignKey: "villageCode",        // column in Table2
  sourceKey: "village_code",  // column in Table1
  as: "village_list",
  constraints: false,               // <-- enables foreign key in DB
});


export default ProposedInstituteAddressesDetails;
