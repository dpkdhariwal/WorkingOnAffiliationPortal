import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const LandDocuments = sequelize.define(
  "LandDocuments",
  {
    slno: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true, // usually primary key
    },
    uniqueId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    appId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    assessment_id: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    recordType: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    language: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    document: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    notarised_document: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    timestamp: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
    uploaded_datetime: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    update_date: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    reference_number: {
      type: DataTypes.STRING(255),
      allowNull: true,
    }
  },
  {
    tableName: "land_documents",
    timestamps: false, // disable Sequelize's auto timestamps
  }
);

export default LandDocuments;




