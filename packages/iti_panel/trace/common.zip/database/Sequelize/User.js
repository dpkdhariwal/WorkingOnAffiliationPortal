import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const User = sequelize.define("User", {
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true, // usually needed for int PK
    },
    userType: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    email: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true, // usually email should be unique
        validate: {
            isEmail: true,
        },
    },
    password: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    token: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    last_login_datetime: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    last_logout_datetime: {
        type: DataTypes.DATE, // Sequelize maps to TIMESTAMP/DATE
        allowNull: false,
        defaultValue: DataTypes.NOW,
    },
    status: {
        type: DataTypes.ENUM("active", "inactive"),
        allowNull: false,
    },
}, {
    tableName: "users", // maps to your table
    timestamps: false,  // disable createdAt & updatedAt
    comment: "user_infromation"
});
export default User;
