import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import AppFormSubCivilInfra from "./AppFormSubCivilInfra.js";

const FormFlowStageII = sequelize.define(
  "FormFlowStageII",
  {
    slno: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true, // remove if not auto-increment
    },
    stepNo: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    step: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    status: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    stepLabel: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    nextStep: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    stepStatus: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    subSteps: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: null,
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    userId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    tableName: "form_flow_stage_ii", // exact table name
    timestamps: false, // no createdAt/updatedAt
  }
);


// FormFlowStageII.hasMany(AppFormSubCivilInfra, {
//   foreignKey: "appId",        // column in Table2
//   sourceKey: "appId",  // column in Table1
//   as: "civilInfraSubSteps",
//   constraints: true,               // <-- enables foreign key in DB
// });


export default FormFlowStageII;
