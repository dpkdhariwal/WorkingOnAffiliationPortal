import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';


const MasterTradeInfo = sequelize.define("MasterTradeInfo", {
  slno: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true, // remove if not auto-increment
  },
  trade_type: {
    type: DataTypes.STRING(100),
    allowNull: true,
  },
  trade_type_id: {
    type: DataTypes.STRING(50),
    allowNull: true,
  },
  trade_id: {
    type: DataTypes.STRING(50),
    allowNull: false,
  },
  trade_name: {
    type: DataTypes.STRING(150),
    allowNull: true,
  },
  unit_strength: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  classroom_area: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
  },
  workshop_area_requirement: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
  },
  workshop_area_unit: {
    type: DataTypes.STRING(50),
    allowNull: true,
  },
  excess_workshop_area_status: {
    type: DataTypes.STRING(20),
    allowNull: true,
  },
  excess_workshop_area: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
  },
  excess_workshop_area_unit: {
    type: DataTypes.STRING(50),
    allowNull: true,
  },
  workshop_area_remarks_status: {
    type: DataTypes.STRING(20),
    allowNull: true,
  },
  workshop_area_remarks: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  power_requirement: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
  },
  power_requirement_unit: {
    type: DataTypes.STRING(50),
    allowNull: true,
  },
  power_requirement_remarks_status: {
    type: DataTypes.STRING(20),
    allowNull: true,
  },
  power_requirement_remarks: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  trade_cat: {
    type: DataTypes.STRING(50),
    allowNull: true,
  },
  is_new_age: {
    type: DataTypes.ENUM("yes", "no"),
    allowNull: false,
    defaultValue: "no",
  },
}, {
  tableName: "master_trade_info",
  timestamps: false, // no createdAt/updatedAt in your schema
});

export default MasterTradeInfo;

