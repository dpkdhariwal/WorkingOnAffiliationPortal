import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const AuthorizedSignatoryDetail = sequelize.define("AuthorizedSignatoryDetail", 
    {
    slno: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    appId: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    name: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    email_id: {
        type: DataTypes.STRING(255),
        allowNull: false,
        validate: {
            isEmail: true
        }
    },
    mobile_number: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    id_proof_type: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    id_proof_number: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    document: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    uploaded_datetime: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    timestamp: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    document_meta_info: {
        type: DataTypes.JSON,
        allowNull: false
    },
    recordType:{
        type: DataTypes.ENUM(['PRESENT', 'HISTORY']),
        allowNull:true
    },
    update_date: {
        type: DataTypes.DATE,
        allowNull: true
    },
    reference_number: {
        type: DataTypes.STRING(255),
        allowNull:true
    },
    assessment_id:{
        type: DataTypes.STRING(255),
        allowNull:true
    }
}, {
    tableName: "authorized_signatory_details",
    timestamps: false
});

export default AuthorizedSignatoryDetail;
// 