import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const District = sequelize.define(
  "District",
  {
    districtCode: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      allowNull: false,
    },
    districtNameEnglish: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    districtNameLocal: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    districtNameshort: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    stateCode: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    census2011Code: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    effectiveDate: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    lastUpdated: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    majorVersion: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    minorVersion: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    transactionId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    operationCode: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    transactionDescription: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    isactive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
    },
  },
  {
    tableName: "districts",
    timestamps: true, // because table has createdAt and updatedAt
  }
);

export default District;
