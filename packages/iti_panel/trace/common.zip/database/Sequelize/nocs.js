// models/nocIssuedNocDetail.js
import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const Noc = sequelize.define(
  "Noc",
  {
    slno: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true, // set true if you want it to auto-increment
    },
    appId: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    assessment_id: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    docName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    genertedDate: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    stage: {
      type: DataTypes.ENUM("STAGE_I", "STAGE_II"),
      allowNull: true,
    },
    status: {
      type: DataTypes.ENUM(
        "NOC_ISSUANCE_ISSUED",
        "NOC_ISSUANCE_PENDING",
        "NOC_ISSUANCE_REJECTED"
      ),
      allowNull: false,
    },
    rejectedDate: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: "nocs",
    timestamps: false, // set true if you have createdAt/updatedAt columns
  }
);

export default Noc;
