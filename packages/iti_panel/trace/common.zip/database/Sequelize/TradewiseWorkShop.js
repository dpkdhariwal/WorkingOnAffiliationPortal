import { Sequelize, DataTypes, Model } from "sequelize"
import { sequelize } from '../../config/database.js';
import MasterTradeInfo from "./tradeAreaInfo.js";

const TradewiseWorkshop = sequelize.define('TradewiseWorkshop', {
  slno: {
    type: DataTypes.INTEGER(10),
    allowNull: false,
    primaryKey: true,
    autoIncrement: true
  },
  appId: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  trade_id: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  workshop: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  required_area: {
    type: DataTypes.FLOAT,
    allowNull: false
  },
  available_area: {
    type: DataTypes.FLOAT,
    allowNull: true
  },
  document: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  userId: {
    type: DataTypes.STRING(255),
    allowNull: false
  }
}, {
  tableName: 'tradewise_workshop',
  timestamps: false,
  underscored: false
});

TradewiseWorkshop.belongsTo(MasterTradeInfo, {
    foreignKey: "trade_id",   // column in EntityAddress
    targetKey: "trade_id",     // PK in State model
    as: "tradeInfo",
});
export default TradewiseWorkshop;
