import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const Stage1Documents = sequelize.define(
  "Stage1Documents",
  {
    slno: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    uniqueId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    land_document_type: {
      type: DataTypes.ENUM("LEASED", "OWNED", "LAND_CONVERSION_CERTIFICATE"),
      allowNull: false,
    },
    language: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    document: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    notarised_document: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    timestamp: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
    uploaded_datetime: {
      type: DataTypes.DATE,
      allowNull: false,
    },
  },
  {
    tableName: "stage1_documents",
    timestamps: false, // disable Sequelize's automatic createdAt/updatedAt
  }
);

export default Stage1Documents;
