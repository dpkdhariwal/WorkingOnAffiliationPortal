import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import District from "./districts.js";
import VilDistrictSubDistrict from "./villages_district_sub_districts.js";

const EntOtherITI = sequelize.define('EntOtherITI', {
  slno: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true, // assuming slno is an auto-increment field
    allowNull: false,
  },
  run_AffiliationNo: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  run_ITIName: {
    type: DataTypes.STRING(150),
    allowNull: false,
  },
  run_MISCode: {
    type: DataTypes.STRING(150),
    allowNull: false,
  },
  run_State: {
    type: DataTypes.STRING(150),
    allowNull: false,
  },
  run_District: {
    type: DataTypes.STRING(150),
    allowNull: false,
  },
  run_SubDistrict: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  run_Village: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  run_TownCity: {
    type: DataTypes.STRING(150),
    allowNull: false,
  },
  run_Pincode: {
    type: DataTypes.STRING(150),
    allowNull: false,
  },
  run_PlotNumber_KhasaraNumber: {
    type: DataTypes.STRING(150),
    allowNull: false,
  },
  run_Landmark: {
    type: DataTypes.STRING(150),
    allowNull: false,
  },
  appId: {
    type: DataTypes.STRING(150),
    allowNull: false,
  },
  userId: {
    type: DataTypes.STRING(150),
    allowNull: false,
  },
  run_BlockTehsil: {
    type: DataTypes.STRING(150),
    allowNull: false,
  },
}, {
  tableName: 'ent_otheriti',
  timestamps: false, // disable createdAt/updatedAt
});



EntOtherITI.hasMany(District, {
  foreignKey: "stateCode",        // column in Table2
  sourceKey: "run_State",  // column in Table1
  as: "district_list",
  constraints: true,               // <-- enables foreign key in DB
});

EntOtherITI.hasMany(VilDistrictSubDistrict, {
  foreignKey: "subdistrictCode",        // column in Table2
  sourceKey: "run_SubDistrict",  // column in Table1
  as: "sub_district_list",
  constraints: true,               // <-- enables foreign key in DB
});

EntOtherITI.hasMany(VilDistrictSubDistrict, {
  foreignKey: "villageCode",        // column in Table2
  sourceKey: "run_Village",  // column in Table1
  as: "village_list",
  constraints: false,               // <-- enables foreign key in DB
});


export default EntOtherITI;
