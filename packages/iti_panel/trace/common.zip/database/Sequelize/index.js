import District from "./districts.js";
import EntEntityDetails from "./EntEntityDetails.js";
import EntityAddress from "./EntityAddress.js";
import EntOtherITI from "./EntOtherITI.js";
import MasterAffiliationCategory from "./master_affiliation_categories.js";
import MasterAffiliationSubCategory from "./master_affiliation_sub_categories.js";
import ProposedInstituteAddressesDetails from "./ProposedInstituteAddressesDetails.js";
import State from "./State.js";
import VilDistrictSubDistrict from "./villages_district_sub_districts.js";
import UserProfile from "./UserProfile.js";

// 1:1 relation via appId
EntEntityDetails.hasOne(EntityAddress, {
    foreignKey: "appId",
    sourceKey: "appId",   // important: tells Sequelize which key in EntEntityDetails to match
    as: "ent_address",
});

// 1:1 relation via appId
EntEntityDetails.belongsTo(MasterAffiliationCategory, {
    foreignKey: "aff_category",
    sourceKey: "uniqueId",   // important: tells Sequelize which key in EntEntityDetails to match
    as: "category_info",
});

EntEntityDetails.belongsTo(MasterAffiliationSubCategory, {
    foreignKey: "aff_sub_category",
    sourceKey: "uniqueId",   // important: tells Sequelize which key in EntEntityDetails to match
    as: "sub_cat_info",
});




EntityAddress.belongsTo(EntEntityDetails, {
    foreignKey: "appId",
    targetKey: "appId",
    as: "entity_details",
});


EntityAddress.belongsTo(State, {
    foreignKey: "state_code",   // column in EntityAddress
    targetKey: "stateCode",     // PK in State model
    as: "state_detail",
});


EntityAddress.belongsTo(District, {
    foreignKey: "district_code",   // column in EntityAddress
    targetKey: "districtCode",     // PK in State model
    as: "district_detail",
});


EntityAddress.belongsTo(VilDistrictSubDistrict, {
    foreignKey: "sub_district_code",   // column in EntityAddress
    targetKey: "subdistrictCode",     // PK in State model
    as: "sub_district",
});

EntityAddress.belongsTo(VilDistrictSubDistrict, {
    foreignKey: "village_code",   // column in EntityAddress
    targetKey: "villageCode",     // PK in State model
    as: "village",
});


EntOtherITI.belongsTo(State, {
    foreignKey: "run_State",   // column in EntityAddress
    targetKey: "stateCode",     // PK in State model
    as: "state_detail",
});

EntOtherITI.belongsTo(District, {
    foreignKey: "run_District",   // column in EntityAddress
    targetKey: "districtCode",     // PK in State model
    as: "district_detail",
});




ProposedInstituteAddressesDetails.belongsTo(State, {
    foreignKey: "state_code",   // column in EntityAddress
    targetKey: "stateCode",     // PK in State model
    as: "state_detail",
});
ProposedInstituteAddressesDetails.belongsTo(District, {
    foreignKey: "district_code",   // column in EntityAddress
    targetKey: "districtCode",     // PK in State model
    as: "district_detail",
});
ProposedInstituteAddressesDetails.belongsTo(VilDistrictSubDistrict, {
    foreignKey: "sub_district_code",   // column in EntityAddress
    targetKey: "subdistrictCode",     // PK in State model
    as: "sub_district",
});
ProposedInstituteAddressesDetails.belongsTo(VilDistrictSubDistrict, {
    foreignKey: "village_code",   // column in EntityAddress
    targetKey: "villageCode",     // PK in State model
    as: "village",
});


export { EntEntityDetails, EntityAddress, ProposedInstituteAddressesDetails };
export { UserProfile };
