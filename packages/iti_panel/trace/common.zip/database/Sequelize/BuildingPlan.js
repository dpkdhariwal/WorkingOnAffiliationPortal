import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import DAStageIVerificationsChecklist from "./DAStageIVerificationsChecklist.js";

const BuildingPlan = sequelize.define("BuildingPlan",
    {
        slno: {
            type: DataTypes.INTEGER(10),
            allowNull: false,
            primaryKey: true,
            autoIncrement: true, // typical for slno
        },
        uniqueId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        language_for_building_plan: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        document_of_building_plan: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        notarised_document_of_building_plan: {
            type: DataTypes.STRING(255),
            allowNull: true,
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        uploadDate:{
            type: DataTypes.DATE,
            allowNull:false
        }
    }, {
    tableName: "bld_building_plan",
    timestamps: false, // no createdAt/updatedAt
});


// AppAssessmentFlowStageI.hasMany(DAStageIVerificationsChecklist, {
//     foreignKey: "assessment_id",        // column in Table2
//     sourceKey: "assessment_id",  // column in Table1
//     as: "check_list",
//     constraints: true,               // <-- enables foreign key in DB
// });


// AppAssessmentFlowStageI.hasMany(DAStageIVerificationsChecklist, {
//   foreignKey: "assessment_id",   // FK in VerificationList table
//   as: "VerificationList" // must match your include alias
// });

// DAStageIVerificationsChecklist.belongsTo(AppAssessmentFlowStageI, {
//   foreignKey: "assessment_id",
//   as: "Flow"
// });



export default BuildingPlan;
