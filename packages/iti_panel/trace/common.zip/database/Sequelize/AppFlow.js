import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
const AppFlow = sequelize.define(
    "AppFlow",
    {
        slno: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true, // add if this is auto-incremented
        },
        stepNo: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        userId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        step: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        status: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        startedDate: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        stepStatus: {
            type: DataTypes.ENUM("inactive", "pending", "completed", "on-progress"),
            defaultValue: "inactive",
            allowNull: false,
        },
        stepTitle: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        stepMsg: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        assignedTo: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        nextStep: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        completedDate: {
            type: DataTypes.DATE,
            allowNull: true,
        },
    },
    {
        tableName: "app_flow", // exact table name in DB
        timestamps: false,     // no createdAt or updatedAt
    }
);

export default AppFlow;