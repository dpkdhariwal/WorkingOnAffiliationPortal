import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const InitialAuthorizedSignatoryDetails = sequelize.define(
  "InitialAuthorizedSignatoryDetails",
  {
    slno: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    uniqueId:{
        type: DataTypes.STRING(255),
        allowNull:false
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    email_id: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    mobile_number: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    id_proof_type: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    id_proof_number: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    document: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    uploaded_datetime: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    timestamp: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
  },
  {
    tableName: "initial_authorized_signatory_details",
    timestamps: false, // disable Sequelize automatic createdAt/updatedAt
  }
);

export default InitialAuthorizedSignatoryDetails;
