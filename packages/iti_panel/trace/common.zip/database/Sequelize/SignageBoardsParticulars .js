import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const SignageBoardsParticulars = sequelize.define(
    "SignageBoardsParticulars",
    {
        slno: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true, // assuming auto-increment
        },
        particular: {
            type: DataTypes.ENUM(
                "SIGNAGE_BOARD_ON_PLOT_ENTRANCE",
                "SIGNAGE_BOARD_ON_INSTITUTE_BUILDING",
                "SIGNAGE_BOARDS",
                "TRADE_DETAILS_BOARD",
                "STAFF_DETAILS_BOARD",
                "EXIT_BOARD",
                "BOARD_INDICATING_DANGER_SIGNS",
                "PROHIBITED_AREA_INDICATORS",
                "SEXUAL_HARASSMENT_REDRESSAL_COMMITTEE_NOTICE",
            ),
            allowNull: false,
        },
        instruction: {
            type: DataTypes.TEXT,
            allowNull: false,
        },
        document: {
            type: DataTypes.STRING(255),
            allowNull: true,
        },
        submit_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        userId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        status: {
            type: DataTypes.ENUM('FILLED', 'NOT_FILLED'),
            allowNull: true,
            defaultValue: 'NOT_FILLED',
        },
    },
    {
        tableName: "signage_boards_particulars",
        timestamps: false, // since there are no createdAt/updatedAt columns
    }
);

export default SignageBoardsParticulars;
