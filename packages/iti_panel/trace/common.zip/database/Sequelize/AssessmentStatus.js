import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const AssessmentStatus = sequelize.define("AssessmentStatus", {
    slno: {
        type: DataTypes.INTEGER(10),
        allowNull: false,
        primaryKey: true,
        autoIncrement: true, // usually for int PK
    },
    assessment_id: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    assessment_status: {
        type: DataTypes.ENUM("ON_PROGRESS", "COMPLETED", "VERIFIED"),
        allowNull: false,
    },
    appId: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    pendingAt: {
        type: DataTypes.STRING(255),
        allowNull: true,
    },
    stage: {
        type: DataTypes.ENUM("STAGE_I", "STAGE_II"),
        allowNull: false,
    },
}, {
    tableName: "assessment_status",
    timestamps: false, // no createdAt/updatedAt in your schema
    underscored: false,
});

export default AssessmentStatus;
