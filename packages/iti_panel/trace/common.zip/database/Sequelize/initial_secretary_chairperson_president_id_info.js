import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const InitialSecretaryChairpersonPresidentIdInfo = sequelize.define(
  "InitialSecretaryChairpersonPresidentIdInfo",
  {
    slno: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    uniqueId:{
        type: DataTypes.STRING(255),
        allowNull:false
    },
    designation: {
      type: DataTypes.STRING(500),
      allowNull: false,
    },
    id_proof_type: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    id_proof_number: {
      type: DataTypes.STRING(250),
      allowNull: false,
    },
    document: {
      type: DataTypes.STRING(250),
      allowNull: false,
    },
    uploaded_datetime: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    timestamp: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    tableName: "initial_secretary_chairperson_president_id_info",
    timestamps: false, // disables Sequelize automatic createdAt / updatedAt
  }
);

export default InitialSecretaryChairpersonPresidentIdInfo;
