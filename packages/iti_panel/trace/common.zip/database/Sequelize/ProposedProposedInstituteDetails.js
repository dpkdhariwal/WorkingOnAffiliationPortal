import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
const ProposedProposedInstituteDetails = sequelize.define(
  "ProposedProposedInstituteDetails",
  {
    slno: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true, // ✅ recommended since it's `int(10)` primary
    },
    name_of_applicant_institute: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    type_of_institute: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    institute_location: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    is_falls_under_hill_area_hill: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    Falls_Under_Hill_Area_Hill__Supporting_Doc: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    is_falls_under_border_district: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    Falls_Under_Border_District__Supporting_Doc: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    under_msti_category: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    Whether_the_institute_is_exclusive_for_women_trainees: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    latitude: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    Longitude: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    userId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    tableName: "proposed_proposedinstitutedetails",
    timestamps: false, // ✅ since your table has no createdAt/updatedAt
  }
);
export default ProposedProposedInstituteDetails;
