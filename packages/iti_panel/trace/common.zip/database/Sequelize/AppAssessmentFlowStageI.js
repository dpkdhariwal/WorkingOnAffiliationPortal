import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import DAStageIVerificationsChecklist from "./DAStageIVerificationsChecklist.js";

const AppAssessmentFlowStageI = sequelize.define("AppAssessmentFlowStageI",
    {
        slno: {
            type: DataTypes.INTEGER(10),
            allowNull: false,
            primaryKey: true,
            autoIncrement: true, // typical for slno
        },
        uniqueID: {
            type: DataTypes.STRING(255), 
            allowNull: false,
        },
        stepNo: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        step: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        status: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        stepLabel: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        nextStep: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        stepStatus: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        DA: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        actor: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        recordType: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        assessment_id: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        completionDate: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        activeDate: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        referenceNumber: {
            type: DataTypes.STRING(255),
            allowNull: true,
        },
        forwarded_by: {
            type: DataTypes.STRING(255),
            allowNull: true,
        },
    }, {
    tableName: "app_assessment_flow_stage_i",
    timestamps: false, // no createdAt/updatedAt
});


AppAssessmentFlowStageI.hasMany(DAStageIVerificationsChecklist, {
    foreignKey: "assessment_id",        // column in Table2
    sourceKey: "assessment_id",  // column in Table1
    as: "check_list",
    constraints: true,               // <-- enables foreign key in DB
});


AppAssessmentFlowStageI.hasMany(DAStageIVerificationsChecklist, {
  foreignKey: "assessment_id",   // FK in VerificationList table
  as: "VerificationList" // must match your include alias
});

DAStageIVerificationsChecklist.belongsTo(AppAssessmentFlowStageI, {
  foreignKey: "assessment_id",
  as: "Flow"
});



export default AppAssessmentFlowStageI;
