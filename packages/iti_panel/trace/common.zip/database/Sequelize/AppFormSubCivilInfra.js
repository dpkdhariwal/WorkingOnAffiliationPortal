import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import CommonCivilInfrastructure from "./CommonCivilInfrastructure.js";

const AppFormSubCivilInfra = sequelize.define(
  "AppFormSubCivilInfra",
  {
    slno: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true, // remove if not auto-increment
    },
    stepNo: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    step: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    status: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    stepTitle: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    nextStep: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    stepStatus: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    stepLabel: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    userId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    tableName: "app_form_sub_civil_infra", // exact table name
    timestamps: false, // no createdAt/updatedAt
  }
);


AppFormSubCivilInfra.hasMany(CommonCivilInfrastructure, {
  foreignKey: "appId",     // column in GetVerifications
  sourceKey: "appId",    // column in GET_VERIFICATION_LIST_BY_STEP
  as: "common_civil_infra",
});

export default AppFormSubCivilInfra;
