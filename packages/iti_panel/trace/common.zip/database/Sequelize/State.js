import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const State = sequelize.define(
  "State",
  {
    stateCode: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      allowNull: false,
    },
    stateNameEnglish: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    stateNameLocal: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    shortName: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    census2011Code: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    effectiveDate: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    lastUpdated: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    majorVersion: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    minorVersion: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    stateOrUt: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    transactionId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    operationCode: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    transactionDescription: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    isactive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
    },
  },
  {
    tableName: "states", // table name
    timestamps: true, // because you have createdAt/updatedAt
  }
);

export default State;
