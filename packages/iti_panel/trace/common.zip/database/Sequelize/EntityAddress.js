import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';


const EntityAddress = sequelize.define(
  "EntityAddress",
  {
    slno: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true, // assuming this is the PK
      autoIncrement: true, // add if it's auto-incremented
    },
    state_code: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    state_name: {
      type: DataTypes.STRING(150),
      allowNull: true,
    },
    district_code: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    district_name: {
      type: DataTypes.STRING(150),
      allowNull: true,
    },
    sub_district_code: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    sub_district_name: {
      type: DataTypes.STRING(150),
      allowNull: true,
    },
    village_code: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    village_name: {
      type: DataTypes.STRING(150),
      allowNull: true,
    },
    pincode: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    plotNumber_khasaraNumber_gataNumber: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    landmark: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
     town_city: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    Block: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    appId: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    userId: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
  },
  {
    tableName: "ent_entityaddress", // ✅ exact table name
    timestamps: false, // your table has no createdAt/updatedAt
  }
);

export default EntityAddress;

