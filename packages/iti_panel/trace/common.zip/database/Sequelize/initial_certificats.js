import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import Certificat from "./Certificat.js";

const InitialCertificats = sequelize.define(
  "InitialCertificats",
  {
    slno: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    uniqueId:{
      type: DataTypes.STRING(255),
      allowNull:false
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    stage: {
      type: DataTypes.ENUM("STAGE_I", "STAGE_II"),
      allowNull: true,
    },
    keyName: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    document: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    upload_datetime: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    timestamp: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
  },
  {
    tableName: "initial_certificats",
    timestamps: false, // avoid Sequelize's default createdAt / updatedAt
  }
);



InitialCertificats.hasMany(Certificat, {
  foreignKey: "appId",    
  sourceKey: "appId",  
  as: "old_certificates",
});
InitialCertificats.hasMany(Certificat, {
  foreignKey: "appId",    
  sourceKey: "appId",  
  as: "latest_certificates",
});



export default InitialCertificats;
