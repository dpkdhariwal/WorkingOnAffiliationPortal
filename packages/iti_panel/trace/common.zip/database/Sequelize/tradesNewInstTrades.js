import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import MasterTradeInfo from "./tradeAreaInfo.js";
import MasterTradeToolEquipment from "./MasterTradeToolEquipment.js";
import TradeWiseToolEquipments from "./TradeWiseToolEquipments.js";

const TradesNewInstTrades = sequelize.define("TradesNewInstTrades", {
  slno: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true, // remove if not auto-increment in DB
  },
  appId: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  tradeId: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  trade: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  unit_in_shift1: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  unit_in_shift2: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  unit_in_shift3: {
    type: DataTypes.STRING(255),
    allowNull: true,
  },
}, {
  tableName: "trades_newinsttrades",
  timestamps: false, // no createdAt/updatedAt in your schema
});




TradesNewInstTrades.belongsTo(MasterTradeInfo, {
    foreignKey: "tradeId",   // column in EntityAddress
    targetKey: "trade_id",     // PK in State model
    as: "tradeInfo",
});



TradesNewInstTrades.hasMany(TradeWiseToolEquipments, {
  foreignKey: "trade_id",        // column in Table2
  sourceKey: "tradeId",  // column in Table1
  as: "toolInfo",
});
export default TradesNewInstTrades;
