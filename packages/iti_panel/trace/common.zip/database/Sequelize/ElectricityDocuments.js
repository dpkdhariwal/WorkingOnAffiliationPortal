import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const ElectricityDocuments = sequelize.define(
  "ElectricityDocuments",
  {
    slno: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true, // assuming auto-increment
    },
    document_type: {
      type: DataTypes.ENUM(
        'power_supply_back_power',
        'power_supply_purchase_related_documents',
        'fire_and_safety_certificate'
      ),
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM('FILLED', 'NOT_FILLED'),
      allowNull: false,
    },
    submit_date: {
      type: DataTypes.DATEONLY, // matches MySQL DATE
      allowNull: false,
    },
    document: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    userId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    tableName: "electricity_documents",
    timestamps: false, // no createdAt or updatedAt
  }
);

export default ElectricityDocuments;
