import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const LandArea = sequelize.define("LandArea", {
  slno: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,        // since you didn't define PK in SQL, I assume slno is PK
    autoIncrement: true
  },
  appId: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  assessment_id:{
    type: DataTypes.STRING(255),
    allowNull: false
  },
  reference_number: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  recordType: {
    type: DataTypes.ENUM("HISTORY", "PRESENT"),
    allowNull: false,
    defaultValue: "PRESENT"
  },
  land_area: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  created_date: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW  // optional: sets current date-time by default
  },
  update_date: {
    type: DataTypes.DATE,
    allowNull: true,
  },
}, {
  tableName: "land_area",
  timestamps: false  // since your table doesn’t have createdAt/updatedAt
});

export default LandArea;
