import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const SecretaryChairpersonPresidentIdInfo = sequelize.define("SecretaryChairpersonPresidentIdInfo", {
  slno: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  appId: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  designation: {
    type: DataTypes.STRING(500),
    allowNull: false
  },
  id_proof_type: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  id_proof_number: {
    type: DataTypes.STRING(250),
    allowNull: false
  },
  document: {
    type: DataTypes.STRING(250),
    allowNull: false
  },
  uploaded_datetime: {
    type: DataTypes.DATE,
    allowNull: false
  },
  timestamp: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  recordType: {
    type: DataTypes.ENUM(['PRESENT', 'HISTORY']),
    allowNull: true
  },
  update_date: {
    type: DataTypes.DATE,
    allowNull: true
  },
  reference_number: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  assessment_id: {
    type: DataTypes.STRING(255),
    allowNull: true
  }
}, {
  tableName: "secretary_chairperson_president_id_info",
  timestamps: false
});

export default SecretaryChairpersonPresidentIdInfo;
