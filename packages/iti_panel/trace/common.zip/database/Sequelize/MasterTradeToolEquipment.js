import { DataTypes } from "sequelize";
import { sequelize } from "../../config/database.js";

const MasterTradeToolEquipment = sequelize.define(
    "MasterTradeToolEquipment",
    {
        slno: {
            type: DataTypes.INTEGER(10),
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },
        sl: {
            type: DataTypes.INTEGER(10),
            allowNull: false,
        },
        trade_name: {
            type: DataTypes.STRING(100),
            allowNull: false,
        },
        trade_id: {
            type: DataTypes.STRING(50),
            allowNull: true,
        },
        tool_category: {
            type: DataTypes.STRING(100),
            allowNull: false,
        },
        Sub_category: {
            type: DataTypes.STRING(100),
            allowNull: true,
        },
        Item_name: {
            type: DataTypes.TEXT,
            allowNull: false,
        },
        Specification: {
            type: DataTypes.TEXT,
            allowNull: false,
        },
        Quantity: {
            type: DataTypes.STRING(50),
            allowNull: false,
        },
        Qty_type: {
            type: DataTypes.STRING(50),
            allowNull: false,
        },
        Per_unit: {
            type: DataTypes.INTEGER(10),
            allowNull: false,
        },
    },
    {
        tableName: "master_trade_tool_equpment",
        timestamps: false,
    }
);

export default MasterTradeToolEquipment;
