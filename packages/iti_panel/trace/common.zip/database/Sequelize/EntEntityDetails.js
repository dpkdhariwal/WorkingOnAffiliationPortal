import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';


const EntEntityDetails = sequelize.define(
  "EntEntityDetails",
  {
    slno: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true, // remove if not auto-increment
    },
    aff_category: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    aff_sub_category: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    category: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    name_of_applicant_entity: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    ApplicantEntityEmailId: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    isApplicantEntityEmailIdVerified: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    ApplicantContactNumber: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    Is_the_applicant_running_any_other_iti: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    appId: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    userId: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
  },
  {
    tableName: "ent_entitydetails", // exact table name
    timestamps: false, // no createdAt/updatedAt
  }
);

export default EntEntityDetails;
