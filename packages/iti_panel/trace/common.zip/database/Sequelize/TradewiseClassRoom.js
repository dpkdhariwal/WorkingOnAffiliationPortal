import { Sequelize, DataTypes, Model } from "sequelize"
import { sequelize } from '../../config/database.js';
import MasterTradeInfo from "./tradeAreaInfo.js";

const TradewiseClassRoom = sequelize.define('TradewiseClassRoom', {
  slno: {
    type: DataTypes.INTEGER(10),
    allowNull: false,
    primaryKey: true,
    autoIncrement: true
  },
  appId: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  trade_id: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  clasroom: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  required_area: {
    type: DataTypes.FLOAT,
    allowNull: false
  },
  available_area: {
    type: DataTypes.FLOAT,
    allowNull: true
  },
  document: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  userId: {
    type: DataTypes.STRING(255),
    allowNull: false
  }
}, {
  tableName: 'tradewise_classrooms',
  timestamps: false,
  underscored: false
});

TradewiseClassRoom.belongsTo(MasterTradeInfo, {
    foreignKey: "trade_id",   // column in EntityAddress
    targetKey: "trade_id",     // PK in State model
    as: "tradeInfo",
});

export default TradewiseClassRoom;
