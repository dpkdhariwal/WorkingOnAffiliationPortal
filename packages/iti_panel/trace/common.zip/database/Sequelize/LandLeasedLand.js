import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';


const LandLeasedLand = sequelize.define("LandLeasedLand", {
  slno: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,   // 👈 treating as PK since none defined
    autoIncrement: true // remove if not needed
  },
  name_of_lessor: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  name_of_lessee: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  lease_deed_number: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  date_of_commencement: {
    type: DataTypes.STRING(255), // consider DATE type if storing actual dates
    allowNull: false,
  },
  date_of_expiry: {
    type: DataTypes.STRING(255), // consider DATE type if storing actual dates
    allowNull: false,
  },
  appId: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
}, {
  tableName: "land_leased_lands", // 👈 exact table name
  timestamps: false, // no createdAt / updatedAt
});

export default LandLeasedLand;
