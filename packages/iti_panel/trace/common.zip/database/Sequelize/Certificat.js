import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const Certificat = sequelize.define("Certificat", {
  slno: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  appId: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  stage: {
    type: DataTypes.ENUM("STAGE_I", "STAGE_II"),
    allowNull: true
  },
  keyName: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  document: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  upload_datetime: {
    type: DataTypes.DATE,
    allowNull: false
  },
  timestamp: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  recordType: {
    type: DataTypes.ENUM(['PRESENT', 'HISTORY']),
    allowNull: true
  },
  update_date: {
    type: DataTypes.DATE,
    allowNull: true
  },
  reference_number: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  assessment_id: {
    type: DataTypes.STRING(255),
    allowNull: true
  }
}, {
  tableName: "certificats",
  timestamps: false
});

export default Certificat;
