import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const InitialLandArea = sequelize.define("InitialLandArea", {
  slno: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,        // since you didn't define PK in SQL, I assume slno is PK
    autoIncrement: true
  },
  appId: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  land_area: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  created_date: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW  // optional: sets current date-time by default
  },
}, {
  tableName: "initial_land_area",
  timestamps: false  // since your table doesn’t have createdAt/updatedAt
});

export default InitialLandArea;
