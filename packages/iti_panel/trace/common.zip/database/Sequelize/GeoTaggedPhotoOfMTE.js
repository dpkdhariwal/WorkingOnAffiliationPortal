import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import MasterTradeInfo from "./tradeAreaInfo.js";

const GeoTaggedPhotoOfMTE = sequelize.define(
    "GeoTaggedPhotoOfMTE",
    {
        slno: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true, // assuming auto-increment
        },
        tradeId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        unit: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        photo: {
            type: DataTypes.STRING(255),
            allowNull: true,
        },
        uniqueId: {
            type: DataTypes.STRING(255),
            allowNull: true,
        },
        submit_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM("FILLED", "NOT_FILLED"),
            allowNull: true,
            defaultValue: "NOT_FILLED",
        },
    },
    {
        tableName: "geo_tagged_photo_of_mte",
        timestamps: false, // no createdAt/updatedAt
    }
);

GeoTaggedPhotoOfMTE.belongsTo(MasterTradeInfo, {
    foreignKey: "tradeId",   // column in EntityAddress
    targetKey: "trade_id",     // PK in State model
    as: "tradeInfo",
});

export default GeoTaggedPhotoOfMTE;
