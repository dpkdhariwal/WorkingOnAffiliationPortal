import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const FormFlowStageI = sequelize.define(
    "FormFlowStageI",
    {
        slno: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true, // add if this is auto-incremented
        },
        stepNo: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        step: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        status: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        stepLabel: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        nextStep: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        submitDate: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        updateDate: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        stepStatus: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        for: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        recordType: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        userId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        activeDate:{
            type: DataTypes.DATE,
            allowNull:true
        }
    },
    {
        tableName: "form_flow_stage_i", // exact table name
        timestamps: false, // no createdAt/updatedAt columns
    }
);
export default FormFlowStageI;
