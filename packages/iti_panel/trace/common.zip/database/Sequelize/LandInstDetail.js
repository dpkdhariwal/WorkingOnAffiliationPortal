import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import LandOwnedLand from "./LandOwnedLand.js";
import Stage1Documents from "./stage1_documents.js";
import LandDocuments from "./land_documents.js";
import LandLeasedLand from "./LandLeasedLand.js";
import InitialLandArea from "./InitialLandArea.js";
import LandArea from "./LandArea.js";
import InitialCertificats from "./initial_certificats.js";

const LandInstDetail = sequelize.define("LandInstDetail",
  {
    slno: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,   // 👈 treating as PK since none defined in SQL
      autoIncrement: true // optional — remove if you don’t want auto increment
    },
    possession_of_land: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    land_area_in_square_metres: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    }
  }, {
  tableName: "land_landinstdetail", // 👈 exact table name
  timestamps: false, // no createdAt / updatedAt in your schema
});


LandInstDetail.hasOne(LandOwnedLand, {
  foreignKey: "appId",     // column in GetVerifications
  sourceKey: "appId",    // column in GET_VERIFICATION_LIST_BY_STEP
  as: "land_owner_info",
});


LandInstDetail.hasOne(LandLeasedLand, {
  foreignKey: "appId",     // column in GetVerifications
  sourceKey: "appId",    // column in GET_VERIFICATION_LIST_BY_STEP
  as: "leased_land_info",
});

LandInstDetail.hasOne(InitialLandArea, {
  foreignKey: "appId",     // column in GetVerifications
  sourceKey: "appId",    // column in GET_VERIFICATION_LIST_BY_STEP
  as: "initial_land_area",
});

LandInstDetail.hasMany(LandArea, {
  foreignKey: "appId",     // column in GetVerifications
  sourceKey: "appId",    // column in GET_VERIFICATION_LIST_BY_STEP
  as: "old_land_area",
});

LandInstDetail.hasOne(LandArea, {
  foreignKey: "appId",     // column in GetVerifications
  sourceKey: "appId",    // column in GET_VERIFICATION_LIST_BY_STEP
  as: "latest_land_area",
});









export default LandInstDetail;
