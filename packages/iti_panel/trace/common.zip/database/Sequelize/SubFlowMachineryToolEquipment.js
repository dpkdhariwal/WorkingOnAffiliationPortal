import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const SubFlowMachineryToolEquipment = sequelize.define(
  "SubFlowMachineryToolEquipment",
  {
    slno: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true, // remove if not auto-increment
    },
    stepNo: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    step: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    status: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    stepTitle: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    nextStep: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    stepStatus: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    stepLabel: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    userId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    tableName: "sub_flow_machinery_tool_equipment", // exact table name
    timestamps: false, // no createdAt/updatedAt
  }
);




export default SubFlowMachineryToolEquipment;
