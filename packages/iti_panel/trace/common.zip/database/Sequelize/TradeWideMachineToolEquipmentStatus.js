import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import MasterTradeInfo from "./tradeAreaInfo.js";

const TradeWideMachineToolEquipmentStatus = sequelize.define(
    "TradeWideMachineToolEquipmentStatus",
    {
        slno: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        userId: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        tradeId: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        status: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        stepNo: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        stepTitle: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        stepLabel: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        stepStatus: {
            type: DataTypes.ENUM("ACTIVE", "IN_ACTIVE"),
            allowNull: false,
            defaultValue: "IN_ACTIVE"
        },
        nextStep: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        submit_date:{
            type: DataTypes.DATE,
            allowNull:true
        }
    },
    {
        tableName: "tradewide_machine_tool_equipment_status",
        timestamps: false
    }
);


TradeWideMachineToolEquipmentStatus.belongsTo(MasterTradeInfo, {
    foreignKey: "tradeId",   // column in EntityAddress
    targetKey: "trade_id",     // PK in State model
    as: "tradeInfo",
});


export default TradeWideMachineToolEquipmentStatus;
