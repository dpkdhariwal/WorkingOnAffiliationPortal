import { Sequelize, DataTypes, Model } from "sequelize"
import { sequelize } from '../../config/database.js';
import MasterTradeInfo from "./tradeAreaInfo.js";
import MasterTradeToolEquipment from "./MasterTradeToolEquipment.js";

const TradeWiseToolEquipments = sequelize.define(
    "TradeWiseToolEquipments",
    {
        slno: {
            type: DataTypes.INTEGER(10),
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },
        trade_id: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        tool_id: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        availability: {
            type: DataTypes.ENUM("yes", "no"),
            allowNull: false,
        },
        required_quantity: {
            type: DataTypes.FLOAT,
            allowNull: false,
        },
        available_quantity: {
            type: DataTypes.INTEGER(11),
            allowNull: true,
        },
        submit_date: {
            type: DataTypes.DATE,
            allowNull: false,
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        userId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        status: {
            type: DataTypes.ENUM("FILLED", "NOT_FILLED"),
            allowNull: false,
        },
    },
    {
        tableName: "tradewise_tool_equipments",
        timestamps: false,
    }
);

TradeWiseToolEquipments.belongsTo(MasterTradeInfo, {
    foreignKey: "trade_id",   // column in EntityAddress
    targetKey: "trade_id",     // PK in State model
    as: "tradeInfo",
});


TradeWiseToolEquipments.belongsTo(MasterTradeToolEquipment, {
    foreignKey: "tool_id",   // column in EntityAddress
    targetKey: "slno",     // PK in State model
    as: "toolInfo",
});
export default TradeWiseToolEquipments;
