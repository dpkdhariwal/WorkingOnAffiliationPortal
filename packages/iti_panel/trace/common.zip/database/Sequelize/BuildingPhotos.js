import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import DAStageIVerificationsChecklist from "./DAStageIVerificationsChecklist.js";

const BuildingPhotos = sequelize.define("BuildingPhotos",
    {
        slno: {
            type: DataTypes.INTEGER(10),
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        uniqueId: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        as_per_norms:{
             type: DataTypes.ENUM(
                'yes',
                'no',
            ),
            allowNull: false
        },
        photoView: {
            type: DataTypes.ENUM(
                'front_view_photo_of_building',
                'side_view_photo_of_building',
                'entrance_gate_photo_of_plot_with_signage_board'
            ),
            allowNull: false
        },
        photo_pth: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        uploadDate: {
            type: DataTypes.DATE,
            allowNull: false
        }
    }, {
    tableName: 'bld_photos',
    timestamps: false,
    underscored: false
});


export default BuildingPhotos;
