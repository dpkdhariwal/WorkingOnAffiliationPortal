import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const LandConversionCertificates = sequelize.define("LandConversionCertificates", 
  {
  slno: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  appId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  language: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  document: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  notarised_document: {
    type: DataTypes.STRING(255),
    allowNull: true
  },
  timestamp: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  uploaded_datetime: {
    type: DataTypes.DATE,
    allowNull: false
  },
  file_meta_info: {
     type: DataTypes.JSON,
    allowNull: false
  }
}, {
  tableName: "land_conversion_certificates",  // keeping original name with space
  timestamps: false                   // we already have custom timestamps
});

export default LandConversionCertificates;
