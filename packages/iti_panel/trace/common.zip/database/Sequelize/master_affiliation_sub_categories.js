import { DataTypes } from "sequelize";
import { sequelize } from "../../config/database.js";

const MasterAffiliationSubCategory = sequelize.define(
  "MasterAffiliationSubCategory",
  {
    slno: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      allowNull: false,
      autoIncrement: true, // assuming slno is auto-increment
    },
    uniqueId: {
      type: DataTypes.STRING(255),
      allowNull: false,
      unique: true,
    },
    affiliation_catId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    cat_name: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    keyName: {
      type: DataTypes.ENUM(
        "Addition_Trades_Units",
        "Name_Change",
        "Shifting_Relocation",
        "Merger_of_ITIs",
        "SCVT_to_NCVET",
        "Renewal"
      ),
      allowNull: false,
    },
  },
  {
    tableName: "master_affiliation_sub_categories",
    timestamps: false,
  }
);

export default MasterAffiliationSubCategory;
