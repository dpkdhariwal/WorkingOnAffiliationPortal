import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const DAStageIVerificationsChecklist = sequelize.define(
  "DAStageIVerificationsChecklist",
  {
    slno: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    uniqueId: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    reffNumber: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    assessment_id: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    checkName: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    da_status: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    step: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    update_date: {
      type: DataTypes.DATE,
      allowNull: true
    },
    reviewDate: {
      type: DataTypes.DATE,
      allowNull: true
    }
  },
  {
    tableName: "da_stage_i_verifications_checklist",
    timestamps: false // since your table has no createdAt/updatedAt
  }
);

export default DAStageIVerificationsChecklist;
