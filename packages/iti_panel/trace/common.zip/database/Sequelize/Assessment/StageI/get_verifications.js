import { DataTypes } from "sequelize"
import { sequelize } from '../../../../config/database.js';

const GetVerifications = sequelize.define(
  "GetVerifications",
  {
    slno: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true, // usually for int PK
      allowNull: false,
    },
    uniqueId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    reffNumber: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    assessment_id: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    keyName: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    step: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    as_per_norms: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    reason: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    assessor_comments: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    isDraft: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    insertDate: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    reviewDate: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    updateDate: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    recordType: {
      type: DataTypes.ENUM("PRESENT", "HISTORY"),
      allowNull: false,
    },
    reff_uniquId:{
      type: DataTypes.STRING(255),
      allowNull:false
    }
  },
  {
    tableName: "da_stage_i_verifications",
    timestamps: false, // table has its own insertDate/updateDate
  }
);

export default GetVerifications;

