import { DataTypes, Sequelize } from "sequelize"
import { sequelize } from '../../../../config/database.js';
import GetVerifications from "./get_verifications.js"
import LandOwnedLand from "../../LandOwnedLand.js";
import LandDocuments from "../../land_documents.js";
import LandArea from "../../LandArea.js";
import AuthorizedSignatoryDetail from "../../AuthorizedSignatoryDetail.js";
import Certificat from "../../Certificat.js";
import SecretaryChairpersonPresidentIdInfo from "../../SecretaryChairpersonPresidentIdInfo.js";
import Stage1Documents from "../../stage1_documents.js";
import InitialLandArea from "../../InitialLandArea.js";
import InitialAuthorizedSignatoryDetails from "../../initial_authorized_signatory_details.js";
import InitialCertificats from "../../initial_certificats.js";
import InitialSecretaryChairpersonPresidentIdInfo from "../../initial_secretary_chairperson_president_id_info.js";
const GET_VERIFICATION_LIST_BY_STEP = sequelize.define(
    "GET_VERIFICATION_LIST_BY_STEP",
    {
        slno: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        reffNumber: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        checkName: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        da_status: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        step: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        assessment_id: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
    },
    {
        tableName: "da_stage_i_verifications_checklist",
        timestamps: false,
    }
);

GET_VERIFICATION_LIST_BY_STEP.hasOne(GetVerifications, {
    foreignKey: "keyName",     // column in GetVerifications
    sourceKey: "checkName",    // column in GET_VERIFICATION_LIST_BY_STEP
    as: "Verificiation",
});


GET_VERIFICATION_LIST_BY_STEP.hasOne(LandOwnedLand, {
    foreignKey: "appId",     // column in GetVerifications
    sourceKey: "appId",    // column in GET_VERIFICATION_LIST_BY_STEP
    as: "land_owner_info",
});


GET_VERIFICATION_LIST_BY_STEP.hasMany(Stage1Documents, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "init_land_documents"
});

GET_VERIFICATION_LIST_BY_STEP.hasMany(LandDocuments, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "old_land_documents"
});

GET_VERIFICATION_LIST_BY_STEP.hasMany(LandDocuments, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "latest_land_documents"
});


GET_VERIFICATION_LIST_BY_STEP.hasOne(InitialLandArea, {
    foreignKey: "appId",     // column in GetVerifications
    sourceKey: "appId",    // column in GET_VERIFICATION_LIST_BY_STEP
    as: "initial_land_area",
});

GET_VERIFICATION_LIST_BY_STEP.hasMany(LandArea, {
    foreignKey: "appId",     // column in GetVerifications
    sourceKey: "appId",    // column in GET_VERIFICATION_LIST_BY_STEP
    as: "old_land_area",
});

GET_VERIFICATION_LIST_BY_STEP.hasOne(LandArea, {
    foreignKey: "appId",     // column in GetVerifications
    sourceKey: "appId",    // column in GET_VERIFICATION_LIST_BY_STEP
    as: "latest_land_area",
});



// authorized_signatory_details Start

GET_VERIFICATION_LIST_BY_STEP.hasOne(InitialAuthorizedSignatoryDetails, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "init_auth_signatory_detail"
});

GET_VERIFICATION_LIST_BY_STEP.hasMany(AuthorizedSignatoryDetail, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "old_auth_signatory_detail"
});

GET_VERIFICATION_LIST_BY_STEP.hasOne(AuthorizedSignatoryDetail, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "latest_auth_signatory_detail"
});


//certificats
GET_VERIFICATION_LIST_BY_STEP.hasOne(InitialCertificats, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "init_certificate"
});

GET_VERIFICATION_LIST_BY_STEP.hasMany(Certificat, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "old_certificate"
});

GET_VERIFICATION_LIST_BY_STEP.hasOne(Certificat, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "latest_certificate"
});




//secretary_chairperson_president_id_info

GET_VERIFICATION_LIST_BY_STEP.hasMany(InitialSecretaryChairpersonPresidentIdInfo, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "init_scp"
});

GET_VERIFICATION_LIST_BY_STEP.hasMany(SecretaryChairpersonPresidentIdInfo, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "old_scp"
});

GET_VERIFICATION_LIST_BY_STEP.hasMany(SecretaryChairpersonPresidentIdInfo, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "latest_scp"
});
//End




export default GET_VERIFICATION_LIST_BY_STEP;

