// models/nocIssuedNocDetail.js
import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import MasterTradeInfo from "./tradeAreaInfo.js";


const NocIssuedNocDetail = sequelize.define(
    "NocIssuedNocDetail",
    {
        slno: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true, // usually best practice for int PK
            allowNull: false,
        },
        tradeId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        issued_unit_in_shift1: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        issued_unit_in_shift2: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        issued_unit_in_shift3: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        issued_date_time: {
            type: DataTypes.DATE,
            allowNull: false,
        },
    },
    {
        tableName: "noc_issued_noc_detail",
        timestamps: false, // table does not have createdAt/updatedAt
    }
);

NocIssuedNocDetail.belongsTo(MasterTradeInfo, {
    foreignKey: "tradeId",   // column in EntityAddress
    targetKey: "trade_id",     // PK in State model
    as: "tradeInfo",
});
export default NocIssuedNocDetail;
