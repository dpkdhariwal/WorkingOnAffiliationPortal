import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const AmenitiesParticulars = sequelize.define(
    "AmenitiesParticulars",
    {
        slno: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true, // assuming you want it auto-increment
        },
        status: {
            type: DataTypes.ENUM(
                "FILLED",
                "NOT_FILLED",
            ),
            allowNull: true,
        },
        particular: {
            type: DataTypes.ENUM(
                "First-Aid Room",
                "Library & reading room",
                "Playground",
                "Drinking water facility",
                "Availability of staircases",
                "Toilets/Water Closets",
                "General Parking Details"
            ),
            allowNull: false,
        },
        instruction: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        required_area: {
            type: DataTypes.FLOAT,
            allowNull: true,
        },
        available_area: {
            type: DataTypes.FLOAT,
            allowNull: true,
        },
        AreaUnit: {
            type: DataTypes.ENUM('sq. m'),
            allowNull: true,
        },
        availability: {
            type: DataTypes.ENUM('yes', 'no'),
            allowNull: true,
        },
        document: {
            type: DataTypes.STRING(255),
            allowNull: true,
        },
        submit_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        userId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
    },
    {
        tableName: "amenities_particulars",
        timestamps: false, // since no createdAt/updatedAt in table
    }
);

export default AmenitiesParticulars;
