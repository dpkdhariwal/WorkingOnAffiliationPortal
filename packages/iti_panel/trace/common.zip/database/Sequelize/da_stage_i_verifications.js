import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const DaStageIVerification = sequelize.define(
    "DaStageIVerification",
    {
        slno: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        reffNumber: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        assessment_id: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        keyName: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        as_per_norms: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        reason: {
            type: DataTypes.TEXT, // longer comments supported
            allowNull: true,
        },
        assessor_comments: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        isDraft: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false,
        },
        insertDate: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: DataTypes.NOW,
        },
        updateDate: {
            type: DataTypes.DATE,
            allowNull: true,
        },
    },
    {
        tableName: "da_stage_i_verifications",
        timestamps: false, // since you're managing insertDate/updateDate manually
    }
);
export default DaStageIVerification;
