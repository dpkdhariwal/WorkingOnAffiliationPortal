import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';
import MasterTradeInfo from "./tradeAreaInfo.js";

const GstInvoicesMachineryPayment = sequelize.define(
    "GstInvoicesMachineryPayment",
    {
        slno: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true, // assuming you want this to auto-increment
        },
        uniqueId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        tradeId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        appId: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        document: {
            type: DataTypes.STRING(255),
            allowNull: true,
        },
        submit_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM("FILLED", "NOT_FILLED"),
            allowNull: true,
            defaultValue: "NOT_FILLED",
        },
    },
    {
        tableName: "gst_invoices_machinery_payment",
        timestamps: false, // no createdAt or updatedAt in the table
    }
);


GstInvoicesMachineryPayment.belongsTo(MasterTradeInfo, {
    foreignKey: "tradeId",   // column in EntityAddress
    targetKey: "trade_id",     // PK in State model
    as: "tradeInfo",
});
export default GstInvoicesMachineryPayment;
