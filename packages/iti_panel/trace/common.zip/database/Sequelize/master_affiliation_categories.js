import { DataTypes } from "sequelize";
import { sequelize } from "../../config/database.js";

const MasterAffiliationCategory = sequelize.define(
  "MasterAffiliationCategory",
  {
    slno: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      allowNull: false,
      autoIncrement: true, // assuming slno is auto-increment
    },
    uniqueId: {
      type: DataTypes.STRING(255),
      allowNull: false,
      unique: true,
    },
    cat_name: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    keyName: {
      type: DataTypes.ENUM(
        "NEW_ITIS",
        "MSTI",
        "NEW_AGE",
        "DST",
        "Surrender_Trade_Units",
        "Existing_ITIs"
      ),
      allowNull: false,
    },
  },
  {
    tableName: "master_affiliation_categories",
    timestamps: false, // table has no createdAt/updatedAt
  }
);

export default MasterAffiliationCategory;
