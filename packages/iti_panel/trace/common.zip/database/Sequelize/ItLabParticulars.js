import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const ItLabParticulars = sequelize.define(
  "ItLabParticulars",
  {
    slno: {
      type: DataTypes.INTEGER(10),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    particular: {
      type: DataTypes.ENUM(
        "DESKTOP_COMPUTER_WITH_LATEST_CONFIGURATION",
        "INTERNET_CONNECTION",
        "COMPUTER_WITH_MULTIMEDIA_ANTI_VIRUS_ETC",
        "LAN_CABLING_ETC",
        "PRINTER_LASER",
        "SCANNER",
        "SERVER",
        "EXTERNAL_HARD_DISK_1TB",
        "INSTRUCTOR_OFFICE_CHAIR",
        "INSTRUCTOR_OFFICE_TABLE",
        "TRAINEES_COMPUTER_CHAIRS",
        "TRAINEES_COMPUTER_TABLES",
        "BLACK_WHITE_BOARD_4X6_FEET"
      ),
      allowNull: false,
    },
    instruction: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    required_qty: {
      type: DataTypes.FLOAT,
      allowNull: true,
    },
    available_qty: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
    },
    AreaUnit: {
      type: DataTypes.ENUM("sq. m"),
      allowNull: true,
    },
    availability: {
      type: DataTypes.ENUM("yes", "no"),
      allowNull: true,
    },
    submit_date: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    userId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    tableName: "it_lab_particulars",
    timestamps: false,
  }
);

export default ItLabParticulars;
