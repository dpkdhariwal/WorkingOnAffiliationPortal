import { DataTypes } from "sequelize"
import { sequelize } from '../../config/database.js';

const CommonCivilInfrastructure = sequelize.define(
  "CommonCivilInfrastructure",
  {
    slno: {
      type: DataTypes.INTEGER(10),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    category: {
      type: DataTypes.ENUM("CIVIL", "AMENITIES"),
      allowNull: false,
    },
    particular: {
      type: DataTypes.ENUM(
        "MULTIPURPOSE_HALL",
        "IT_LAB",
        "LIBRARY",
        "PLACEMENT_AND_COUNSELLING_ROOM",
        "PRINCIPAL_ROOM",
        "RECEPTION_CUM_WAITING_LOBBY",
        "STAFF_ROOM",
        "ADMINISTRATIVE_HALL_SECTION",
        "First-Aid Room",
        "Library & reading room",
        "IT_LAB" // note: duplicate IT_LAB in original SQL, optional to remove
      ),
      allowNull: false,
    },
    required_area: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    available_area: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
    },
    AreaUnit: {
      type: DataTypes.ENUM("sq. m"),
      allowNull: true,
      field: "AreaUnit",
    },
    appId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    submit_date: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    document: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    userId: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    tableName: "common_civil_infrastructure",
    timestamps: false,
  }
);

export default CommonCivilInfrastructure;
