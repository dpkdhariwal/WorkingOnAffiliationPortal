import { DataTypes } from "sequelize"

import { sequelize } from '../../config/database.js';
import Stage1Documents from "./stage1_documents.js";
import LandDocuments from "./land_documents.js";
const LandOwnedLand = sequelize.define("LandOwnedLand", {
  slno: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true, // 👈 since no PK defined in your SQL, using slno
    autoIncrement: true, // optional, if slno should auto-increment
  },
  land_owner_name: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  land_registration_number: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  appId: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
}, {
  tableName: "land_owned_lands", // 👈 match your table name
  timestamps: false, // no createdAt / updatedAt in your schema
});


LandOwnedLand.hasMany(Stage1Documents, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "init_land_documents"
});

LandOwnedLand.hasMany(LandDocuments, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "old_land_documents"
});

LandOwnedLand.hasMany(LandDocuments, {
    foreignKey: "appId",
    sourceKey: "appId",
    as: "latest_land_documents"
});

export default LandOwnedLand;
