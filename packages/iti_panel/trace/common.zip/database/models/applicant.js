import dotenv from "dotenv";
// Load correct .env file based on NODE_ENV
dotenv.config({ path: `.env.${process.env.NODE_ENV || "development"}`, });
/* eslint-disable no-undef */
import jwt from "jsonwebtoken";
import fs from "fs";
import path from "path";

const dir = path.join("uploads");
import mysql from "mysql2/promise";
import { pKeyPath } from "../../common/common.js";
import { masterConfig, eMsg, dbConfig, affDbConfig } from "../db.js";
import { Op } from "sequelize";


const privateKey = fs.readFileSync(pKeyPath, "utf8");
import * as cons from "../../constant/constants.js";
import { throws } from "assert";

import dayjs from "dayjs";
import utc from "dayjs/plugin/utc.js";
import timezone from "dayjs/plugin/timezone.js";
import { upload, upload2 } from "../../services/multer/configs.js";

import { pid } from "../../index.js";
import { landDetail } from "../../index.js";

dayjs.extend(utc);
dayjs.extend(timezone);
let updateDate;
export const formattedDate = dayjs().tz("Asia/Kolkata").toISOString();
export const submitDate = updateDate = dayjs().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
// console.log("ISO India:", formattedDate);

import { sequelize } from '../../config/database.js';

import AppFlow from "../Sequelize/AppFlow.js";
import AppFormSubCivilInfra from "../Sequelize/AppFormSubCivilInfra.js";
import { EntEntityDetails, ProposedInstituteAddressesDetails } from "../Sequelize/index.js";
import EntityAddress from "../Sequelize/EntityAddress.js";
import EntOtherITI from "../Sequelize/EntOtherITI.js";
import FormFlowStageI from "../Sequelize/FormFlowStageI.js";
import FormFlowStageII from "../Sequelize/FormFlowStageII.js";

import PIA_Details from "../Sequelize/ProposedInstituteAddressesDetails.js";
import PIDetails from "../Sequelize/ProposedProposedInstituteDetails.js";



import LandInstDetail from "../Sequelize/LandInstDetail.js";
import LandLeasedLand from "../Sequelize/LandLeasedLand.js";
import LandOwnedLand from "../Sequelize/LandOwnedLand.js";

import ElectricityModel from "../Sequelize/ElectricityDetails.js";
import ElectricityDocuments from "../Sequelize/ElectricityDocuments.js";




import { st1form } from "../../index.js";
import TradeAreaInfo from "../Sequelize/tradeAreaInfo.js";
import MasterTradeInfo from "../Sequelize/tradeAreaInfo.js";
import TradesNewInstTrades from "../Sequelize/tradesNewInstTrades.js";

import get from "lodash.get";
import LeaseDeedDocument from "../Sequelize/LeaseDeedDocument.js";
import LandConversionCertificates from "../Sequelize/LandConversionCertificates.js";
import AuthorizedSignatoryDetail from "../Sequelize/AuthorizedSignatoryDetail.js";
import Certificat from "../Sequelize/Certificat.js";
import SecretaryChairpersonPresidentIdInfo from "../Sequelize/SecretaryChairpersonPresidentIdInfo.js";
import ProposedProposedInstituteDetails from "../Sequelize/ProposedProposedInstituteDetails.js";
import LandDocuments from "../Sequelize/land_documents.js";
import Stage1Documents from "../Sequelize/stage1_documents.js";
import InitialCertificats from "../Sequelize/initial_certificats.js";
import InitialAuthorizedSignatoryDetails from "../Sequelize/initial_authorized_signatory_details.js";
import InitialSecretaryChairpersonPresidentIdInfo from "../Sequelize/initial_secretary_chairperson_president_id_info.js";
import AppAssessmentFlowStageI from "../Sequelize/AppAssessmentFlowStageI.js";
import AssessmentStatus from "../Sequelize/AssessmentStatus.js";
import LandArea from "../Sequelize/LandArea.js";
import DAStageIVerificationsChecklist from "../Sequelize/DAStageIVerificationsChecklist.js";
import State from "../Sequelize/State.js";
import District from "../Sequelize/districts.js";
import VilDistrictSubDistrict from "../Sequelize/villages_district_sub_districts.js";
import MasterAffiliationCategory from "../Sequelize/master_affiliation_categories.js";
import MasterAffiliationSubCategory from "../Sequelize/master_affiliation_sub_categories.js";
import InitialLandArea from "../Sequelize/InitialLandArea.js";
import { Sequelize } from 'sequelize';
import TradewiseWorkshop from "../Sequelize/TradewiseWorkShop.js";
import BuildingPlan from "../Sequelize/BuildingPlan.js";
import BccDocuments from "../Sequelize/BccDocuments.js";
import BuildingPhotos from "../Sequelize/BuildingPhotos.js";
import TradewiseClassRoom from "../Sequelize/TradewiseClassRoom.js";
import CommonCivilInfrastructure from "../Sequelize/CommonCivilInfrastructure.js";
import ItLabParticulars from "../Sequelize/ItLabParticulars.js";
import SubFlowMachineryToolEquipment from "../Sequelize/SubFlowMachineryToolEquipment.js";
import MasterTradeToolEquipment from "../Sequelize/MasterTradeToolEquipment.js";
import TradeWiseToolEquipments from "../Sequelize/TradeWiseToolEquipments.js";
import TradeWideMachineToolEquipmentStatus from "../Sequelize/TradeWideMachineToolEquipmentStatus.js";
import AmenitiesParticulars from "../Sequelize/AmenitiesParticulars .js";
import SignageBoardsParticulars from "../Sequelize/SignageBoardsParticulars .js";
import GstInvoicesMachineryPayment from "../Sequelize/GstInvoicesMachineryPayment.js";
import GeoTaggedPhotoOfMTE from "../Sequelize/GeoTaggedPhotoOfMTE.js";


export const setEntityDetails = async (req, res) => {
  let connection, stmt, results, update, formattedDate, jsonData, userId, submitDate, updateDate;
  // formattedDate = new Date().toISOString(); // "2025-08-05T07:25:13.123Z"
  // submitDate = new Date().toISOString().slice(0, 19).replace('T', ' ');

  formattedDate = dayjs().tz("Asia/Kolkata").toISOString();
  // console.log("ISO India:", formattedDate);

  submitDate = updateDate = dayjs().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

  // console.log("MySQL India:", submitDate);
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  const t = await sequelize.transaction();
  try {
    // connection = await mysql.createConnection(affDbConfig);
    const { data, appId } = req.body;
    const { email } = req.user;
    userId = req.userInfo.user_id;
    jsonData = JSON.parse(data);


    // Create directory if it doesn't exist
    const dir = path.join(process.env.TEMP_FILES_UPLOAD_PATH, appId);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      console.log("Directory created:", dir);
    } else {
      console.log("Directory already exists:", dir);
    }
    // End

    // Converting in Sequelize Object
    const found = await AppFlow.findOne({ where: { appId: appId } });
    if (!found) {
      const mainStepsData = cons.AppFlow.map((step) => ({ ...step, appId: appId, userId: userId, }));
      await AppFlow.bulkCreate(mainStepsData, { transaction: t });
    }


    // Settign Up Stage I Form Flow
    const found2 = await FormFlowStageI.findOne({ where: { appId: appId } });
    if (!found2) {
      const mainStepsData = cons.STAGE_I_APP_FORM_FLOW.map((step) => {
        switch (step.step) {
          case cons.ST1FC.APPLICANT_ENTITY_DETAILS.step:
            return { ...step, status: cons.FILLED, submitDate: cons.currentDate, appId: appId, userId: userId, }
          case cons.ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step:
            return { ...step, stepStatus: cons.SL.ACTIVE, appId: appId, userId: userId }
          default:
            return { ...step, appId: appId, userId: userId, }
        }

      });
      await FormFlowStageI.bulkCreate(mainStepsData, { transaction: t });
      // throw mainStepsData;
    }



    // Settign Up Stage I Form Flow
    const found3 = await FormFlowStageII.findOne({ where: { appId: appId } });
    if (!found3) {
      const mainStepsData = cons.STAGE_II_APP_FORM_FLOW.map((step) => {
        switch (step.step) {
          case cons.BUILDING_DETAIL:
            return { ...step, status: cons.FILLED, submitDate: cons.currentDate, appId: appId, userId: userId, }
          case cons.CIVIL_INFRASTRUCTURE_DETAIL:
            return { ...step, stepStatus: cons.SL.ACTIVE, appId: appId, userId: userId }
          default:
            return { ...step, appId: appId, userId: userId, }
        }
      });
      await FormFlowStageII.bulkCreate(mainStepsData, { transaction: t });
      // Setting Sub Steps
      for (const [index, flow] of mainStepsData.entries()) {
        if ("subSteps" in flow) {
          switch (flow.step) {
            case cons.CIVIL_INFRASTRUCTURE_DETAIL:
              const mainStepsData = flow.subSteps.map((step) => ({ ...step, appId: appId, userId: userId, }));
              await AppFormSubCivilInfra.bulkCreate(mainStepsData, { transaction: t });
            default:
              break;
          }
        }
      }
    }


    const found5 = await EntEntityDetails.findOne({ where: { appId: appId } });

    const toSave = {
      aff_category: jsonData.aff_category,
      aff_sub_category: jsonData.aff_sub_category,
      category: jsonData.category,
      name_of_applicant_entity: jsonData.name_of_applicant_entity,
      ApplicantEntityEmailId: jsonData.ApplicantEntityEmailId,
      isApplicantEntityEmailIdVerified: jsonData.isApplicantEntityEmailIdVerified,
      ApplicantContactNumber: jsonData.ApplicantContactNumber,
      Is_the_applicant_running_any_other_iti: jsonData.Is_the_applicant_running_any_other_iti,
      appId: appId,
      userId: userId
    }
    if (found5) {
      await EntEntityDetails.update(toSave, { where: { appId } }); // 👈 here
      console.log("✅ Updated existing record");
    } else {
      await EntEntityDetails.create(toSave);
      console.log("✅ Inserted new record");
    }


    // Save Entity Address
    const toSave2 = {
      state_code: jsonData.ApplicantEntityState,
      district_code: jsonData.ApplicantEntityDistrict,
      sub_district_code: jsonData.ApplicantEntitySubDistrict,
      village_code: jsonData.ApplicantEntityVillage,
      pincode: jsonData.ApplicantEntityPincode,
      plotNumber_khasaraNumber_gataNumber: jsonData.ApplicantEntityPlotNumber_KhasaraNumber_GataNumber,
      landmark: jsonData.ApplicantEntityLandmark,
      town_city: jsonData.ApplicantEntityTown_City,
      Block: jsonData.ApplicantEntityAddressBlock,
      appId: appId,
      userId: userId
    }
    const found6 = await EntityAddress.findOne({ where: { appId: appId } });
    if (found6) {
      await EntityAddress.update(toSave2, { where: { appId } }); // 👈 here
      console.log("✅ Updated existing record");
    } else {
      await EntityAddress.create(toSave2);
      console.log("✅ Inserted new record");
    }

    if (jsonData.Is_the_applicant_running_any_other_iti === "yes") {
      await EntOtherITI.destroy({ where: { appId }, transaction: t });
      const mainStepsData = jsonData.runningITIs.map((obj) => ({ ...obj, appId: appId, userId: userId, }));

      // throw mainStepsData;

      await EntOtherITI.bulkCreate(mainStepsData, { transaction: t });
    }
    else if (jsonData.Is_the_applicant_running_any_other_iti === "no") {
      await EntOtherITI.destroy({ where: { appId }, transaction: t });
    }

    await t.commit();
    console.log("Multiple records inserted within transaction ✅");

  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    // if (connection) await connection.end();
  }
  return { msg: "Information Successfully" };

};



export const getAppListByUserId = async (req, res) => {
  let connection, stmt, results, update, formattedDate, jsonData, userId, submitDate, updateDate;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  let enrichedApps;
  try {

    connection = await mysql.createConnection(affDbConfig);

    const { data, appId } = req.body;
    userId = req.userInfo.user_id;
    const { state, userType, state_code } = req.userInfo;


    // throw req.userInfo;



    // const list = await EntEntityDetails.findAll({
    //   where: {},
    //   include: [
    //     {
    //       model: ProposedProposedInstituteDetails,
    //       as: "proposedInstitute",  // matches hasOne alias
    //       required: false
    //     }
    //   ]
    // });

    // throw lsit;


    // throw req.userInfo;


    let sel_entity_details, result, finalResult;
    await connection.beginTransaction();
    // return userType;
    switch (userType) {
      case "applicant":
        sel_entity_details = await connection.prepare('SELECT * FROM `' + cons.ENTITY_DETAILS + '` WHERE userId = ?');
        result = await sel_entity_details.execute([userId]);
        finalResult = result[0];
        break;
      case "dgt":
        sel_entity_details = await connection.prepare('SELECT * FROM `' + cons.ENTITY_DETAILS + '` WHERE 1');
        result = await sel_entity_details.execute([userId]);
        finalResult = result[0];
        break;
      case "rdsde":
        sel_entity_details = await connection.prepare('SELECT * FROM `' + cons.ENTITY_DETAILS + '` WHERE 1');
        result = await sel_entity_details.execute([userId]);
        finalResult = result[0];
        break;
      case "state_admin":
        sel_entity_details = await connection.prepare('SELECT * FROM `' + cons.ENTITY_DETAILS + '` WHERE 1');
        result = await sel_entity_details.execute([userId]);
        finalResult = result[0];
        break;
      case "state_assessor":

        // // One-to-One relationship (adjust if it should be One-to-Many)
        // let found3 = EntEntityDetails.hasOne(ProposedProposedInstituteDetails, {
        //   foreignKey: "appId",      // field in ProposedProposedInstituteDetails
        //   sourceKey: "appId",       // field in EntEntityDetails
        //   as: "proposedInstitute"   // alias used in include
        // });

        // throw found3;
        // throw state_code;
        sel_entity_details = await connection.prepare(`SELECT t1.*, t2.state_code FROM ent_entitydetails as t1 JOIN proposed_proposedinstituteaddressesdetails as t2 on t1.appId=t2.appId and t2.state_code=?`);
        result = await sel_entity_details.execute([state_code]);
        finalResult = result[0];
        break;
      default:
        throw new Error("User Profile is Incorrect");
        break;
    }
    // return state;
    if (!finalResult || finalResult.length === 0) {
      throw new Error("Applications Not Found");
    }

    enrichedApps = await Promise.all(
      finalResult.map(async (app) => {
        const entityDetails = await getEntityDetailsByUserId(req, res, connection, app.appId); // <-- await here!
        const proposedInstDetails = await getProposedInstDetailsByUserId(req, res, connection, app.appId);
        return { ...app, ...entityDetails, proposedInstDetails, };
      })
    );

    // Commit the transaction
    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }

  return enrichedApps;


};

export const getAppListByStateUser = async (req, res) => {
  let connection, stmt, results, update, formattedDate, jsonData, userId, submitDate, updateDate;

  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {

    connection = await mysql.createConnection(affDbConfig);

    const { data, appId } = req.body;
    userId = req.userInfo.user_id;


    await connection.beginTransaction();

    stmt = await connection.prepare('SELECT * FROM `' + cons.ENTITY_DETAILS + '` WHERE 1');


    let [result] = await stmt.execute([userId]);
    if (!result || result.length === 0) {
      throw new Error("Applications Not Found");
    }

    // return result;
    const enrichedApps = await Promise.all(
      result.map(async (app) => {
        const entityDetails = await getEntityDetailsByUserId(req, res, connection, app.appId); // <-- await here!
        const proposedInstDetails = await getProposedInstDetailsByUserId(req, res, connection, app.appId);
        return { ...app, ...entityDetails, proposedInstDetails, };
      })
    );



    //  const db = await initDB();
    // let result = await db.getAllFromIndex(cons.ENTITY_DETAILS, "userId", userId);

    // const enrichedApps = await Promise.all(
    //   result.map(async (app) => {
    //     const entityDetails = await getEntityDetailsByUserId(app.appId); // <-- await here!
    //     const proposedInstDetails = await getProposedInstDetailsByUserId(
    //       app.appId
    //     );
    //     return {
    //       ...app,
    //       entityDetails,
    //       proposedInstDetails,
    //     };
    //   })
    // );
    // return enrichedApps; // Now includes full entity details, not Promises



    // Commit the transaction
    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return enrichedApps;


};

export const getDbEntityDetails = async (req, res) => {
  let finalResult, userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;

    const found1 = await EntEntityDetails.findOne({ where: { appId: appId } });
    const found2 = await EntityAddress.findOne({ where: { appId: appId } });
    const found3 = await EntOtherITI.findAll({
      where: { appId: appId }, include: [
        {
          model: District,
          as: "district_list",
          where: Sequelize.and(
            Sequelize.where(
              Sequelize.col('EntOtherITI.run_State'),
              Sequelize.col('district_list.stateCode')
            ),
            Sequelize.where(
              Sequelize.col('EntOtherITI.run_District'),
              Sequelize.col('district_list.districtCode')
            )
          ),
          required: false,
          separate: false,   // fetch in separate query
          limit: 1          // only 1 row per EntOtherITI
        },
        {
          attributes: [
            'districtCode',
            'districtNameEnglish',
            'stateCode',
            'subdistrictCode',
            'subdistrictNameEnglish'
          ],
          model: VilDistrictSubDistrict,
          as: "sub_district_list",
          where: Sequelize.and(
            Sequelize.where(
              Sequelize.col('EntOtherITI.run_State'),
              Sequelize.col('sub_district_list.stateCode')
            ),
            Sequelize.where(
              Sequelize.col('EntOtherITI.run_District'),
              Sequelize.col('sub_district_list.districtCode')
            ),
            Sequelize.where(
              Sequelize.col('EntOtherITI.run_SubDistrict'),
              Sequelize.col('sub_district_list.subdistrictCode')
            )
          ),
          required: false,
          separate: false,   // fetch in separate query
          limit: 1
        },
        {
          model: VilDistrictSubDistrict,
          as: "village_list",
        }
      ]
    });

    const obj1 = {
      aff_category: found1.aff_category,
      aff_sub_category: found1.aff_sub_category,
      category: found1.category,
      name_of_applicant_entity: found1.name_of_applicant_entity,
      ApplicantEntityEmailId: found1.ApplicantEntityEmailId,
      isApplicantEntityEmailIdVerified: found1.isApplicantEntityEmailIdVerified,
      ApplicantContactNumber: found1.ApplicantContactNumber,
      isApplicantEntityMobileNumberVerified: true,
      Is_the_applicant_running_any_other_iti: found1.Is_the_applicant_running_any_other_iti
    }
    const obj2 = {
      ApplicantEntityState: found2.state_code,
      ApplicantEntityDistrict: found2.district_code,
      ApplicantEntitySubDistrict: found2.sub_district_code,
      ApplicantEntityVillage: found2.village_code,
      ApplicantEntityPincode: found2.pincode,
      ApplicantEntityPlotNumber_KhasaraNumber_GataNumber: found2.plotNumber_khasaraNumber_gataNumber,
      ApplicantEntityLandmark: found2.landmark,
      ApplicantEntityTown_City: found2.town_city,
      ApplicantEntityAddressBlock: found2.Block,
    }
    const arrayList = found3.map((item) => {
      return item;
      // return { 
      //   run_AffiliationNo: '',
      //   run_ITIName: item.run_ITIName,
      //   run_MISCode: item.run_MISCode,
      //   run_State: item.run_State,
      //   run_District: item.run_District,
      //   run_SubDistrict: '',
      //   run_Village: '',
      //   run_TownCity: item.run_TownCity,
      //   run_Pincode: item.run_Pincode,
      //   run_PlotNumber_KhasaraNumber: item.run_PlotNumber_KhasaraNumber,
      //   run_Landmark: item.run_Landmark
      // };
    });
    // throw arrayList;
    finalResult = { ...st1form.initialValues, ...obj1, ...obj2, runningITIs: arrayList.length > 0 ? arrayList : [st1form.runningITI_Obj], };
    // throw found1;
    // throw found2;
    // throw found3;
  } catch (err) {
    throw err;
  } finally {
    // if (connection) await connection.end();
  }
  return finalResult;

};

export const getEntityDetailsByUserId = async (req, res, connection, appId) => {

  let stmt, results, update, formattedDate, jsonData, userId, submitDate, updateDate;
  let l1, l2, l3;
  try {

    userId = req.userInfo.user_id;

    // const pool = mysql.createPool(masterConfig);
    // connection = await pool.getConnection();

    // await connection.beginTransaction();

    let sel_entity_details = await connection.prepare('SELECT * FROM `' + cons.ENTITY_DETAILS + '` WHERE appId = ?');
    let sel_entity_address = await connection.prepare('SELECT * FROM `' + cons.ENTITY_ADDRESS + '` WHERE appId = ?');
    let sel_other_iti = await connection.prepare('SELECT * FROM `' + cons.OTHER_ITI + '` WHERE appId = ?');


    let rows;
    rows = await sel_entity_details.execute([appId]);

    l1 = rows[0];

    rows = await sel_entity_address.execute([appId]);
    l2 = rows[0];


    rows = await sel_other_iti.execute([appId]);
    l3 = rows[0];

    // Commit the transaction
    // await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    // if (connection) {
    //   await connection.rollback();
    // }
    throw err;
  } finally {
    // if (connection) await connection.end();
  }
  return { entity_details: l1[0] || {}, entity_address: l2, other_iti: l3, };

};



export const getProposedInstDetailsByUserId = async (req, res, connection, appId) => {
  let l1, l2;
  try {
    let stmt, results, update, formattedDate, jsonData, userId, submitDate, updateDate;
    userId = req.userInfo.user_id;
    // const pool = mysql.createPool(masterConfig);
    // connection = await pool.getConnection();
    // await connection.beginTransaction();
    let proposed_insti_details = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_DETAILS + '` WHERE appId = ?');
    let proposed_insti_addresses = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_ADDRESSES + '` WHERE appId = ?');

    let rows;
    rows = await proposed_insti_details.execute([appId]);
    l1 = rows[0];

    rows = await proposed_insti_addresses.execute([appId]);
    l2 = rows[0];
    // Commit the transaction
    // await connection.commit();
    // connection.release();

  } catch (err) {
    console.error("Error in checkUser:", err);
    // if (connection) {
    //   await connection.rollback();
    // }
    throw err;
  } finally {
    // if (connection) await connection.end();
  }

  return { pro_insti_details: l1[0] || {}, pro_insti_address: l2, };


  // const db = await initDB();
  // let l1 = await db.getAllFromIndex(PROPOSED_INSTI_DETAILS, "appId", appId);
  // let l2 = await db.getAllFromIndex(PROPOSED_INSTI_ADDRESSES, "appId", appId);
  // return {
  //   pro_insti_details: l1[0] || {},
  //   pro_insti_address: l2,
  // };
};


// export const setProposedInstDetails = async (req, res) => {
//   let connection, stmt, results, update, formattedDate, jsonData, userId, stepInfo;
//   const t = await sequelize.transaction();
//   try {

//     // connection = await mysql.createConnection(affDbConfig);

//     const { step, data, appId } = req.body;
//     userId = req.userInfo.user_id;

//     jsonData = JSON.parse(data);
//     stepInfo = JSON.parse(step);


//     const found5 = await PIA_Details.findOne({ where: { appId: appId }, transaction: t });
//     const toSave = {
//       state_code: jsonData.cmp_post_state,
//       district_code: jsonData.cmp_post_district,
//       sub_district_code: jsonData.cmp_post_sub_district,
//       village_code: jsonData.cmp_post_village,
//       pincode: jsonData.cmp_post_pincode,
//       plotNumber_khasaraNumber: jsonData.cmp_post_plot_number_khasara_number,
//       landmark: jsonData.cmp_post_landmark,
//       appId: appId,
//       userId: userId
//     };
//     if (found5) {
//       await PIA_Details.update(toSave, { where: { appId }, transaction: t }); // 👈 here
//       console.log("✅ Updated existing record");
//     } else {
//       await PIA_Details.create(toSave);
//       console.log("✅ Inserted new record");
//     }


//     const found6 = await PIDetails.findOne({ where: { appId: appId }, transaction: t });
//     const toSave2 = {
//       name_of_applicant_institute: jsonData.name_of_applicant_institute,
//       type_of_institute: jsonData.type_of_institute,
//       institute_location: jsonData.institute_location,
//       is_falls_under_hill_area_hill: jsonData.is_falls_under_hill_area_hill,
//       Falls_Under_Hill_Area_Hill__Supporting_Doc: req.files.Falls_Under_Hill_Area_Hill__Supporting_Doc[0].filename,
//       is_falls_under_border_district: jsonData.is_falls_under_border_district,
//       Falls_Under_Border_District__Supporting_Doc: req.files.Falls_Under_Border_District__Supporting_Doc[0].filename,
//       under_msti_category: jsonData.under_msti_category,
//       Whether_the_institute_is_exclusive_for_women_trainees: jsonData.Whether_the_institute_is_exclusive_for_women_trainees,
//       latitude: jsonData.latitude,
//       Longitude: jsonData.Longitude,
//       appId: appId,
//       userId: userId
//     };

//     if (found6) {
//       await PIDetails.update(toSave2, { where: { appId }, transaction: t }); // 👈 here
//       console.log("✅ Updated existing record");
//     } else {
//       await PIDetails.create(toSave2);
//       console.log("✅ Inserted new record");
//     }


//     // Settign Up Stage I Form Flow
//     let toSave3 = { status: cons.SL.FILLED };
//     const [updatedRows] = await FormFlowStageI.update(toSave3,
//       {
//         where: { appId, step: cons.ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step }, transaction: t
//       }
//     );

//     // if (updatedRows === 0) {
//     //   throw new Error("Step Not Found, for Updating " + cons.ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step);
//     // }

//     let toSave4 = { stepStatus: cons.SL.ACTIVE };
//     const [updatedRows2] = await FormFlowStageI.update(toSave4,
//       {
//         where: {
//           appId: appId,
//           step: cons.ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step
//         }, transaction: t
//       }
//     );
//     // if (updatedRows2 === 0) {
//     //   throw new Error("Step Not Found, for Updating " + cons.ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step);
//     // }

//     await t.commit();
//     console.log("Multiple records inserted within transaction ✅");
//   } catch (err) {
//     await t.rollback();
//     throw err;
//   } finally {
//     // if (connection) await connection.end();
//   }
//   return { msg: "Information Successfully" };
// };
export const setProposedInstDetails = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { step, data, appId } = req.body;
    const userId = req.userInfo.user_id;

    const jsonData = JSON.parse(data);
    const stepInfo = JSON.parse(step);

    // throw jsonData;

    // ----------- PIA_Details -----------
    const found5 = await PIA_Details.findOne({ where: { appId }, transaction: t });
    const toSave = {
      state_code: jsonData.cmp_post_state,
      district_code: jsonData.cmp_post_district,
      sub_district_code: jsonData.cmp_post_sub_district,
      village_code: jsonData.cmp_post_village,
      pincode: jsonData.cmp_post_pincode,
      plotNumber_khasaraNumber: jsonData.cmp_post_plot_number_khasara_number,
      landmark: jsonData.cmp_post_landmark,
      town_city: jsonData.comp_town_city,
      block: '--',
      appId,
      userId,
    };

    if (found5) {
      await PIA_Details.update(toSave, { where: { appId }, transaction: t });
      console.log("✅ Updated existing PIA_Details record");
    } else {
      await PIA_Details.create(toSave, { transaction: t });
      console.log("✅ Inserted new PIA_Details record");
    }

    // ----------- PIDetails -----------
    const found6 = await PIDetails.findOne({ where: { appId }, transaction: t });

    const toSave2 = {
      name_of_applicant_institute: jsonData.name_of_applicant_institute,
      type_of_institute: jsonData.type_of_institute,
      institute_location: jsonData.institute_location,

      // Condition
      is_falls_under_hill_area_hill: jsonData.is_falls_under_hill_area_hill,
      ...(jsonData.is_falls_under_hill_area_hill === "yes" && {
        Falls_Under_Hill_Area_Hill__Supporting_Doc:
          req?.files?.Falls_Under_Hill_Area_Hill__Supporting_Doc?.[0]?.filename || null
      }),


      // Condition
      is_falls_under_border_district: jsonData.is_falls_under_border_district,
      ...(jsonData.is_falls_under_border_district === "yes" && {
        Falls_Under_Border_District__Supporting_Doc:
          req?.files?.Falls_Under_Border_District__Supporting_Doc?.[0]?.filename || null,
      }),


      under_msti_category: jsonData.under_msti_category,
      Whether_the_institute_is_exclusive_for_women_trainees:
        jsonData.Whether_the_institute_is_exclusive_for_women_trainees,
      latitude: jsonData.latitude,
      Longitude: jsonData.Longitude,
      appId,
      userId,
    };

    if (found6) {
      await PIDetails.update(toSave2, { where: { appId }, transaction: t });
      console.log("✅ Updated existing PIDetails record");
    } else {
      await PIDetails.create(toSave2, { transaction: t });
      console.log("✅ Inserted new PIDetails record");
    }

    // ----------- FormFlowStageI -----------
    let result = await FormFlowStageI.update({ status: cons.SL.FILLED, updateDate: cons.currentDate }, {
      where: { appId: appId, step: cons.ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step },
      transaction: t,
    });
    // console.log("Stage I update affected rows:", updatedRows);

    await FormFlowStageI.update({ stepStatus: cons.SL.ACTIVE, activeDate: cons.currentDate, updateDate: cons.currentDate }, {
      where: { appId: appId, step: cons.ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step },
      transaction: t,
    });

    // ----------- Commit -----------
    await t.commit();
    // throw { status: cons.SL.FILLED, updateDate: cons.currentDate };

  } catch (err) {
    await t.rollback();
    console.error("❌ Transaction rolled back due to error:", err);
    throw err;
  }
  return { msg: "Information saved successfully" };
};

export const setInstTradeDetails = async (req, res) => {
  let jsonData, userId, stepInfo;
  const t = await sequelize.transaction();

  try {
    const { step, data, appId } = req.body;
    userId = req.userInfo.user_id;
    jsonData = JSON.parse(data);
    stepInfo = JSON.parse(step);

    let preparedArray = jsonData.trades.map((item) => {
      const { trade, units_in_shift_1, units_in_shift_2, units_in_shift_3 } = item
      return { tradeId: trade, unit_in_shift1: units_in_shift_1, unit_in_shift2: units_in_shift_2, unit_in_shift3: units_in_shift_3, appId: appId };
    });

    // Remove if Exist
    await TradesNewInstTrades.destroy({ where: { appId }, transaction: t, });

    // Insert New 
    await TradesNewInstTrades.bulkCreate(preparedArray, { transaction: t });


    // Update Flow Status
    await FormFlowStageI.update({ status: cons.SL.FILLED, updateDate: cons.currentDate }, {
      where: { appId, step: cons.ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step },
      transaction: t,
    });

    await FormFlowStageI.update({ stepStatus: cons.SL.ACTIVE, updateDate: cons.currentDate, activeDate: cons.currentDate }, {
      where: { appId, step: cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step },
      transaction: t,
    });

    await t.commit();

  } catch (err) {
    await t.rollback();
    throw err;
  }
  return { msg: "Information Successfully" };
};

export const setInstLandDetails = async (req, res) => {
  let connection, stmt, results, update, formattedDate, jsonData, userId, stepInfo;
  const t = await sequelize.transaction();
  try {
    const { step, data, appId } = req.body;
    userId = req.userInfo.user_id;

    jsonData = JSON.parse(data);
    stepInfo = JSON.parse(step);


    // throw jsonData.possession_of_land;

    switch (jsonData.possession_of_land) {
      case 'owned':
        const toSave2 = {
          land_owner_name: jsonData.land_owner_name,
          land_registration_number: jsonData.land_registration_number,
          appId: appId,
          userId: userId
        }
        const found6 = await LandOwnedLand.findOne({
          where: { appId: appId },
          transaction: t,
        });
        if (found6) {
          await LandOwnedLand.update(toSave2, {
            where: { appId },
            transaction: t,
          });
        } else {
          await LandOwnedLand.create(toSave2);
        }
        // Save
        const toSave3 = {
          possession_of_land: jsonData.possession_of_land,
          land_area_in_square_metres: jsonData.land_area_in_square_metres,
          appId: appId,
          userId: userId
        }
        const found7 = await LandInstDetail.findOne({
          where: { appId: appId },
          transaction: t,
        });
        if (found7) {
          await LandInstDetail.update(toSave3, {
            where: { appId },
            transaction: t,
          });
        } else {
          await LandInstDetail.create(toSave3);
        }
        break;
      case 'leased':


        const found1 = await LandInstDetail.findOne({
          where: { appId: appId },
          transaction: t,
        });
        // throw found1;
        const toSave4 = {
          possession_of_land: jsonData.possession_of_land,
          land_area_in_square_metres: jsonData.land_area_in_square_metres,
          appId: appId,
          userId: userId
        }
        if (found1) {

          await LandInstDetail.update(toSave4, {
            where: { appId },
            transaction: t,
          });
        } else {
          await LandInstDetail.create(toSave4);
        }

        const toSave6 = {
          name_of_lessor: jsonData.name_of_lessor,
          name_of_lessee: jsonData.name_of_lessee,
          lease_deed_number: jsonData.lease_deed_number,
          date_of_commencement: jsonData.date_of_commencement,
          date_of_expiry: jsonData.date_of_expiry,
          appId: appId,
          userId: userId
        }
        const found8 = await LandLeasedLand.findOne({
          where: { appId: appId },
          transaction: t,
        });
        if (found8) {
          await LandLeasedLand.update(toSave6, {
            where: { appId },
            transaction: t,
          }); // 👈 here
        } else {
          await LandLeasedLand.create(toSave6);
        }
        break;
      default:
        throw new Error("Error In Possession of Land Type");
        break;
    }

    // ----------- FormFlowStageI -----------
    const toSave3 = { status: cons.SL.FILLED };
    const [updatedRows] = await FormFlowStageI.update(toSave3, {
      where: { appId, step: cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step },
      transaction: t,
    });
    console.log("Stage I update affected rows:", updatedRows);

    const toSave4 = { stepStatus: cons.SL.ACTIVE };
    const [updatedRows2] = await FormFlowStageI.update(toSave4, {
      where: { appId, step: cons.ST1FC.FEE_PAYMENT.step },
      transaction: t,
    });
    console.log("Trade Unit step update affected rows:", updatedRows2);

    // ----------- Commit -----------
    await t.commit();
    console.log("Multiple records inserted/updated within transaction ✅");

  } catch (err) {
    await t.rollback();
    throw err;
  }
  return { msg: "Information Successfully" };
};


export const landInfo = async (req, res) => {
  let finalResult;
  try {
    const { appId } = req.body;
    const userId = req.userInfo.user_id;

    // Land Information 
    const landDetail = await LandInstDetail.findOne({
      where: { appId: appId }, include: [
        {
          model: LandOwnedLand,
          as: "land_owner_info",
          include: [
            {
              model: Stage1Documents,
              as: "init_land_documents",
              required: false, // LEFT JOIN
              // where: { appId: appId }
            },
            {
              attributes: ['appId', 'assessment_id', 'recordType', 'language', 'document', 'notarised_document', 'timestamp', 'reference_number'],
              model: LandDocuments,
              as: "old_land_documents",
              required: false, // LEFT JOIN
              where: { appId: appId, recordType: cons.SL.HISTORY }
            },
            {
              attributes: ['appId', 'assessment_id', 'recordType', 'language', 'document', 'notarised_document', 'timestamp', 'reference_number'],
              model: LandDocuments,
              as: "latest_land_documents",
              required: false, // LEFT JOIN
              where: { appId: appId, recordType: cons.SL.PRESENT }
            },
          ]
        },
        {
          model: LandLeasedLand,
          as: "leased_land_info",
          required: false,
        },
        {
          attributes: ["appId", "land_area", "created_date"],
          model: InitialLandArea,
          as: "initial_land_area",
          required: false, // LEFT JOIN
        },
        {
          attributes: ["appId", "assessment_id", "reference_number", "recordType", "land_area", "created_date", "update_date"],
          model: LandArea,
          as: "latest_land_area",
          required: false, // LEFT JOIN
          where: { appId: appId, recordType: cons.SL.PRESENT }
        },
        {
          attributes: ["appId", "assessment_id", "reference_number", "recordType", "land_area", "created_date", "update_date"],
          model: LandArea,
          as: "old_land_area",
          required: false, // LEFT JOIN
          where: { appId: appId, recordType: cons.SL.HISTORY }
        },
      ]
    });
    finalResult = { ...finalResult, landDetail: landDetail }
    // const owned_land_info = await LandOwnedLand.findOne({ where: { appId: appId }, });


  } catch (err) {
    throw err;
  }

  return finalResult;
}

export const getInstLandDetails = async (req, res) => {
  let finalResult, userId;
  try {

    const { appId } = req.body;
    userId = req.userInfo.user_id;

    const found1 = await LandOwnedLand.findOne({
      where: { appId: appId }
    });
    const found2 = await LandInstDetail.findOne({
      where: { appId: appId },
    });
    const found3 = await LandLeasedLand.findOne({
      where: { appId: appId },
    });







    finalResult = {
      ...landDetail.initialValues,
      "possession_of_land": found2?.possession_of_land || '',
      "land_area_in_square_metres": found2?.land_area_in_square_metres || '',
      "land_owner_name": found1?.land_owner_name || '',
      "land_registration_number": found1?.land_registration_number || '',
      "name_of_lessor": found3?.name_of_lessor || '',
      "name_of_lessee": found3?.name_of_lessee || '',
      "lease_deed_number": found3?.lease_deed_number || '',
      "date_of_commencement": found3?.date_of_commencement || '',
      "date_of_expiry": found3?.date_of_expiry || ''
    };
    // throw finalResult;
    // throw found1;
    // throw found2;
    // throw found3;
  } catch (err) {
    throw err;
  }

  return finalResult;

};




export const getProposedInstDetailsForAutoFill = async (req, res) => {
  let finalResult, userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;

    const found5 = await PIA_Details.findOne({
      where: { appId }, include: [
        {
          model: District,
          as: "district_list",
          where: Sequelize.and(
            Sequelize.where(
              Sequelize.col('ProposedInstituteAddressesDetails.state_code'),
              Sequelize.col('district_list.stateCode')
            ),
            Sequelize.where(
              Sequelize.col('ProposedInstituteAddressesDetails.district_code'),
              Sequelize.col('district_list.districtCode')
            )
          ),
          required: false,
          separate: false,   // fetch in separate query
          limit: 1          // only 1 row per EntOtherITI
        },
        {
          attributes: [
            'districtCode',
            'districtNameEnglish',
            'stateCode',
            'subdistrictCode',
            'subdistrictNameEnglish'
          ],
          model: VilDistrictSubDistrict,
          as: "sub_district_list",
          where: Sequelize.and(
            Sequelize.where(
              Sequelize.col('ProposedInstituteAddressesDetails.state_code'),
              Sequelize.col('sub_district_list.stateCode')
            ),
            Sequelize.where(
              Sequelize.col('ProposedInstituteAddressesDetails.district_code'),
              Sequelize.col('sub_district_list.districtCode')
            ),
            Sequelize.where(
              Sequelize.col('ProposedInstituteAddressesDetails.sub_district_code'),
              Sequelize.col('sub_district_list.subdistrictCode')
            )
          ),
          required: false,
          separate: false,   // fetch in separate query
          limit: 1
        },
        {
          model: VilDistrictSubDistrict,
          as: "village_list",
        }
      ]
    });
    const found6 = await PIDetails.findOne({ where: { appId } });
    const {
      name_of_applicant_institute,
      type_of_institute,
      institute_location,
      is_falls_under_hill_area_hill,
      Falls_Under_Hill_Area_Hill__Supporting_Doc,
      is_falls_under_border_district,
      Falls_Under_Border_District__Supporting_Doc,
      under_msti_category,
      Whether_the_institute_is_exclusive_for_women_trainees,
      latitude,
      Longitude, } = found6 || {};


    const { state_code,
      district_code,
      town_city,
      sub_district_code,
      village_code,
      pincode,
      plotNumber_khasaraNumber,
      landmark, district_list,
      sub_district_list,
      village_list } = found5 || {};


    finalResult = {
      name_of_applicant_institute: name_of_applicant_institute,
      type_of_institute: type_of_institute,
      cmp_post_state: state_code,
      cmp_post_district: district_code,
      cmp_post_sub_district: sub_district_code,
      comp_town_city: town_city,
      cmp_post_village: village_code,
      cmp_post_pincode: pincode,
      cmp_post_plot_number_khasara_number: plotNumber_khasaraNumber,
      cmp_post_landmark: landmark,
      institute_location: institute_location,
      is_falls_under_hill_area_hill: is_falls_under_hill_area_hill,
      Falls_Under_Hill_Area_Hill__Supporting_Doc: Falls_Under_Hill_Area_Hill__Supporting_Doc,
      is_falls_under_border_district: is_falls_under_border_district,
      Falls_Under_Border_District__Supporting_Doc: Falls_Under_Border_District__Supporting_Doc,
      under_msti_category: under_msti_category,
      Whether_the_institute_is_exclusive_for_women_trainees: Whether_the_institute_is_exclusive_for_women_trainees,
      latitude: latitude,
      Longitude: Longitude,
      district_list: district_list,
      sub_district_list: sub_district_list,
      village_list: village_list,
    }
    // throw pid.intiValues;
    // throw found6;
    // throw found5;
    // throw appId;
  } catch (err) {
    throw err;
  }
  return finalResult;
};

// export const getProposedInstDetailsForAutoFill = async (req, res) => {

//   let connection, stmt, results, update, jsonData, userId, submitDate, updateDate;
//   // const pool = mysql.createPool(masterConfig);
//   // connection = await pool.getConnection();
//   let l1, l2;
//   try {

//     connection = await mysql.createConnection(affDbConfig);

//     const { appId } = req.body;
//     userId = req.userInfo.user_id;



//     await connection.beginTransaction();

//     let sel_proposed_insti_details = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_DETAILS + '` WHERE appId = ?');
//     let sel_proposed_insti_addresses = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_ADDRESSES + '` WHERE appId = ?');

//     let rows;
//     rows = await sel_proposed_insti_details.execute([appId]);
//     l1 = rows[0];
//     rows = await sel_proposed_insti_addresses.execute([appId]);
//     l2 = rows[0];

//     // Commit the transaction
//     await connection.commit();
//     // connection.release();

//   } catch (err) {
//     console.error("Error in checkUser:", err);
//     if (connection) {
//       await connection.rollback();
//     }
//     throw err;
//   } finally {
//     if (connection) await connection.end();
//   }
//   return { pro_insti_details: l1[0] || {}, pro_insti_address: l2, };

// };
export const getProposedInstDetailByAppId = async (appId, connection) => {
  let l1, l2;
  try {
    // Session User
    // userId = req.userInfo.user_id;

    // Create Connection
    // const pool = mysql.createPool(masterConfig);
    // connection = await pool.getConnection();

    connection = await mysql.createConnection(affDbConfig);


    await connection.beginTransaction();

    let sel_proposed_insti_details = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_DETAILS + '` WHERE appId = ?');
    let sel_proposed_insti_addresses = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_ADDRESSES + '` WHERE appId = ?');

    let rows;
    rows = await sel_proposed_insti_details.execute([appId]);
    l1 = rows[0];

    rows = await sel_proposed_insti_addresses.execute([appId]);
    l2 = rows[0];


    // Commit the transaction
    await connection.commit();
    // connection.release();

  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return { pro_insti_details: l1[0] || {}, pro_insti_address: l2, };

};

export const getStage1FormFlow = async (req, res) => {
  let connection, userId, finalList;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {

    connection = await mysql.createConnection(affDbConfig);


    const { appId } = req.body;
    userId = req.userInfo.user_id;



    await connection.beginTransaction();

    let sel_app_form_flow_stage_i = await connection.prepare('SELECT * FROM `' + cons.APP_FORM_FLOW_STAGE_I + '` WHERE appId = ?');
    let [flow] = await sel_app_form_flow_stage_i.execute([appId]);

    finalList = await Promise.all(flow.map(async (item) => {
      switch (item.step) {
        case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
          // check possession_of_land
          console.log(item.step);
          return item;
        default:
          return item;
      }
    }));


    // Commit the transaction
    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return finalList;



  // const db = await initDB();
  // try {
  //   const tx = db.transaction([cons.APP_FORM_FLOW_STAGE_I], 'readwrite');
  //   const list = tx.objectStore(cons.APP_FORM_FLOW_STAGE_I);
  //   const flow = await list.index('appId').getAll(appId);
  //   console.log(flow);
  //   flow.sort((a, b) => a.stepNo - b.stepNo);
  //   const finalList = await Promise.all(flow.map(async (item) => {
  //     switch (item.step) {
  //       case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
  //         // check possession_of_land
  //         console.log(item.step);
  //         return item;
  //       default:
  //         return item;
  //     }
  //   }));
  //   console.log(finalList);
  //   await tx.done;
  //   return finalList;
  // } catch (error) {
  //   return []
  // }
};



export const getStage2FormFlow = async (req, res) => {
  let finalList = [];
  try {

    const { appId } = req.body;
    const userId = req.userInfo.user_id;

    const List = await FormFlowStageII.findAll({
      where: { appId: appId },
    });


    for (const [index, flow] of List.entries()) {
      switch (flow.step) {
        case cons.CIVIL_INFRASTRUCTURE_DETAIL:
          {
            const List = await AppFormSubCivilInfra.findAll({ where: { appId: appId } });
            flow.subSteps = List;
            finalList.push(flow);
          }
          break;
        case cons.TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS:
          {
            const List = await SubFlowMachineryToolEquipment.findAll({ where: { appId: appId } });
            flow.subSteps = List;
            finalList.push(flow);
          }
          break;
        default:
          finalList.push(flow);
        // throw `Something Went Wrong with Step Info: ${flow.step}`
      }
    }



    // let sel_app_form_flow_stage_i = await connection.prepare('SELECT * FROM `' + cons.APP_FORM_FLOW_STAGE_II + '` WHERE appId = ?');
    // let [flow] = await sel_app_form_flow_stage_i.execute([appId]);

    // finalList = await Promise.all(flow.map(async (item) => {
    //   switch (item.step) {
    //     case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
    //       return item;
    //     case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
    //       return item;
    //     default:
    //       return item;
    //   }
    // }));

    // // Commit the transaction
    // await connection.commit();
    // // connection.release();
  } catch (err) {
    throw err;
  }
  return finalList;
};
export const markascomleted_app_form_flow_stage_i = async (connection, appId, stepInfo) => {
  let stmt1 = await connection.prepare('SELECT * FROM `' + cons.APP_FORM_FLOW_STAGE_I + '` WHERE appId = ? and step=?');
  let [result2] = await stmt1.execute([appId, stepInfo.step]);
  if (result2.length > 0) {
    let stmt1 = await connection.prepare('UPDATE `' + cons.APP_FORM_FLOW_STAGE_I + '` SET stepStatus=?, status=?, updateDate=? WHERE appId=? and step=?;');
    await stmt1.execute([cons.ACTIVE, cons.FILLED, updateDate, appId, stepInfo.step]);
  }
  else {
    throw new Error("Form FLow Step Information Not Found");
  }
}

export const markasactive_app_form_flow_stage_i = async (connection, appId, step) => {
  let sel_proposed_insti_details = await connection.prepare('SELECT * FROM `' + cons.APP_FORM_FLOW_STAGE_I + '` WHERE appId = ? and step=?');
  let [result2] = await sel_proposed_insti_details.execute([appId, step]);
  if (result2.length > 0) {
    let stmt = await connection.prepare('UPDATE `' + cons.APP_FORM_FLOW_STAGE_I + '` SET stepStatus=? WHERE appId=? and step=?;');
    await stmt.execute([cons.ACTIVE, appId, step]);
  }
  else {
    throw new Error("Form FLow Step Information Not Found");
  }
}


export const markAsAtiveAppFlow = async (connection, appId, step) => {
  let sel_proposed_insti_details = await connection.prepare('SELECT * FROM `' + cons.APP_FLOW + '` WHERE appId = ? and step=?');
  let [result2] = await sel_proposed_insti_details.execute([appId, step]);
  if (result2.length > 0) {
    let stmt = await connection.prepare('UPDATE `' + cons.APP_FLOW + '` SET stepStatus=? WHERE appId=? and step=?;');
    await stmt.execute([cons.SL.PENDING, appId, step]);
  }
  else {
    throw new Error("Form FLow Step Information Not Found");
  }
}




export const getStage1ApplicationInfo = async (req, res) => {
  let finalResult = {};
  // const t = await sequelize.transaction();
  try {
    const { appId } = req.body;
    const userId = req.userInfo.user_id;

    const entity = await EntEntityDetails.findOne({
      where: { appId: appId },
      include: [
        {
          model: EntityAddress,
          as: "ent_address",
          include: [
            {
              model: State,
              as: "state_detail", // nested include
              attributes: ['stateCode',
                'stateNameEnglish',
                'stateNameLocal',
                'shortName',
                'stateOrUt']
            },
            {
              model: District,
              as: "district_detail", // nested include
              attributes: ['districtCode',
                'districtNameEnglish',
                'districtNameLocal',
                'districtNameshort',
                'stateCode']
            },
            {
              model: VilDistrictSubDistrict,
              as: "sub_district", // nested include,
              attributes: ['subdistrictCode',
                'subdistrictNameEnglish',
                'districtCode']
            },
            {
              model: VilDistrictSubDistrict,
              as: "village", // nested include
              attributes: ['villageCode',
                'villageNameEnglish',
                'districtCode']
            },
          ],
        },
        {
          model: MasterAffiliationCategory,
          as: "category_info", // nested include
        },
        {
          model: MasterAffiliationSubCategory,
          as: "sub_cat_info", // nested include
        },
      ],
    });
    const otherITIs = await EntOtherITI.findAll({
      include: [
        {
          model: State,
          as: "state_detail",
          attributes: ['stateCode',
            'stateNameEnglish',
            'stateNameLocal',
            'shortName',
            'stateOrUt']

        },
        {
          model: District,
          as: "district_detail",
          attributes: ['districtCode',
            'districtNameEnglish',
            'districtNameLocal',
            'districtNameshort',
            'stateCode']
        },
      ], where: { appId: appId }
    });
    finalResult = { ...finalResult, entity: entity, otherITIs: otherITIs };

    // Getting Proposed Institute Details
    const pInstDetail = await ProposedProposedInstituteDetails.findOne({ where: { appId: appId } });
    const comp_postal_addres_of_inst = await ProposedInstituteAddressesDetails.findOne({
      where: { appId: appId },
      include: [
        {
          model: State,
          as: "state_detail", // nested include
          attributes: ['stateCode',
            'stateNameEnglish',
            'stateNameLocal',
            'shortName',
            'stateOrUt']
        },
        {
          model: District,
          as: "district_detail", // nested include
          attributes: ['districtCode',
            'districtNameEnglish',
            'districtNameLocal',
            'districtNameshort',
            'stateCode']
        },
        {
          model: VilDistrictSubDistrict,
          as: "sub_district", // nested include,
          attributes: ['subdistrictCode',
            'subdistrictNameEnglish',
            'districtCode']
        },
        {
          model: VilDistrictSubDistrict,
          as: "village", // nested include
          attributes: ['villageCode',
            'villageNameEnglish',
            'districtCode']
        },
      ],
    });
    finalResult = { ...finalResult, pInstDetail: pInstDetail, comp_postal_addres_of_inst: comp_postal_addres_of_inst }


    // Getting Trade Info 
    const tradeList = await TradesNewInstTrades.findAll({
      where: { appId: appId }, include: [
        {
          model: MasterTradeInfo,
          as: "tradeInfo"
        }
      ]
    });

    finalResult = { ...finalResult, tradeList: tradeList }


    // Land Information 
    const landDetail = await LandInstDetail.findOne({
      where: { appId: appId }, include: [
        {
          model: LandOwnedLand,
          as: "land_owner_info",
          include: [
            {
              model: Stage1Documents,
              as: "init_land_documents",
              required: false, // LEFT JOIN
              // where: { appId: appId }
            },
            {
              attributes: ['appId', 'assessment_id', 'recordType', 'language', 'document', 'notarised_document', 'timestamp', 'reference_number'],
              model: LandDocuments,
              as: "old_land_documents",
              required: false, // LEFT JOIN
              where: { appId: appId, recordType: cons.SL.HISTORY }
            },
            {
              attributes: ['appId', 'assessment_id', 'recordType', 'language', 'document', 'notarised_document', 'timestamp', 'reference_number'],
              model: LandDocuments,
              as: "latest_land_documents",
              required: false, // LEFT JOIN
              where: { appId: appId, recordType: cons.SL.PRESENT }
            },
          ]
        },
        {
          model: LandLeasedLand,
          as: "leased_land_info",
          required: false,
        },
        {
          attributes: ["appId", "land_area", "created_date"],
          model: InitialLandArea,
          as: "initial_land_area",
          required: false, // LEFT JOIN
        },
        {
          attributes: ["appId", "assessment_id", "reference_number", "recordType", "land_area", "created_date", "update_date"],
          model: LandArea,
          as: "latest_land_area",
          required: false, // LEFT JOIN
          where: { appId: appId, recordType: cons.SL.PRESENT }
        },
        {
          attributes: ["appId", "assessment_id", "reference_number", "recordType", "land_area", "created_date", "update_date"],
          model: LandArea,
          as: "old_land_area",
          required: false, // LEFT JOIN
          where: { appId: appId, recordType: cons.SL.HISTORY }
        },
      ]
    });
    finalResult = { ...finalResult, landDetail: landDetail }
    // const owned_land_info = await LandOwnedLand.findOne({ where: { appId: appId }, });


    // Setting up certificates
    const certificatesList = await InitialCertificats.findAll({
      where: { appId: appId }, include: [
        {
          model: Certificat,
          as: 'old_certificates'
        },
        {
          model: Certificat,
          as: 'latest_certificates'
        }
      ]
    });
    finalResult = { ...finalResult, certificatesList: certificatesList }



  } catch (err) {
    // await t.rollback();
    throw err;
  }
  return finalResult;
};


export const getFeeInfo = async (req, res) => {
  let connection, userId, finalResult;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();

  try {

    connection = await mysql.createConnection(affDbConfig);


    const { appId } = req.body;
    userId = req.userInfo.user_id;


    await connection.beginTransaction();

    let stmt1 = await connection.prepare('SELECT * FROM `' + cons.APP_FLOW + '` WHERE step=? and appId = ?');
    let [result] = await stmt1.execute([cons.STAGE_I_FEE, appId]);
    if (result.length > 0) {
      finalResult = result[0]
    }
    else {
      throw new Error("Form FLow Step Not Found");
    }

    // Commit the transaction
    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return { stageI: finalResult };



  // const db = await initDB();
  // try {
  //   const tx = db.transaction([cons.APP_FORM_FLOW_STAGE_I], 'readwrite');
  //   const list = tx.objectStore(cons.APP_FORM_FLOW_STAGE_I);
  //   const flow = await list.index('appId').getAll(appId);
  //   console.log(flow);
  //   flow.sort((a, b) => a.stepNo - b.stepNo);
  //   const finalList = await Promise.all(flow.map(async (item) => {
  //     switch (item.step) {
  //       case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
  //         // check possession_of_land
  //         console.log(item.step);
  //         return item;
  //       default:
  //         return item;
  //     }
  //   }));
  //   console.log(finalList);
  //   await tx.done;
  //   return finalList;
  // } catch (error) {
  //   return []
  // }
};
export const setAsExemptedStageII = async (req, res) => {
  const t = await sequelize.transaction();
  try {

    const { appId } = req.body;
    const userId = req.userInfo.user_id;

    let exit_inst_info = await ProposedProposedInstituteDetails.findOne({ where: { appId: appId } });
    let exist = await LandInstDetail.findOne({ where: { appId: appId } });

    if (!(exit_inst_info.type_of_institute === cons.TypeOfInst.GOVERNMENT)) {
      throw new Error("Invalid Request");
    }



    // Setting Up Stage 1 Form Filling Step
    const exist0 = await AppFlow.findOne({ where: { appId: appId, step: cons.STAGE_II_FORM_FILLING }, transaction: t, });
    await exist0.update({ stepStatus: cons.SL.COMPLETED, status: cons.STAGE_II__FILLED, completedDate: cons.currentDate })


    // CHeck First 
    const appFlow = await AppFlow.findOne({ where: { appId, step: cons.STAGE_II_FEE }, transaction: t, });
    await appFlow.update({ stepStatus: cons.SL.COMPLETED, status: cons.STAGE_II__FEE_EXEMPTED, completedDate: cons.currentDate });


    // CHeck First 
    const found1 = await AppFlow.findOne({ where: { appId, step: cons.STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS }, transaction: t, });
    await found1.update({ stepStatus: cons.SL.PENDING, status: cons.STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_ON_PROGRESS, startedDate: cons.currentDate });


    // Setting UP Fee Payment
    const exist2 = await FormFlowStageII.findOne({ where: { appId, step: cons.FEE_PAYMENT_FOR_STAGEII }, transaction: t, });
    await exist2.update({ status: cons.SL.FILLED, updateDate: cons.currentDate })

    // Setting UP Document Step
    const exist3 = await FormFlowStageII.findOne({ where: { appId, step: cons.TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS }, transaction: t, });
    await exist3.update({ stepStatus: cons.SL.ACTIVE, activeDate: cons.currentDate })

    // await t.commit();
    await t.rollback();
  } catch (err) {
    await t.rollback();
    throw err;
  }
  return { msg: "Information saved successfully" };
};

export const setAsExemptedStageI = async (req, res) => {
  let formData, connection, stmt, results, update, formattedDate, jsonData, userId, stepInfo;
  const t = await sequelize.transaction();

  try {


    const { data, step, appId } = req.body;
    userId = req.userInfo.user_id;

    stepInfo = JSON.parse(step);
    formData = JSON.parse(data);

    let exit_inst_info = await ProposedProposedInstituteDetails.findOne({ where: { appId: appId } });
    let exist = await LandInstDetail.findOne({ where: { appId: appId } });

    if (!(exit_inst_info.type_of_institute === cons.TypeOfInst.GOVERNMENT)) {
      throw new Error("Invalid Request");
    }



    // Setting Up Stage 1 Form Filling Step
    const exist0 = await AppFlow.findOne({ where: { appId: appId, step: cons.STAGE_I_FORM_FILLING }, transaction: t, });
    await exist0.update({ stepStatus: cons.SL.COMPLETED, status: cons.STAGE_I__FILLED, completedDate: cons.currentDate })


    // CHeck First 
    const appFlow = await AppFlow.findOne({ where: { appId, step: cons.STAGE_I_FEE }, transaction: t, });
    await appFlow.update({ stepStatus: cons.SL.COMPLETED, status: cons.STAGE_I__FEE_EXEMPTED, completedDate: cons.currentDate })


    // Setting UP Fee Payment
    const exist2 = await FormFlowStageI.findOne({ where: { appId, step: cons.ST1FC.FEE_PAYMENT.step }, transaction: t, });
    await exist2.update({ status: cons.SL.FILLED, updateDate: cons.currentDate })

    // Setting UP Document Step
    const exist3 = await FormFlowStageI.findOne({ where: { appId, step: cons.ST1FC.DOCUMENTS_UPLOAD.step }, transaction: t, });
    await exist3.update({ stepStatus: cons.SL.ACTIVE, activeDate: cons.currentDate })

    await t.commit();
    // await t.rollback();
  } catch (err) {
    await t.rollback();
    throw err;
  }
  return { msg: "Information saved successfully" };
};

export const setUploadDocumentStageI = async (req, res) => {
  let formData, connection, stmt, results, update, formattedDate, jsonData, userId, stepInfo;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  // Safe access
  const file = req.files.find(f => f.fieldname === "land_conversion_certificate[2].document");
  const t = await sequelize.transaction();

  try {


    // connection = await mysql.createConnection(affDbConfig);


    const { data, step, appId } = req.body;
    userId = req.userInfo.user_id;

    // await connection.beginTransaction();

    stepInfo = JSON.parse(step);
    formData = JSON.parse(data);

    let found = await LandInstDetail.findOne({ where: { appId: appId } });
    switch (found.possession_of_land) {
      case "leased":
        for (const [index, item] of formData.lease_deed_documents.entries()) {

          const lease_deed_document = req.files.find(f => f.fieldname === `lease_deed_documents[${index}].document`);
          if (!lease_deed_document) {
            throw new Error(`File missing for ${item.language} at index ${index}`);
          }
          console.log(1326, item.language, index, lease_deed_document);

          switch (item.language) {
            case "English":
            case "Hindi":
              await Stage1Documents.create({
                uniqueId: cons.randomId(),
                appId: appId,
                language: item.language,
                document: lease_deed_document.filename,
                uploaded_datetime: cons.currentDate,
                file_meta_info: { lease_deed_document }
              }, { transaction: t });
              break;
            default:
              const lease_deed_notarised_document = req.files.find(f => f.fieldname === `lease_deed_documents[${index}].notarised_document`);
              if (!lease_deed_notarised_document) {
                throw new Error(`File missing`);
              }
              await Stage1Documents.create({
                uniqueId: cons.randomId(),
                appId: appId,
                language: item.language,
                document: lease_deed_document.filename,
                notarised_document: lease_deed_notarised_document.filename,
                uploaded_datetime: cons.currentDate,
                file_meta_info: { lease_deed_document, lease_deed_notarised_document }
              }, { transaction: t });
              break;
          }
        }
        break;
      case "owned":
        for (const [index, item] of formData.onwed_land_documents.entries()) {
          const land_document = req.files.find(f => f.fieldname === `onwed_land_documents[${index}].document`);
          if (!land_document) {
            throw new Error(`File missing for ${item.land_documents_language} at index ${index}`);
          }
          switch (item.land_documents_language) {
            case "English":
            case "Hindi":
              await Stage1Documents.create({
                uniqueId: cons.randomId(),
                land_document_type: cons.LAND_DOCUMENT_TYPES.OWNED,
                appId: appId,
                language: item.land_documents_language,
                document: land_document.filename,
                uploaded_datetime: cons.currentDate,
              }, { transaction: t });
              break;
            default:
              const land_document_notarised_document = req.files.find(f => f.fieldname === `land_notarised_documents[${index}].notarised_document`);
              if (!land_document_notarised_document) {
                throw new Error(`File missing`);
              }

              await Stage1Documents.create({
                uniqueId: cons.randomId(),
                land_document_type: cons.LAND_DOCUMENT_TYPES.OWNED,
                appId: appId,
                language: item.land_documents_language,
                document: land_document.filename,
                notarised_document: land_document_notarised_document.filename,
                uploaded_datetime: cons.currentDate,
              }, { transaction: t });
              break;
          }
        }
        break;
      default:
        throw new Error("Error In Possession of Land Type");
    }

    // Saving Land Conversion Certificate
    for (const [index, item] of formData.land_conversion_certificate.entries()) {
      const lcc_documents = req.files.find(f => f.fieldname === `land_conversion_certificate[${index}].document`);
      if (!lcc_documents) {
        throw new Error(`File missing for ${item.language} at index ${index}`);
      }
      switch (item.language) {
        case "English":
        case "Hindi":
          await Stage1Documents.create({
            uniqueId: cons.randomId(),
            land_document_type: cons.LAND_DOCUMENT_TYPES.LAND_CONVERSION_CERTIFICATE,
            appId: appId,
            language: item.language,
            document: lcc_documents.filename,
            uploaded_datetime: cons.currentDate,
          }, { transaction: t });
          break;
        default:
          const lcc_notarised_documents = req.files.find(f => f.fieldname === `land_conversion_certificate[${index}].notarised_document`);
          if (!lcc_notarised_documents) {
            throw new Error(`File missing for`);
          }
          await Stage1Documents.create({
            uniqueId: cons.randomId(),
            land_document_type: cons.LAND_DOCUMENT_TYPES.LAND_CONVERSION_CERTIFICATE,
            appId: appId,
            language: item.language,
            document: lcc_documents.filename,
            notarised_document: lcc_notarised_documents.filename,
            uploaded_datetime: cons.currentDate,
          }, { transaction: t });
          break;
      }
    }


    // Saving AuthorizedSignatoryDetails
    const { name_of_authorized_signatory,
      email_id_of_authorized_signatory,
      is_verified_email_id_of_authorized_signatory,
      mobile_number_of_authorized_signatory,
      is_verified_mobile_number_of_authorized_signatory,
      id_proof_of_authorized_signatory,
      id_proof_number_of_authorized_signatory,
      id_proof_docs_of_authorized_signatory } = formData;

    if (is_verified_email_id_of_authorized_signatory != true) {
      throw new Error("Please Verify Email ID of Authorized Signatory");
    }

    if (is_verified_mobile_number_of_authorized_signatory != true) {
      throw new Error("Please Verify Mobile Number Authorized Signatory");
    }

    const doc_of_authorized_signatory_document = req.files.find(f => f.fieldname === `doc_of_authorized_signatory`);
    if (!doc_of_authorized_signatory_document) {
      throw new Error(`File missing`);
    }

    await InitialAuthorizedSignatoryDetails.create({
      uniqueId: cons.randomId(),
      appId: appId,
      name: name_of_authorized_signatory,
      email_id: email_id_of_authorized_signatory,
      mobile_number: mobile_number_of_authorized_signatory,
      id_proof_type: id_proof_of_authorized_signatory,
      id_proof_number: id_proof_number_of_authorized_signatory,
      document: doc_of_authorized_signatory_document.fieldname,
      uploaded_datetime: cons.currentDate,
    }, { transaction: t });



    // Select Registration Certificate of Applicant Organization
    const doc_of_registration_cert_of_applicant_org = req.files.find(f => f.fieldname === `doc_of_registration_cert_of_applicant_org`);
    if (!doc_of_registration_cert_of_applicant_org) {
      throw new Error(`File missing for ${item.language} at index ${index}`);
    }

    await InitialCertificats.create({
      uniqueId: cons.randomId(),
      appId: appId,
      stage: "STAGE_I",
      keyName: "registration_certificate",
      document: doc_of_registration_cert_of_applicant_org.fieldname,
      upload_datetime: cons.currentDate,
    }, { transaction: t });


    // doc_iti_resolution
    const doc_iti_resolution = req.files.find(f => f.fieldname == `doc_iti_resolution`);
    if (!doc_iti_resolution) {
      throw new Error(`File missing`);
    }
    await InitialCertificats.create({
      uniqueId: cons.randomId(),
      appId: appId,
      stage: "STAGE_I",
      keyName: cons.Certificat.DOC_ITI_RESOLUTION,
      document: doc_iti_resolution.fieldname,
      upload_datetime: cons.currentDate,
    }, { transaction: t });



    // doc_of_authorized_signatory
    const doc_of_authorized_signatory = req.files.find(f => f.fieldname === `doc_of_authorized_signatory`);
    if (!doc_of_authorized_signatory) {
      throw new Error(`File missing`);
    }
    await InitialCertificats.create({
      uniqueId: cons.randomId(),
      appId: appId,
      stage: "STAGE_I",
      keyName: cons.Certificat.DOC_OF_AUTHORIZED_SIGNATORY,
      document: doc_of_authorized_signatory.fieldname,
      upload_datetime: cons.currentDate,
    }, { transaction: t });


    // doc_of_authorized_signatory
    const doc_of_land_earmarking = req.files.find(f => f.fieldname === `doc_of_land_earmarking`);
    if (!doc_of_land_earmarking) {
      throw new Error(`File missing`);
    }
    await InitialCertificats.create({
      uniqueId: cons.randomId(),
      appId: appId,
      stage: "STAGE_I",
      keyName: cons.Certificat.DOC_OF_LAND_EARMARKING,
      document: doc_of_land_earmarking.fieldname,
      upload_datetime: cons.currentDate,
    }, { transaction: t });



    //Saving SecretaryChairpersonPresidentIdInfo
    for (const [index, item] of formData.id_proof_scp.entries()) {
      const document = req.files.find(f => f.fieldname === `id_proof_scp[${index}].document`);
      if (!document) {
        throw new Error(`File missing`);
      }
      const { designation, id_proof_type, id_proof_number, } = item;



      const newInfo = await InitialSecretaryChairpersonPresidentIdInfo.create({
        uniqueId: cons.randomId(),
        appId: appId,
        designation: designation,
        id_proof_type: id_proof_type, // e.g., 1 = Aadhaar, 2 = Passport
        id_proof_number: id_proof_number,
        document: document.fieldname,
        uploaded_datetime: cons.currentDate // maps to MySQL DATETIME
        // timestamp will auto-set
      });

    }



    // Updating Application Flows
    await AppFlow.update({ stepStatus: cons.SL.COMPLETED, status: cons.STAGE_I__DOCUMENT_UPLOADED }, {
      where: { appId, step: cons.STAGE_I_DOCUMENT_UPLAOD },
      transaction: t,
    });

    await AppFlow.update({ stepStatus: cons.SL.COMPLETED, status: cons.STAGE_I__SUBMITED }, {
      where: { appId, step: cons.STAGE_I_SUBMIT },
      transaction: t,
    });

    await AppFlow.update({ stepStatus: 'pending' }, {
      where: { appId, step: cons.STAGE_I__ASSESSMENT },
      transaction: t,
    });


    await FormFlowStageI.update({ status: cons.SL.FILLED }, {
      where: { appId, step: cons.ST1FC.DOCUMENTS_UPLOAD.step },
      transaction: t,
    });

    // throw found;
    t.commit();

  } catch (err) {
    await t.rollback();
    return res.status(500).json({ error: "Something went wrong", details: err.message });
  }
  return { msg: "Information Successfully" };
};

export const setSendApplicationStage1ToState = async (req, res) => {
  let connection, userId;
  const t = await sequelize.transaction();
  try {
    const { appId, assessment_id } = req.body;
    userId = req.userInfo.user_id;


    const check1 = await AppAssessmentFlowStageI.findOne({
      where: { assessment_id: assessment_id, appId: appId, recordType: cons.SL.PRESENT, actor: cons.SL.APPLICANT }
    });
    if (!check1) {
      throw "FLow Not Found";
    }



    await AssessmentStatus.update(
      { pendingAt: cons.SL.PENDING_AT_ASSESSOR },
      { where: { appId: appId, assessment_id: assessment_id }, transaction: t }
    );




    // 2. Marks as Completed Review Step fo Assessment Flow 
    AppAssessmentFlowStageI.update(
      { step: cons.ST1FC.REVIEW_ASSESSMENT.step, status: cons.SL.COMPLETED },
      {
        where:
        {
          appId: appId,
          assessment_id: assessment_id,
          step: cons.ST1FC.REVIEW_ASSESSMENT.step,
          actor: cons.SL.APPLICANT,
          recordType: cons.SL.PRESENT
        }, transaction: t
      }
    );
    //End



    // 3. Mark as History Current Assessment
    AppAssessmentFlowStageI.update(
      { recordType: cons.SL.HISTORY },
      { where: { appId: appId, assessment_id: assessment_id, recordType: cons.SL.PRESENT }, transaction: t }
    );
    // End



    // 4. Generate New Flow for Applicnat 
    const flowList = await AppAssessmentFlowStageI.findAll({
      where: { assessment_id: assessment_id, appId: appId, recordType: cons.SL.PRESENT, actor: cons.SL.APPLICANT }
    });

    // throw flowList;
    const mainStepsData = flowList.map((step) => {
      const obj = step.get({ plain: true }); // plain object
      delete obj.completionDate;
      delete obj.DA;
      delete obj.slno;

      let rObj = {
        referenceNumber: step.uniqueID,
        appId: appId,
        assessment_id: assessment_id,
        uniqueID: cons.randomId(),
        actor: cons.SL.ASSESSOR,
        recordType: cons.SL.PRESENT,
        status: cons.SL.PENDING,
        forwarded_by: cons.SL.APPLICANT
      }
      return { ...obj, ...rObj };  // <-- use obj not step
    });

    // throw mainStepsData;

    await AppAssessmentFlowStageI.bulkCreate(mainStepsData, { transaction: t });
    await t.commit();
    // await t.rollback();

  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    console.log('reached to final')
  }
  return { msg: "Information Successfully" };
};

export const cleareForResubmitDeficiency = async (req, res) => {
  let connection, userId;
  const t = await sequelize.transaction();
  try {
    const { appId, assessment_id, step, checkName } = req.body;
    userId = req.userInfo.user_id;

    // throw userId;

    const asmt = await AssessmentStatus.findOne({ where: { appId: appId, assessment_id: assessment_id, pendingAt: cons.SL.PENDING_AT_APPLICANT } });
    if (!asmt) throw "Assessment Information Not Found";

    switch (step) {
      case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
        switch (checkName) {
          case cons.DA1_KEYS.LAND_AREA:
            {
              await LandArea.destroy({ where: { appId: appId, assessment_id: assessment_id, recordType: cons.SL.PRESENT }, transaction: t });
              const info = await DAStageIVerificationsChecklist.findOne({ where: { appId: appId, assessment_id: assessment_id, checkName: checkName } })
              if (!info) throw "Check List Info Not Found";
              await info.update({ da_status: cons.SL.REVIEWED }); // as given by Assessor
            }
            break;
          case cons.DA1_KEYS.LAND_DOCUMENT:
            {
              await LandDocuments.destroy({ where: { appId: appId, assessment_id: assessment_id, recordType: cons.SL.PRESENT }, transaction: t });
              const info = await DAStageIVerificationsChecklist.findOne({ where: { appId: appId, assessment_id: assessment_id, checkName: checkName } })
              if (!info) throw "Check List Info Not Found";
              await info.update({ da_status: cons.SL.REVIEWED }); // as given by Assessor
            }
            break;

          default:
            throw "Invalid Check Name";
            break;
        }
        break;
      default:
        throw "Invalid Step";
        break;
    }
    await t.commit();
    // await t.rollback();
  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    console.log('reached to final')
  }
  return { msg: "success" };
};




export const setAppFlow = async ({ appId, step, status, connection }) => {
  // Update the app flow status
  // const db = await initDB();
  let smt1 = await connection.prepare('SELECT * FROM `' + cons.APP_FLOW + '` WHERE step=? and appId = ?');
  let up_stm1 = await connection.prepare('UPDATE `' + cons.APP_FLOW + '` SET `status`=?,	`stepStatus`=? WHERE appId=? and step=?;');
  let [smt1_result] = await smt1.execute([step, appId]);

  if (smt1_result.length == 0 || smt1_result.length < 0) {
    throw "App FLow Not Found";
  }

  switch (step) {
    case cons.STAGE_I_FORM_FILLING:
      await up_stm1.execute([cons.STAGE_I__FILLED, status, appId, step]);
      break;
    case cons.STAGE_I_FEE:
      let result1 = await getProposedInstDetailByAppId(appId, connection);
      switch (result1.pro_insti_details.type_of_institute) {
        case "Government":
          await up_stm1.execute([cons.STAGE_I__FEE_EXEMPTED, status, appId, step]);
          break;
        case "Private":
          await up_stm1.execute([cons.STAGE_I__FEE_PAID, status, appId, step]);
      }
      break;
    case cons.STAGE_I_DOCUMENT_UPLAOD:
      await up_stm1.execute([cons.STAGE_I__DOCUMENT_UPLOADED, status, appId, step]);
      break;
    case cons.STAGE_I_SUBMIT:
      await up_stm1.execute([cons.STAGE_I__SUBMITED, status, appId, step]);
      break;
    case cons.STAGE_I__ASSESSMENT:
      await up_stm1.execute([cons.STAGE_I__ASSESSMENT_COMPLETED, status, appId, step]);
      break;
    case cons.NOC_ISSUANCE:
      await up_stm1.execute([cons.NOC_ISSUANCE_ISSUED, status, appId, step]);
      break;
    case cons.STAGE_II_FORM_FILLING:
      await up_stm1.execute([cons.STAGE_II__FILLED, status, appId, step]);
      break;
    case cons.STAGE_II_FEE:
      await up_stm1.execute([cons.STAGE_II__FEE_PAID, status, appId, step]);
      break;
    case cons.STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS:
      await up_stm1.execute([cons.STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_COMPLETED, status, appId, step]);
      break;
    case cons.STAGE_II_DOCUMENT_UPLAOD:
      await up_stm1.execute([cons.STAGE_II__DOCUMENT_UPLOADED, status, appId, step]);
      break;
    case cons.STAGE_II_SUBMIT:
      await up_stm1.execute([cons.STAGE_II__SUBMITED, status, appId, step]);
      break;
    case cons.STAGE_II__ASSESSMENT:
      await up_stm1.execute([cons.STAGE_II__ASSESSMENT_COMPLETED, status, appId, step]);
      break;
    case cons.STAFF_DETAILS:
      await up_stm1.execute([cons.STAFF_DETAILS_COMPLETED, status, appId, step]);
      break;
    case cons.INSP_SLOT_SELECTION:
      await up_stm1.execute([cons.INSP_SLOT_SELECTION_COMPLETED, status, appId, step]);
      break;
    case cons.INSPENCTION:
      throw new Error("To be Continue....");
      break;
    default:
      throw new Error("App FLow Step Does not Match");
      break;
  }
};


export const getInstTradeDetails = async (req, res) => {
  let finalResult, userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;
    const List = await MasterTradeInfo.findAll({
      attributes: ["trade_id", "trade_name", "is_new_age"], // 👈 only these two columns
      where: { /* optionally filter by appId if needed */ }
    }); finalResult = List
  } catch (err) {
    throw err;
  }
  return finalResult;
};

export const getFilledTrades = async (req, res) => {
  let finalResult = {}, userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;
    // Getting Trade Info 
    const result = await TradesNewInstTrades.findAll({
      where: { appId: appId }, include: [
        {
          model: MasterTradeInfo,
          as: "tradeInfo"
        }
      ]
    });

    const tradesArray = result.map((obj, index) => {
      const { tradeId, unit_in_shift1, unit_in_shift2, unit_in_shift3 } = obj;
      return { trade: tradeId, units_in_shift_1: unit_in_shift1, units_in_shift_2: unit_in_shift2, units_in_shift_3: unit_in_shift3 }
    });
    finalResult = { trades: tradesArray };

  } catch (err) {
    throw err;
  }
  return finalResult;
};


export const getStatusFillingMte = async (req, res) => {

  let finalResult;
  try {
    const { appId } = req.body;
    const { email } = req.user;
    const userId = req.userInfo.user_id;


    finalResult = await TradeWideMachineToolEquipmentStatus.findAll({
      where: { appId: appId }, include: [
        {
          attributes: ["trade_type", "trade_id", "trade_name", "is_new_age"],
          model: MasterTradeInfo,
          as: "tradeInfo"
        },
      ],
    });
    if (!finalResult) {
      throw "Trade Units Not Filled";
    }


    finalResult = finalResult.map((obj) => {
      const plain = obj.get({ plain: true });
      return { ...plain, stepLabel: plain.stepTitle, stepDescription: plain.stepLabel };
    })



  } catch (err) {
    throw err;
  }
  return finalResult;

};


export const saveSignageBoards = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { data, appId } = req.body;
    const { email } = req.user;
    const userId = req.userInfo.user_id;
    const jsonData = JSON.parse(data);

    for (const [index, item] of jsonData.signage_boards.entries()) {
      const up_document = req.files.find(f => f.fieldname === `signage_boards[${index}].document`);
      const { particular, document } = item;
      let to_upload_doc = '';
      if (typeof document == "string") {
        to_upload_doc = document;
      }
      else {
        if (!up_document) {
          throw new Error(`File missing for ${item.document} at index ${index}`);
        }
        to_upload_doc = up_document.filename;
      }

      const toUpdate = { document: to_upload_doc, submit_date: cons.currentDate, status: cons.SL.FILLED };
      await SignageBoardsParticulars.update(toUpdate, { where: { particular: particular, appId: appId, userId: userId }, transaction: t })
    }

    await FormFlowStageII.update({ status: cons.SL.FILLED }, { where: { appId, step: cons.SIGNAGE_BOARDS }, transaction: t, });
    await FormFlowStageII.update({ stepStatus: cons.SL.ACTIVE }, { where: { appId, step: cons.ELECTRICITY_CONNECTION_DETAILS }, transaction: t, });


    // throw jsonData;

    await t.commit();
    // await t.rollback();
  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    // if (connection) await connection.end();
  }
  return { msg: "Information Successfully" };

};

export const saveDocumentNcompleteStageII = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { data, appId } = req.body;
    const { email } = req.user;
    const userId = req.userInfo.user_id;
    const jsonData = JSON.parse(data);
    const { iaccept, mte_photos_per_unit, gst_invoices } = jsonData;

    if (iaccept != true) {
      throw "Invalid Request";
    }


    for (const [index, item] of mte_photos_per_unit.entries()) {
      const { slno, tradeId, appId, uniqueId } = item;
      const photo = req.files.find(f => f.fieldname === `mte_photos_per_unit[${index}].photo`);
      if (!photo) {
        throw new Error(`File missing for ${item.document} at index ${index}`);
      }
      await GeoTaggedPhotoOfMTE.update({ photo: photo.filename, submit_date: cons.currentDate, status: cons.SL.FILLED }, { where: { slno: slno, tradeId: tradeId, appId: appId, uniqueId: uniqueId }, transaction: t })
    }


    for (const [index, item] of gst_invoices.entries()) {
      const { slno, uniqueId, tradeId, appId } = item;
      const document = req.files.find(f => f.fieldname === `gst_invoices[${index}].document`);
      if (!document) {
        throw new Error(`File missing for ${item.document} at index ${index}`);
      }
      await GstInvoicesMachineryPayment.update({ document: document.filename, submit_date: cons.currentDate, status: cons.SL.FILLED }, { where: { slno: slno, uniqueId: uniqueId, tradeId: tradeId, appId: appId }, transaction: t })
    }
    // Application Stage II Form
    await FormFlowStageII.update({ status: cons.SL.FILLED }, { where: { appId, step: cons.DOCUMENT_UPLOADS }, transaction: t, });

    // Application Flow
    const appFlow = await AppFlow.findOne({ where: { appId, step: cons.STAGE_I_SUBMIT }, transaction: t, });
    await appFlow.update({ stepStatus: cons.SL.COMPLETED, status: cons.STAGE_I__SUBMITED, completedDate: cons.currentDate })

    // Application Flow
    await AppFlow.update({ stepStatus: cons.SL.PENDING, status: cons.STAGE_I__ASSESSMENT_ON_PROGRESS }, { where: { appId, step: cons.STAGE_I__ASSESSMENT }, transaction: t, });

    // throw jsonData;
    await t.commit();
    // await t.rollback();
  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    // if (connection) await connection.end();
  }
  return { msg: "Information Successfully" };

};

export const saveAmenities = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { data, appId } = req.body;
    const { email } = req.user;
    const userId = req.userInfo.user_id;
    const jsonData = JSON.parse(data);


    const toUpdates = [];
    for (const [index, item] of jsonData.particulars_1.entries()) {
      const { particular, appId, available_area } = item;
      const toUpdate = {
        available_area: available_area,
        submit_date: cons.currentDate,
        status: cons.SL.FILLED
      };
      toUpdates.push(AmenitiesParticulars.update(toUpdate, { where: { particular: particular, appId: appId, userId: userId }, transaction: t }))
    }


    const toUpdates2 = [];
    for (const [index, item] of jsonData.particulars_2.entries()) {

      const document = req.files.find(f => f.fieldname === `particulars_2[${index}].document`);
      // throw document;
      if (!document) {
        throw new Error(`File missing for ${item.document} at index ${index}`);
      }
      const { particular } = item;
      const toUpdate = {
        document: document.filename,
        submit_date: cons.currentDate,
        status: cons.SL.FILLED
      };
      toUpdates2.push(AmenitiesParticulars.update(toUpdate, { where: { particular: particular, appId: appId, userId: userId }, transaction: t }))
    }


    await Promise.all(toUpdates);
    await Promise.all(toUpdates2);

    await FormFlowStageII.update({ status: cons.SL.FILLED }, { where: { appId, step: cons.AMENITIES_AREA }, transaction: t, });
    await FormFlowStageII.update({ stepStatus: cons.SL.ACTIVE }, { where: { appId, step: cons.SIGNAGE_BOARDS }, transaction: t, });


    // throw jsonData;

    await t.commit();
    // await t.rollback();
  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    // if (connection) await connection.end();
  }
  return { msg: "Information Successfully" };

};

export const getElectricityDetails = async (req, res) => {
  let finalResult = {};
  try {
    const { data, appId } = req.body;
    const { email } = req.user;
    const userId = req.userInfo.user_id;

    const found1 = await ElectricityModel.findOne({ where: { appId: appId, userId: userId } });
    const latest_electricity_bill_meter_sealing_report = await ElectricityDocuments.findOne({ where: { document_type: 'latest_electricity_bill_meter_sealing_report', appId: appId, userId: userId } });
    const power_supply_back_power = await ElectricityDocuments.findOne({ where: { document_type: 'power_supply_back_power', appId: appId, userId: userId } });
    const power_supply_purchase_related_documents = await ElectricityDocuments.findOne({ where: { document_type: 'power_supply_purchase_related_documents', appId: appId, userId: userId } });
    const fire_and_safety_certificate = await ElectricityDocuments.findOne({ where: { document_type: 'fire_and_safety_certificate', appId: appId, userId: userId } });


    finalResult = {
      consumer_name: found1.consumer_name, // STRING
      consumer_number: found1.consumer_number, // NUMBER
      electricity_authority_name: found1.electricity_authority_name,  // STRING
      electricity_authority_website: found1.electricity_authority_website, // URL
      total_available_sanction_load_in_kw: found1.total_available_sanction_load_in_kw, //NUMBER

      latest_electricity_bill_meter_sealing_report: latest_electricity_bill_meter_sealing_report.document,
      power_supply_back_power: latest_electricity_bill_meter_sealing_report.document, //FILE
      power_supply_purchase_related_documents: power_supply_purchase_related_documents.document, //FILE
      fire_and_safety_certificate: fire_and_safety_certificate.document, //FILE
    }
  } catch (err) {
    throw err;
  }
  return finalResult;

};
export const saveElectricityDetails = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { data, appId } = req.body;
    const { email } = req.user;
    const userId = req.userInfo.user_id;
    const jsonData = JSON.parse(data);
    const { consumer_name, consumer_number, electricity_authority_name, electricity_authority_website, total_available_sanction_load_in_kw } = jsonData

    const toSave = {
      consumer_name: consumer_name,
      consumer_number: consumer_number,
      electricity_authority_name: electricity_authority_name,
      electricity_authority_website: electricity_authority_website,
      total_available_sanction_load_in_kw: total_available_sanction_load_in_kw,
      appId: appId,
      userId: userId
    }

    await ElectricityModel.create(toSave, { transaction: t })


    // FILES
    const latest_electricity_bill_meter_sealing_report = req.files.find(f => f.fieldname === `latest_electricity_bill_meter_sealing_report`);
    if (!latest_electricity_bill_meter_sealing_report) {
      throw new Error(`File missing for ${item.latest_electricity_bill_meter_sealing_report}`);
    }
    await ElectricityDocuments.create({ document_type: 'latest_electricity_bill_meter_sealing_report', document: latest_electricity_bill_meter_sealing_report.filename, status: cons.SL.FILLED, submit_date: cons.currentDate, appId: appId, userId: userId }, { transaction: t })



    const power_supply_back_power = req.files.find(f => f.fieldname === `power_supply_back_power`);
    if (!power_supply_back_power) {
      throw new Error(`File missing for ${item.power_supply_back_power}`);
    }
    await ElectricityDocuments.create({ document_type: 'power_supply_back_power', document: power_supply_back_power.filename, status: cons.SL.FILLED, submit_date: cons.currentDate, appId: appId, userId: userId }, { transaction: t })



    const power_supply_purchase_related_documents = req.files.find(f => f.fieldname === `power_supply_purchase_related_documents`);
    if (!power_supply_purchase_related_documents) {
      throw new Error(`File missing for ${item.power_supply_purchase_related_documents}`);
    }
    await ElectricityDocuments.create({ document_type: 'power_supply_purchase_related_documents', document: power_supply_purchase_related_documents.filename, status: cons.SL.FILLED, submit_date: cons.currentDate, appId: appId, userId: userId }, { transaction: t })



    const fire_and_safety_certificate = req.files.find(f => f.fieldname === `fire_and_safety_certificate`);
    if (!fire_and_safety_certificate) {
      throw new Error(`File missing for ${item.fire_and_safety_certificate}`);
    }
    await ElectricityDocuments.create({ document_type: 'fire_and_safety_certificate', document: fire_and_safety_certificate.filename, status: cons.SL.FILLED, submit_date: cons.currentDate, appId: appId, userId: userId }, { transaction: t })

    // throw toSave;

    await FormFlowStageII.update({ status: cons.SL.FILLED }, { where: { appId, step: cons.ELECTRICITY_CONNECTION_DETAILS }, transaction: t, });
    await FormFlowStageII.update({ stepStatus: cons.SL.ACTIVE }, { where: { appId, step: cons.FEE_PAYMENT_FOR_STAGEII }, transaction: t, });


    await t.commit();
    // await t.rollback();
  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    // if (connection) await connection.end();
  }
  return { msg: "Information Successfully" };

};
export const setBuildingDetail = async (req, res) => {
  let connection, stmt, results, update, formattedDate, jsonData, submitDate, updateDate;
  // formattedDate = new Date().toISOString(); // "2025-08-05T07:25:13.123Z"
  // submitDate = new Date().toISOString().slice(0, 19).replace('T', ' ');

  formattedDate = dayjs().tz("Asia/Kolkata").toISOString();
  // console.log("ISO India:", formattedDate);

  submitDate = updateDate = dayjs().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");

  // console.log("MySQL India:", submitDate);
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  const t = await sequelize.transaction();
  try {
    // connection = await mysql.createConnection(affDbConfig);
    const { data, appId } = req.body;
    const { email } = req.user;
    const userId = req.userInfo.user_id;
    jsonData = JSON.parse(data);


    const { name_of_bcc_issued_authority, date_of_bcc_issued } = jsonData;
    const entrance_gate_photo_of_plot_with_signage_board = req.files.find(f => f.fieldname === "entrance_gate_photo_of_plot_with_signage_board");
    const front_view_photo_of_building = req.files.find(f => f.fieldname === "front_view_photo_of_building");
    const side_view_photo_of_building = req.files.find(f => f.fieldname === "side_view_photo_of_building");


    // throw { entrance_gate_photo_of_plot_with_signage_board, front_view_photo_of_building, side_view_photo_of_building }
    // throw req.files;
    // throw jsonData;
    // Saving Land Conversion Certificate


    // Getting FIlled Trade and Units 
    const tradeUnits = await TradesNewInstTrades.findAll({
      where: { appId: appId }, include: [
        {
          model: MasterTradeInfo,
          as: "tradeInfo"
        }
      ]
    });

    if (!tradeUnits) {
      throw "Trade Units Not Filled";
    }


    // Getting of Total Strength 
    const array_total_unit_strength = [];
    for (const [index, trade_units_obj] of tradeUnits.entries()) {
      const { unit_strength } = trade_units_obj.tradeInfo;
      const { unit_in_shift1, unit_in_shift2, unit_in_shift3, tradeInfo } = trade_units_obj;
      const arrayValues = [unit_in_shift1, unit_in_shift2, unit_in_shift3];
      const base_unit = Math.max(...arrayValues.filter(v => v !== "").map(Number));
      const calculated = { unit_strength, base_unit, total_unit_strength: unit_strength * base_unit };
      array_total_unit_strength.push(calculated.total_unit_strength);
    }
    const total_strength2 = array_total_unit_strength.reduce((sum, val) => sum + val, 0);

    // throw array_total_unit_strength;
    // throw tradeUnits;
    // throw total_strength2;



    for (const [index, item] of jsonData.bld_plan_documents.entries()) {
      const document = req.files.find(f => f.fieldname === `bld_plan_documents[${index}].document`);
      // throw document;
      if (!document) {
        throw new Error(`File missing for ${item.document} at index ${index}`);
      }
      const { language } = item;
      switch (language) {
        case "English":
        case "Hindi":
          await BuildingPlan.create({
            uniqueId: cons.randomId(),
            appId: appId,
            language_for_building_plan: language,
            document_of_building_plan: document.filename,
            uploadDate: cons.currentDate,
          }, { transaction: t });
          break;
        default:
          const lcc_notarised_documents = req.files.find(f => f.fieldname === `bld_plan_documents[${index}].notarised_document`);
          if (!lcc_notarised_documents) {
            throw new Error(`File missing for`);
          }
          await BuildingPlan.create({
            uniqueId: cons.randomId(),
            appId: appId,
            language_for_building_plan: language,
            document_of_building_plan: document.filename,
            notarised_document_of_building_plan: lcc_notarised_documents.filename,
            uploadDate: cons.currentDate,
          }, { transaction: t });
          break;
      }
    }

    for (const [index, item] of jsonData.bld_completion_cert.entries()) {
      const document = req.files.find(f => f.fieldname === `bld_completion_cert[${index}].document`);
      // throw document;
      if (!document) {
        throw new Error(`File missing for ${item.document} at index ${index}`);
      }
      const { language } = item;
      switch (language) {
        case "English":
        case "Hindi":
          await BccDocuments.create({
            uniqueId: cons.randomId(),
            appId: appId,
            language_for_building_completion_certificate: language,
            building_completion_certificate: document.filename,
            name_of_bcc_issued_authority: name_of_bcc_issued_authority,
            date_of_bcc_issued: date_of_bcc_issued,
            uploadDate: cons.currentDate,
          }, { transaction: t });
          break;
        default:
          const lcc_notarised_documents = req.files.find(f => f.fieldname === `bld_completion_cert[${index}].notarised_document`);
          if (!lcc_notarised_documents) {
            throw new Error(`File missing for`);
          }
          await BccDocuments.create({
            uniqueId: cons.randomId(),
            appId: appId,
            language_for_building_completion_certificate: language,
            building_completion_certificate: document.filename,
            notarised_document_of_bcc: lcc_notarised_documents.filename,
            name_of_bcc_issued_authority: name_of_bcc_issued_authority,
            date_of_bcc_issued: date_of_bcc_issued,
            uploadDate: cons.currentDate,
          }, { transaction: t });
          break;
      }
    }

    const photo_list = [
      {
        uniqueId: cons.randomId(),
        photoView: cons.FRONT_VIEW_PHOTO_OF_BUILDING,
        photo_pth: entrance_gate_photo_of_plot_with_signage_board.filename,
        appId: appId,
        uploadDate: cons.currentDate
      },
      {
        uniqueId: cons.randomId(),
        photoView: cons.SIDE_VIEW_PHOTO_OF_BUILDING,
        photo_pth: front_view_photo_of_building.filename,
        appId: appId,
        uploadDate: cons.currentDate
      },
      {
        uniqueId: cons.randomId(),
        photoView: cons.ENTRANCE_GATE_PHOTO_OF_PLOT_WITH_SIGNAGE_BOARD,
        photo_pth: side_view_photo_of_building.filename,
        appId: appId,
        uploadDate: cons.currentDate
      },];

    await BuildingPhotos.bulkCreate(photo_list, { transaction: t });


    // Settign Up Stage I Form Flow
    const found3 = await FormFlowStageII.findOne({ where: { appId: appId } });
    if (!found3) { //!found3
      const mainStepsData = cons.STAGE_II_APP_FORM_FLOW.map((step) => {
        switch (step.step) {
          case cons.BUILDING_DETAIL:
            return { ...step, status: cons.FILLED, stepStatus: cons.SL.ACTIVE, submitDate: cons.currentDate, appId: appId, userId: userId, }
          case cons.CIVIL_INFRASTRUCTURE_DETAIL:
            return { ...step, stepStatus: cons.SL.ACTIVE, appId: appId, userId: userId }
          default:
            return { ...step, appId: appId, userId: userId, }
        }
      });
      await FormFlowStageII.bulkCreate(mainStepsData, { transaction: t });
      // throw mainStepsData;

      for (const [index, flow] of mainStepsData.entries()) {
        if ("subSteps" in flow) {
          switch (flow.step) {
            case cons.CIVIL_INFRASTRUCTURE_DETAIL:
              const mainStepsData = flow.subSteps.map((step) => ({ ...step, appId: appId, userId: userId, }));
              await AppFormSubCivilInfra.bulkCreate(mainStepsData, { transaction: t });
              // Setting up Required Informtion of 
              for (const [index, subFlow] of flow.subSteps.entries()) {
                switch (subFlow.step) {
                  case cons.CIC.TRADEWISE_WORKSHOP:
                    // Setting Up Required Number of Workshop
                    for (const [index, trade_units_obj] of tradeUnits.entries()) {
                      const { unit_in_shift1, unit_in_shift2, unit_in_shift3, tradeInfo } = trade_units_obj;
                      const arrayValues = [unit_in_shift1, unit_in_shift2, unit_in_shift3];
                      const max = Math.max(...arrayValues.filter(v => v !== "").map(Number));
                      for (let i = 0; i < max; i++) {
                        const toBeSave = {
                          appId: appId,
                          trade_id: trade_units_obj.tradeId,
                          workshop: cons.WorkshopName[i],
                          required_area: tradeInfo.workshop_area_requirement,
                          userId: userId
                        };
                        await TradewiseWorkshop.create(toBeSave, { transaction: t });
                      }
                    }
                    // throw "dfasdfas";
                    break;
                  case cons.CIC.TRADEWISE_CLASSROOMS:
                    for (const [index, trade_units_obj] of tradeUnits.entries()) {
                      const { unit_in_shift1, unit_in_shift2, unit_in_shift3, tradeInfo } = trade_units_obj;
                      const arrayValues = [unit_in_shift1, unit_in_shift2, unit_in_shift3];
                      const max = Math.max(...arrayValues.filter(v => v !== "").map(Number));
                      for (let i = 0; i < max; i++) {
                        // Setting Up Number of Classromms
                        const toBeSaveClassromms = {
                          appId: appId,
                          trade_id: trade_units_obj.tradeId,
                          clasroom: cons.ClassroomName[i],
                          required_area: tradeInfo.classroom_area,
                          userId: userId
                        };
                        await TradewiseClassRoom.create(toBeSaveClassromms, { transaction: t });
                      }
                    }
                    break;
                  case cons.CIC.MULTIPURPOSE_HALL:
                    const array_total_unit_strength = [];
                    for (const [index, trade_units_obj] of tradeUnits.entries()) {
                      const { unit_strength } = trade_units_obj.tradeInfo;
                      const { unit_in_shift1, unit_in_shift2, unit_in_shift3, tradeInfo } = trade_units_obj;
                      const arrayValues = [unit_in_shift1, unit_in_shift2, unit_in_shift3];
                      const base_unit = Math.max(...arrayValues.filter(v => v !== "").map(Number));
                      const calculated = { unit_strength, base_unit, total_unit_strength: unit_strength * base_unit };
                      array_total_unit_strength.push(calculated.total_unit_strength);
                    }
                    const total_strength = array_total_unit_strength.reduce((sum, val) => sum + val, 0);
                    const final_required_area_of_multipurposehall = total_strength * cons.AREA_FOR_ONE_STUDENT;
                    // throw final_required_area_of_multipurposehall;
                    const toSave = {
                      category: cons.common_infra_category.CIVIL,
                      particular: cons.CIK.MULTIPURPOSE_HALL,
                      required_area: final_required_area_of_multipurposehall,
                      appId: appId,
                      userId: userId
                    }
                    await CommonCivilInfrastructure.create(toSave, { transaction: t });
                    break;
                  case cons.CIC.IT_LAB:
                    // throw cons.COMMON_AREA;
                    {
                      const array_total_unit_strength = [];
                      for (const [index, trade_units_obj] of tradeUnits.entries()) {
                        const { unit_strength } = trade_units_obj.tradeInfo;
                        const { unit_in_shift1, unit_in_shift2, unit_in_shift3, tradeInfo } = trade_units_obj;
                        const arrayValues = [unit_in_shift1, unit_in_shift2, unit_in_shift3];
                        const base_unit = Math.max(...arrayValues.filter(v => v !== "").map(Number));
                        const calculated = { unit_strength, base_unit, total_unit_strength: unit_strength * base_unit };
                        array_total_unit_strength.push(calculated.total_unit_strength);
                      }
                      // throw array_total_unit_strength;
                      const total_strength = array_total_unit_strength.reduce((sum, val) => sum + val, 0);
                      const rounded_up_total_strength = cons.roundUpToNextTen(total_strength);

                      const final_required_area_of_it_lab = cons.AREA_FOR_ONE_STUDENT_FOR_IT_LAB * rounded_up_total_strength;
                      // throw final_required_area_of_multipurposehall;
                      // throw { total_strength, rounded_up_total_strength, final_required_area_of_it_lab };
                      const toSave = {
                        category: cons.common_infra_category.CIVIL,
                        particular: cons.CIK.IT_LAB,
                        required_area: final_required_area_of_it_lab,
                        appId: appId,
                        userId: userId
                      }
                      await CommonCivilInfrastructure.create(toSave, { transaction: t });
                      break;
                    }
                    break;
                  case cons.CIC.LIBRARY:
                    {
                      const array_total_unit_strength = [];
                      for (const [index, trade_units_obj] of tradeUnits.entries()) {
                        const { unit_strength } = trade_units_obj.tradeInfo;
                        const { unit_in_shift1, unit_in_shift2, unit_in_shift3, tradeInfo } = trade_units_obj;
                        const arrayValues = [unit_in_shift1, unit_in_shift2, unit_in_shift3];
                        const base_unit = Math.max(...arrayValues.filter(v => v !== "").map(Number));
                        const calculated = { unit_strength, base_unit, total_unit_strength: unit_strength * base_unit };
                        array_total_unit_strength.push(calculated.total_unit_strength);
                      }
                      // throw array_total_unit_strength;
                      const total_strength = array_total_unit_strength.reduce((sum, val) => sum + val, 0);
                      const final_required_area_of_library = cons.AREA_FOR_ONE_STUDENT_FOR_LIBRARY * total_strength;
                      // throw { total_strength,final_required_area_of_library };
                      const toSave = {
                        category: cons.common_infra_category.CIVIL,
                        particular: cons.CIK.LIBRARY,
                        required_area: final_required_area_of_library,
                        appId: appId,
                        userId: userId
                      }
                      await CommonCivilInfrastructure.create(toSave, { transaction: t });
                      break;
                    }
                    break;
                  case cons.CIC.PLACEMENT_AND_COUNSELLING_ROOM:
                    {
                      const array_total_unit_strength = [];
                      for (const [index, trade_units_obj] of tradeUnits.entries()) {
                        const { unit_strength } = trade_units_obj.tradeInfo;
                        const { unit_in_shift1, unit_in_shift2, unit_in_shift3, tradeInfo } = trade_units_obj;
                        const arrayValues = [unit_in_shift1, unit_in_shift2, unit_in_shift3];
                        const base_unit = Math.max(...arrayValues.filter(v => v !== "").map(Number));
                        const calculated = { unit_strength, base_unit, total_unit_strength: unit_strength * base_unit };
                        array_total_unit_strength.push(calculated.total_unit_strength);
                      }
                      // throw array_total_unit_strength;
                      const total_strength = array_total_unit_strength.reduce((sum, val) => sum + val, 0);
                      const final_required_area_of_counselling_room = cons.AREA_FOR_ONE_STUDENT_FOR_COUNSELLING_ROOM * total_strength;
                      // throw { total_strength,final_required_area_of_counselling_room };
                      const toSave = {
                        category: cons.common_infra_category.CIVIL,
                        particular: cons.CIK.PLACEMENT_AND_COUNSELLING_ROOM,
                        required_area: final_required_area_of_counselling_room,
                        appId: appId,
                        userId: userId
                      }
                      await CommonCivilInfrastructure.create(toSave, { transaction: t });
                      break;
                    }
                    break;
                  case cons.CIC.ADMINISTRATIVE_AREA:
                    {
                      const array_total_unit_strength = [];
                      for (const [index, trade_units_obj] of tradeUnits.entries()) {
                        const { unit_strength } = trade_units_obj.tradeInfo;
                        const { unit_in_shift1, unit_in_shift2, unit_in_shift3, tradeInfo } = trade_units_obj;
                        const arrayValues = [unit_in_shift1, unit_in_shift2, unit_in_shift3];
                        const base_unit = Math.max(...arrayValues.filter(v => v !== "").map(Number));
                        const calculated = { unit_strength, base_unit, total_unit_strength: unit_strength * base_unit };
                        array_total_unit_strength.push(calculated.total_unit_strength);
                      }
                      const total_strength = array_total_unit_strength.reduce((sum, val) => sum + val, 0);
                      for (const [index, obj] of cons.ADMINISTRATIVE_AREA.entries()) {
                        const { particular } = obj;
                        switch (particular) {
                          case cons.CIK.PRINCIPAL_ROOM:
                            {
                              const final_required = cons.AREA_FOR_ONE_STUDENT_FOR_PRINCIPAL_ROOM * total_strength;
                              // throw { total_strength, final_required };
                              await CommonCivilInfrastructure.create({
                                category: cons.common_infra_category.CIVIL,
                                particular: cons.CIK.PRINCIPAL_ROOM,
                                required_area: final_required,
                                appId: appId,
                                userId: userId

                              }, { transaction: t });
                            }
                            break;
                          case cons.CIK.RECEPTION_CUM_WAITING_LOBBY:
                            {
                              const final_required = cons.AREA_FOR_ONE_STUDENT_FOR_RECEPTION_CUM_WAITING_LOBBY * total_strength;
                              // throw { total_strength, final_required };
                              await CommonCivilInfrastructure.create({
                                category: cons.common_infra_category.CIVIL,
                                particular: cons.CIK.RECEPTION_CUM_WAITING_LOBBY,
                                required_area: final_required,
                                appId: appId,
                                userId: userId

                              }, { transaction: t });
                            }
                            break;
                          case cons.CIK.STAFF_ROOM:
                            {
                              const final_required = cons.AREA_FOR_ONE_STUDENT_FOR_STAFF_ROOM * total_strength;
                              // throw { total_strength, final_required };
                              await CommonCivilInfrastructure.create({
                                category: cons.common_infra_category.CIVIL,
                                particular: cons.CIK.STAFF_ROOM,
                                required_area: final_required,
                                appId: appId, userId: userId

                              }, { transaction: t });
                            }
                            break;
                          case cons.CIK.ADMINISTRATIVE_HALL_SECTION:
                            {
                              const final_required = cons.AREA_FOR_ONE_STUDENT_FOR_ADMINISTRATIVE_HALL_SECTION * total_strength;
                              // throw { total_strength, final_required };
                              await CommonCivilInfrastructure.create({
                                category: cons.common_infra_category.CIVIL,
                                particular: cons.CIK.ADMINISTRATIVE_HALL_SECTION,
                                required_area: final_required,
                                appId: appId, userId: userId

                              }, { transaction: t });
                            }
                            break;
                          default:
                            throw "Something Went Wrong";
                            break;
                        }
                      }
                      break;
                    }
                    break;
                  default:
                    throw `Something Went wrong with Sub Step: ${subFlow.step}`
                    break;
                }

              }
              break;
            case cons.TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS:
              {
                const mainStepsData = flow.subSteps.map((step) => ({ ...step, appId: appId, userId: userId, }));
                await SubFlowMachineryToolEquipment.bulkCreate(mainStepsData, { transaction: t });

                for (const [index, subFlow] of flow.subSteps.entries()) {
                  switch (subFlow.step) {
                    case cons.CIK.SPECIFICATIONS_OF_IT_LAB:
                      for (const [index, obj] of cons.iti_lab_particulars.entries()) {
                        const { key } = obj;
                        switch (key) {
                          case cons.iti_lab_particulars_keys.DESKTOP_COMPUTER_WITH_LATEST_CONFIGURATION.key:
                            {
                              const { key, instruction } = obj;
                              const rounded_up = cons.roundUpToNextTen(total_strength2);
                              const final_req_qty = rounded_up / 10;
                              await ItLabParticulars.create({
                                particular: key,
                                instruction: instruction,
                                required_qty: final_req_qty,
                                appId: appId,
                                userId: userId

                              }, { transaction: t });
                            }
                            break;
                          case cons.iti_lab_particulars_keys.INTERNET_CONNECTION.key:
                          case cons.iti_lab_particulars_keys.COMPUTER_WITH_MULTIMEDIA_ANTI_VIRUS_ETC.key:
                          case cons.iti_lab_particulars_keys.LAN_CABLING_ETC.key:
                          case cons.iti_lab_particulars_keys.PRINTER_LASER.key:
                          case cons.iti_lab_particulars_keys.SCANNER.key:
                          case cons.iti_lab_particulars_keys.SERVER.key:
                          case cons.iti_lab_particulars_keys.EXTERNAL_HARD_DISK_1TB.key:
                          case cons.iti_lab_particulars_keys.INSTRUCTOR_OFFICE_CHAIR.key:
                          case cons.iti_lab_particulars_keys.INSTRUCTOR_OFFICE_TABLE.key:
                          case cons.iti_lab_particulars_keys.TRAINEES_COMPUTER_CHAIRS.key:
                          case cons.iti_lab_particulars_keys.TRAINEES_COMPUTER_TABLES.key:
                          case cons.iti_lab_particulars_keys.BLACK_WHITE_BOARD_4X6_FEET.key:
                            {
                              const { key, instruction } = obj;
                              await ItLabParticulars.create({
                                particular: key,
                                instruction: instruction,
                                appId: appId,
                                userId: userId

                              }, { transaction: t });
                            }
                            break;
                          default:
                            throw "Invalid ITI Lab Particular";
                            break;
                        }
                      }
                      break;
                    case cons.CIK.TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS:
                      {
                        const final_array = [];
                        const final_array_for_status = [];
                        for (const [index, tradeInfo] of tradeUnits.entries()) {
                          const { tradeId } = tradeInfo;

                          const List = await MasterTradeToolEquipment.findAll({ where: { trade_id: tradeId } });
                          for (const [index, tool] of List.entries()) {
                            const { tool_category, Sub_category, Quantity, Qty_type, Per_unit } = tool;
                            const toSave = {
                              trade_id: tradeId,
                              tool_id: tool.slno,
                              required_quantity: Quantity,
                              appId: appId,
                              userId: userId
                            }
                            final_array.push(toSave);
                          }

                          final_array_for_status.push({
                            userId: userId,
                            appId: appId,
                            tradeId: tradeId,
                            stepNo: index + 1,
                            stepTitle: tradeInfo.tradeInfo.trade_name,
                            stepLabel: tradeInfo.tradeInfo.trade_type,
                            stepStatus: (index + 1) === 1 ? cons.SL.ACTIVE : cons.SL.IN_ACTIVE,
                            nextStep: index === tradeUnits.length - 1 ? 0 : index + 2
                          })
                        }

                        // throw final_array_for_status;
                        await TradeWideMachineToolEquipmentStatus.bulkCreate(final_array_for_status, { transaction: t });
                        await TradeWiseToolEquipments.bulkCreate(final_array, { transaction: t });
                      }

                      break;
                    default:
                      throw `Something Went wrong with Sub Step: ${subFlow.step}`
                      break;
                  }
                }
              }
              break;
            default:
              // throw `Something Went wrong with Sub Step: ${flow.step}`
              break;
          }
        }

        // Setting Up Steps 
        switch (flow.step) {
          case cons.AMENITIES_AREA:
            {
              const array_total_unit_strength = [];
              for (const [index, trade_units_obj] of tradeUnits.entries()) {
                const { unit_strength } = trade_units_obj.tradeInfo;
                const { unit_in_shift1, unit_in_shift2, unit_in_shift3, tradeInfo } = trade_units_obj;
                const arrayValues = [unit_in_shift1, unit_in_shift2, unit_in_shift3];
                const base_unit = Math.max(...arrayValues.filter(v => v !== "").map(Number));
                const calculated = { unit_strength, base_unit, total_unit_strength: unit_strength * base_unit };
                array_total_unit_strength.push(calculated.total_unit_strength);
              }
              const total_strength = array_total_unit_strength.reduce((sum, val) => sum + val, 0);
              // throw cons.AMENITIES_AREAS;
              for (const [index, obj] of cons.AMENITIES_AREAS.entries()) {
                const { particular } = obj;
                switch (particular) {
                  case cons.AMNT.FIRST_AID_ROOM:
                    {
                      const final_required = cons.AREA_FOR_FIRST_AID_ROOM;
                      await CommonCivilInfrastructure.create({
                        category: cons.common_infra_category.AMENITIES,
                        particular: cons.AMNT.FIRST_AID_ROOM,
                        required_area: final_required,
                        appId: appId,
                        userId: userId
                      }, { transaction: t });
                    }
                    break;
                  case cons.AMNT.LIBRARY_AND_READING_ROOM:
                    {
                      const final_required_area = total_strength * cons.AREA_FOR_ONE_STUDENT_FOR_LIBRARY_AND_READING_ROOM;
                      await CommonCivilInfrastructure.create({
                        category: cons.common_infra_category.AMENITIES,
                        particular: cons.AMNT.LIBRARY_AND_READING_ROOM,
                        required_area: final_required_area,
                        appId: appId, userId: userId

                      }, { transaction: t });
                    }
                    break;
                  default:
                    throw "Something Went Wrong";
                    break;
                }
              }
              const toSaveParticulars = [];
              // throw cons.AMENITIES_PARTICULARS;
              for (const [index, obj] of cons.AMENITIES_PARTICULARS.entries()) {
                const { particular, instruction } = obj;
                switch (particular) {
                  case cons.AMNT.FIRST_AID_ROOM:
                    {
                      toSaveParticulars.push(AmenitiesParticulars.create({
                        particular: particular,
                        required_area: cons.AREA_FOR_FIRST_AID_ROOM,
                        appId: appId,
                        userId: userId,
                        AreaUnit: cons.units.sqm
                      }, { transaction: t }))
                    }
                    break;
                  case cons.AMNT.LIBRARY_AND_READING_ROOM:
                    {
                      toSaveParticulars.push(AmenitiesParticulars.create({
                        particular: particular,
                        required_area: total_strength * cons.AREA_FOR_ONE_STUDENT_FOR_LIBRARY_AND_READING_ROOM,
                        appId: appId,
                        userId: userId,
                        AreaUnit: cons.units.sqm
                      }, { transaction: t }))
                    }
                    break;
                  case cons.AMNT.PLAYGROUND:
                  case cons.AMNT.DRINKING_WATER_FACILITY:
                  case cons.AMNT.AVAILABILITY_OF_STAIRCASES:
                  case cons.AMNT.TOILETS_WATER_CLOSETS:
                  case cons.AMNT.GENERAL_PARKING_DETAILS:
                    {
                      const { instruction } = obj;
                      toSaveParticulars.push(AmenitiesParticulars.create({
                        particular: particular,
                        instruction: instruction,
                        appId: appId,
                        userId: userId
                      }, { transaction: t }))
                    }
                    break;
                  default:
                    throw "Invalid Particular";
                    break;
                }
              }
              // Wait for all updates to complete
              await Promise.all(toSaveParticulars);
              // throw cons.AMENITIES_PARTICULARS;
            }
            break;
          case cons.SIGNAGE_BOARDS:
            {
              const toSaveParticulars = [];
              for (const [index, obj] of cons.Signage_Boards_Particulars.entries()) {
                // throw obj;
                const { key, instruction } = obj;
                switch (key) {
                  case cons.Signage_Boards_Keys.SIGNAGE_BOARD_ON_PLOT_ENTRANCE.key:
                  case cons.Signage_Boards_Keys.SIGNAGE_BOARD_ON_INSTITUTE_BUILDING.key:
                  case cons.Signage_Boards_Keys.SIGNAGE_BOARDS.key:
                  case cons.Signage_Boards_Keys.TRADE_DETAILS_BOARD.key:
                  case cons.Signage_Boards_Keys.STAFF_DETAILS_BOARD.key:
                  case cons.Signage_Boards_Keys.EXIT_BOARD.key:
                  case cons.Signage_Boards_Keys.BOARD_INDICATING_DANGER_SIGNS.key:
                  case cons.Signage_Boards_Keys.PROHIBITED_AREA_INDICATORS.key:
                  case cons.Signage_Boards_Keys.SEXUAL_HARASSMENT_REDRESSAL_COMMITTEE_NOTICE.key:
                    toSaveParticulars.push(SignageBoardsParticulars.create({
                      particular: key,
                      instruction: instruction,
                      appId: appId,
                      userId: userId
                    }, { transaction: t }))
                    break;
                  default:
                    throw "Invalid Signage_Boards_Keys";
                    break;
                }
              }
              await Promise.all(toSaveParticulars);
            }
            break;
          case cons.DOCUMENT_UPLOADS:
            {
              const mte_each_unit = [];
              for (const [index, trade_units_obj] of tradeUnits.entries()) {
                const { tradeId } = trade_units_obj
                const { unit_strength } = trade_units_obj.tradeInfo;
                const { unit_in_shift1, unit_in_shift2, unit_in_shift3, tradeInfo } = trade_units_obj;
                const arrayValues = [unit_in_shift1, unit_in_shift2, unit_in_shift3];
                const base_unit = Math.max(...arrayValues.filter(v => v !== "").map(Number));
                for (let i = 1; i <= base_unit; i++) {
                  mte_each_unit.push(GeoTaggedPhotoOfMTE.create({ uniqueId: cons.randomId(), tradeId: tradeId, appId: appId, unit: i }, { transaction: t }))
                }
                await GstInvoicesMachineryPayment.create({ uniqueId: cons.randomId(), tradeId: tradeId, appId: appId, }, { transaction: t })
              }
              await Promise.all(mte_each_unit);
            }
            break;

          default:
          // throw `Something Went wrong with Step: ${flow.step}`
        }
      }
    }


    await t.commit();
    // await t.rollback();
  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    // if (connection) await connection.end();
  }
  return { msg: "Information Successfully" };

};

export const getMachineryToolEquipments = async (req, res) => {
  let finalResult = [], userId;
  try {
    const { appId, tradeId, pagination } = req.body;

    const pageInfo = JSON.parse(pagination);
    const { page, limit } = pageInfo;
    const offset = (page - 1) * limit;

    // throw offset;

    userId = req.userInfo.user_id;
    const result = await TradeWiseToolEquipments.findAndCountAll({
      attributes: ['trade_id', 'tool_id', 'availability', 'required_quantity', 'available_quantity', 'appId', 'userId'],
      where: { appId: appId, trade_id: tradeId },
      include: [
        {
          attributes: ['trade_type', 'trade_id', 'trade_name'],
          model: MasterTradeInfo,
          as: "tradeInfo"
        },
        {
          attributes: ['trade_name', 'trade_id', 'tool_category', 'Sub_category', 'Item_name', 'Specification', 'Quantity', 'Qty_type', 'Per_unit'],
          model: MasterTradeToolEquipment,
          as: "toolInfo"
        },
      ],
      offset,
      limit
    });

    const final = result.rows.map((row, index) => ({
      slno: offset + index + 1, // numbering continues with pagination
      ...row.toJSON(),
    }));

    finalResult = {
      start_from: offset,
      totalRecords: result.count, // total rows matching `where` (ignores limit/offset)
      totalPages: Math.ceil(result.count / limit),
      currentPage: page,
      mte: final,
    };
  } catch (err) {
    throw err;
  }
  return finalResult;
};

export const getTradewiseWorkShop = async (req, res) => {
  let finalResult = [], userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;
    finalResult = await TradewiseWorkshop.findAll({
      where: { appId: appId }, include: [
        {
          model: MasterTradeInfo,
          as: "tradeInfo"
        }
      ]
    });



  } catch (err) {
    throw err;
  }
  return finalResult;
};

export const getITLabSpecifications = async (req, res) => {
  let finalResult = [], userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;

    const computers = await ItLabParticulars.findAll({ where: { appId: appId, particular: cons.iti_lab_particulars_keys.DESKTOP_COMPUTER_WITH_LATEST_CONFIGURATION.key } });
    const equipments = await ItLabParticulars.findAll({
      where: {
        appId: appId, particular: {
          [Op.notIn]: [cons.iti_lab_particulars_keys.DESKTOP_COMPUTER_WITH_LATEST_CONFIGURATION.key]
        }
      }
    });
    finalResult = { "computers": computers, "equipments": equipments, }
  } catch (err) {
    throw err;
  }
  return finalResult;
};


export const getSignageBoards = async (req, res) => {
  let finalResult = [], userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;



    const signage_boards = await SignageBoardsParticulars.findAll({
      attributes: ["particular", "document", "appId", "userId", "status", "instruction"],
      where: {
        appId: appId, userId: userId
      }
    });
    // throw particular_1;

    finalResult = { signage_boards: signage_boards }
  } catch (err) {
    throw err;
  }
  return finalResult;
};

export const getAmenities = async (req, res) => {
  let finalResult = [], userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;



    const particulars_1 = await AmenitiesParticulars.findAll({
      attributes: ['status', 'particular', 'required_area', 'available_area', 'AreaUnit', 'appId', 'userId'],
      where: {
        appId: appId, userId: userId, particular: {
          [Op.in]: [cons.AMNT.FIRST_AID_ROOM, cons.AMNT.LIBRARY_AND_READING_ROOM]
        }
      }
    });
    // throw particular_1;

    const particulars_2 = await AmenitiesParticulars.findAll({
      attributes: ['status', 'particular', 'instruction', 'document', 'appId', 'userId'],
      where: {
        appId: appId, userId: userId, particular: {
          [Op.notIn]: [cons.AMNT.LIBRARY_AND_READING_ROOM, cons.AMNT.FIRST_AID_ROOM]
        }
      }
    });
    finalResult = { particulars_1: particulars_1, particulars_2: particulars_2, }
  } catch (err) {
    throw err;
  }
  return finalResult;
};


export const getDocuments = async (req, res) => {
  let finalResult = [], userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;
    const list_1 = await GeoTaggedPhotoOfMTE.findAll({
      include: [
        {
          model: MasterTradeInfo,
          as: 'tradeInfo'
        }
      ],
      where: { appId: appId }
    });
    const list_2 = await GstInvoicesMachineryPayment.findAll({
      include: [
        {
          attributes: ['trade_name'],
          model: MasterTradeInfo,
          as: 'tradeInfo'
        }
      ], where: { appId: appId }
    });
    finalResult = { mte_photos_per_unit: list_1, gst_invoices: list_2, }
  } catch (err) {
    throw err;
  }
  return finalResult;
};
export const getTradewiseClassRooms = async (req, res) => {
  let finalResult = [], userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;

    finalResult = await TradewiseClassRoom.findAll({
      where: { appId: appId }, include: [
        {
          model: MasterTradeInfo,
          as: "tradeInfo"
        }
      ]
    });



  } catch (err) {
    throw err;
  }
  return finalResult;
};
export const setTradewiseWorkShop = async (values, authUser, appId) => {
  const t = await sequelize.transaction();
  try {
    for (const key in values) {
      const splited = key.split('>');
      const type = splited[0];
      const tradeId = splited[1];
      const workshopName = splited[2];

      const where = {
        appId: appId,
        tradeid_workshop_appid: tradeId,
        workshop: workshopName,
      };

      const found = await TradewiseWorkshop.findOne({ where, transaction: t });
      const now = cons?.currentDate || new Date();

      if (found) {
        const updatePayload = { updateDate: now, submitDate: now };
        if (type === 'area') updatePayload.area = values[key];
        else if (type === 'photo') updatePayload.photo = values[key];

        await found.update(updatePayload, { transaction: t });
      } else {
        // create new record if not exists
        const createPayload = {
          appId: appId,
          userId: authUser?.user_id || authUser,
          workshop: workshopName,
          tradeid_workshop_appid: tradeId,
          submitDate: now,
          updateDate: now,
        };
        if (type === 'area') createPayload.area = values[key];
        else if (type === 'photo') createPayload.photo = values[key];

        await TradewiseWorkshop.create(createPayload, { transaction: t });
      }
    }

    // Update civil infra sub-step status to FILLED
    const stepInfo = await AppFormSubCivilInfra.findOne({ where: { appId: appId, step: CIC.TRADEWISE_WORKSHOP }, transaction: t });
    if (stepInfo) {
      await stepInfo.update({ status: cons?.SL?.FILLED || cons.FILLED, submitDate: cons?.currentDate || new Date(), updateDate: cons?.currentDate || new Date() }, { transaction: t });
      // activate next sub steps
      // await setActiveCivilInfraSubSteps(appId, stepInfo.nextStep);
    }

    await t.commit();
    return {};
  } catch (err) {
    await t.rollback();
    console.error('Error in setTradewiseWorkShop:', err);
    return {};
  }
};

export const saveTradewiseWorkShop = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    // connection = await mysql.createConnection(affDbConfig);
    const { data, appId } = req.body;
    const { email } = req.user;
    const userId = req.userInfo.user_id;
    const jsonData = JSON.parse(data);
    // throw jsonData;

    for (const [index, item] of jsonData.tradewise_workshop.entries()) {
      const document = req.files.find(f => f.fieldname === `tradewise_workshop[${index}].document`);
      if (!document) {
        throw new Error(`File missing for ${item.tradewise_workshop} at index ${index}`);
      }
      const toUpdate = {
        userId: userId,
        appId: appId,
        document: document.filename,
        available_area: item.available_area
      };
      await TradewiseWorkshop.update(toUpdate, { where: { appId: appId, trade_id: item.trade_id, workshop: item.workshop }, transaction: t })
    }
    await AppFormSubCivilInfra.update({ status: cons.SL.FILLED }, { where: { appId: appId, step: cons.CIC.TRADEWISE_WORKSHOP, userId: userId }, transaction: t });
    await AppFormSubCivilInfra.update({ stepStatus: cons.SL.ACTIVE }, { where: { appId: appId, step: cons.CIC.TRADEWISE_CLASSROOMS, userId: userId }, transaction: t });

    await t.commit();
    return true
  } catch (err) {
    await t.rollback();
    console.error('Error in setTradewiseWorkShop:', err);
    return err;
  }
};


export const saveItLabSpecifications = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    // connection = await mysql.createConnection(affDbConfig);
    const { data, appId } = req.body;
    const { email } = req.user;
    const userId = req.userInfo.user_id;
    const jsonData = JSON.parse(data);
    // throw jsonData;

    for (const [index, item] of jsonData.computers.entries()) {
      const { particular, available_qty } = item
      const toUpdate = { particular: particular, available_qty: available_qty };
      await ItLabParticulars.update(toUpdate, { where: { userId: userId, appId: appId, particular: particular, }, transaction: t })
    }

    for (const [index, item] of jsonData.equipments.entries()) {
      const { particular, availability } = item
      const toUpdate = { particular: particular, availability: availability };
      await ItLabParticulars.update(toUpdate, { where: { userId: userId, appId: appId, particular: particular, }, transaction: t })
    }


    await SubFlowMachineryToolEquipment.update({ status: cons.SL.FILLED }, { where: { appId: appId, step: cons.CIK.SPECIFICATIONS_OF_IT_LAB, userId: userId }, transaction: t });
    await SubFlowMachineryToolEquipment.update({ stepStatus: cons.SL.ACTIVE }, { where: { appId: appId, step: cons.CIK.TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS, userId: userId }, transaction: t });

    await t.commit();
    return true
  } catch (err) {
    await t.rollback();
    console.error('Error in setTradewiseWorkShop:', err);
    return err;
  }
};

export const saveTradewiseClassRooms = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    // connection = await mysql.createConnection(affDbConfig);
    const { data, appId } = req.body;
    const { email } = req.user;
    const userId = req.userInfo.user_id;
    const jsonData = JSON.parse(data);
    // throw jsonData;

    for (const [index, item] of jsonData.tradewise_classrooms.entries()) {
      const document = req.files.find(f => f.fieldname === `tradewise_classrooms[${index}].document`);
      if (!document) {
        throw new Error(`File missing for ${item.tradewise_classrooms} at index ${index}`);
      }
      const toUpdate = {
        userId: userId,
        appId: appId,
        document: document.filename,
        available_area: item.available_area
      };

      await TradewiseClassRoom.update(toUpdate, { where: { appId: appId, trade_id: item.trade_id, clasroom: item.clasroom }, transaction: t })
    }
    await AppFormSubCivilInfra.update({ status: cons.SL.FILLED }, { where: { appId: appId, step: cons.CIC.TRADEWISE_CLASSROOMS, userId: userId }, transaction: t });
    await AppFormSubCivilInfra.update({ stepStatus: cons.SL.ACTIVE }, { where: { appId: appId, step: cons.CIC.MULTIPURPOSE_HALL, userId: userId }, transaction: t });

    await t.commit();
    return true
  } catch (err) {
    await t.rollback();
    console.error('Error in setTradewiseWorkShop:', err);
    return err;
  }
};





export const getParticulars = async (req, res) => {
  let finalResult = [], userId;
  try {
    const { appId, particular } = req.body;
    userId = req.userInfo.user_id;


    switch (particular) {
      case cons.CIK.MULTIPURPOSE_HALL:
      case cons.CIK.IT_LAB:
      case cons.CIK.LIBRARY:
      case cons.CIK.PLACEMENT_AND_COUNSELLING_ROOM:
        {
          finalResult = await CommonCivilInfrastructure.findAll({
            limit: 1,
            where: { particular: particular, appId: appId, category: cons.common_infra_category.CIVIL }
          })
        }
        break;

      case cons.CIC.ADMINISTRATIVE_AREA:
        {
          finalResult = await CommonCivilInfrastructure.findAll({
            where: {
              particular: {
                [Op.in]: [cons.CIK.PRINCIPAL_ROOM,
                cons.CIK.RECEPTION_CUM_WAITING_LOBBY,
                cons.CIK.STAFF_ROOM,
                cons.CIK.ADMINISTRATIVE_HALL_SECTION]
              }, appId: appId, category: cons.common_infra_category.CIVIL
            }
          })
        }
        break;
      default:
        throw "Invalid Particular"
        break;
    }


  } catch (err) {
    throw err;
  }
  return finalResult;
};


export const saveParticularDetails = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    // connection = await mysql.createConnection(affDbConfig);
    const { data, appId, particular } = req.body;
    const { email } = req.user;
    const userId = req.userInfo.user_id;
    const jsonData = JSON.parse(data);
    // throw particular;


    switch (particular) {
      case cons.CIK.MULTIPURPOSE_HALL:
        {
          for (const [index, item] of jsonData.multipurposehall.entries()) {
            const document = req.files.find(f => f.fieldname === `multipurposehall[${index}].document`);
            if (!document) {
              throw new Error(`File missing for ${item.tradewise_classrooms} at index ${index}`);
            }
            const toUpdate = {
              userId: userId,
              appId: appId,
              document: document.filename,
              available_area: item.available_area,
              submit_date: cons.currentDate
            };
            await CommonCivilInfrastructure.update(toUpdate, { where: { category: cons.common_infra_category.CIVIL, particular: particular, appId: appId, }, transaction: t })
          }
          await AppFormSubCivilInfra.update({ status: cons.SL.FILLED }, { where: { appId: appId, step: cons.CIC.MULTIPURPOSE_HALL, userId: userId }, transaction: t });
          await AppFormSubCivilInfra.update({ stepStatus: cons.SL.ACTIVE }, { where: { appId: appId, step: cons.CIC.IT_LAB, userId: userId }, transaction: t });
        }
        break;
      case cons.CIK.IT_LAB:
        {
          for (const [index, item] of jsonData.it_lab.entries()) {
            const document = req.files.find(f => f.fieldname === `it_lab[${index}].document`);
            if (!document) {
              throw new Error(`File missing for ${item.it_lab} at index ${index}`);
            }
            const toUpdate = {
              userId: userId,
              appId: appId,
              document: document.filename,
              available_area: item.available_area,
              submit_date: cons.currentDate
            };
            await CommonCivilInfrastructure.update(toUpdate, { where: { category: cons.common_infra_category.CIVIL, particular: particular, appId: appId, }, transaction: t })
          }
          await AppFormSubCivilInfra.update({ status: cons.SL.FILLED }, { where: { appId: appId, step: cons.CIC.IT_LAB, userId: userId }, transaction: t });
          await AppFormSubCivilInfra.update({ stepStatus: cons.SL.ACTIVE }, { where: { appId: appId, step: cons.CIC.LIBRARY, userId: userId }, transaction: t });
        }
        break;
      case cons.CIK.LIBRARY:
        {
          for (const [index, item] of jsonData.library.entries()) {
            const document = req.files.find(f => f.fieldname === `library[${index}].document`);
            if (!document) {
              throw new Error(`File missing for ${item.library} at index ${index}`);
            }
            const toUpdate = {
              userId: userId,
              appId: appId,
              document: document.filename,
              available_area: item.available_area,
              submit_date: cons.currentDate
            };
            await CommonCivilInfrastructure.update(toUpdate, { where: { category: cons.common_infra_category.CIVIL, particular: particular, appId: appId, }, transaction: t })
          }
          await AppFormSubCivilInfra.update({ status: cons.SL.FILLED }, { where: { appId: appId, step: cons.CIC.LIBRARY, userId: userId }, transaction: t });
          await AppFormSubCivilInfra.update({ stepStatus: cons.SL.ACTIVE }, { where: { appId: appId, step: cons.CIC.PLACEMENT_AND_COUNSELLING_ROOM, userId: userId }, transaction: t });
        }
        break;
      case cons.CIK.PLACEMENT_AND_COUNSELLING_ROOM:
        {
          for (const [index, item] of jsonData.placement_n_counselling_room.entries()) {
            const document = req.files.find(f => f.fieldname === `placement_n_counselling_room[${index}].document`);
            if (!document) {
              throw new Error(`File missing for ${item.placement_n_counselling_room} at index ${index}`);
            }
            const toUpdate = {
              userId: userId,
              appId: appId,
              document: document.filename,
              available_area: item.available_area,
              submit_date: cons.currentDate
            };
            await CommonCivilInfrastructure.update(toUpdate, { where: { category: cons.common_infra_category.CIVIL, particular: particular, appId: appId, }, transaction: t })
          }
          await AppFormSubCivilInfra.update({ status: cons.SL.FILLED }, { where: { appId: appId, step: cons.CIC.PLACEMENT_AND_COUNSELLING_ROOM, userId: userId }, transaction: t });
          await AppFormSubCivilInfra.update({ stepStatus: cons.SL.ACTIVE }, { where: { appId: appId, step: cons.CIC.ADMINISTRATIVE_AREA, userId: userId }, transaction: t });
        }
        break;

      case cons.CIC.ADMINISTRATIVE_AREA:
        {
          for (const [index, item] of jsonData.administrative_areas.entries()) {
            const document = req.files.find(f => f.fieldname === `administrative_areas[${index}].document`);
            if (!document) {
              throw new Error(`File missing for ${item.placement_n_counselling_room} at index ${index}`);
            }
            const { particular, available_area } = item;
            switch (particular) {
              case cons.CIK.PRINCIPAL_ROOM:
              case cons.CIK.RECEPTION_CUM_WAITING_LOBBY:
              case cons.CIK.STAFF_ROOM:
              case cons.CIK.ADMINISTRATIVE_HALL_SECTION:
                const toUpdate = {
                  userId: userId,
                  appId: appId,
                  document: document.filename,
                  available_area: available_area,
                  submit_date: cons.currentDate
                };
                await CommonCivilInfrastructure.update(toUpdate, { where: { category: cons.common_infra_category.CIVIL, particular: particular, appId: appId, }, transaction: t })
                break;
              default:
                throw "Invalide Particular";
                break;
            }
          }
          await AppFormSubCivilInfra.update({ status: cons.SL.FILLED }, { where: { appId: appId, step: cons.CIC.ADMINISTRATIVE_AREA, userId: userId }, transaction: t });
          await FormFlowStageII.update({ status: cons.SL.FILLED }, { where: { appId, step: cons.CIVIL_INFRASTRUCTURE_DETAIL }, transaction: t, });
          await FormFlowStageII.update({ stepStatus: cons.SL.ACTIVE }, { where: { appId, step: cons.AMENITIES_AREA }, transaction: t, });
        }
        break;
      default:
        throw "Invalid Particular"
        break;
    }

    await t.commit();
  } catch (err) {
    await t.rollback();
    console.error('Error in setTradewiseWorkShop:', err);
    throw err;
  }
  return true


};



export const saveMachineToolEquipmentQty = async (req, res) => {
  let result, trade_id_global;
  const t = await sequelize.transaction();
  try {
    // connection = await mysql.createConnection(affDbConfig);
    const { data, appId, trade_id } = req.body;
    const { email } = req.user;
    const userId = req.userInfo.user_id;
    const jsonData = JSON.parse(data);
    // throw jsonData;
    const { mte } = jsonData;

    // throw trade_id;
    // throw mte
    let updates = [];
    for (const [index, item] of mte.entries()) {
      const { tool_id, available_quantity, availability } = item;

      if (availability == 'yes') {
        const toUpdate = { availability: availability, available_quantity: available_quantity, submit_date: cons.currentDate, status: cons.SL.FILLED };
        updates.push(TradeWiseToolEquipments.update(toUpdate, { where: { userId: userId, appId: appId, trade_id: trade_id, tool_id: tool_id }, transaction: t }));
      }
      else if (availability == 'no') {
        const toUpdate = { availability: availability, available_quantity: 0, submit_date: cons.currentDate, status: cons.SL.FILLED };
        updates.push(TradeWiseToolEquipments.update(toUpdate, { where: { userId: userId, appId: appId, trade_id: trade_id, tool_id: tool_id }, transaction: t }));
      }
      else {
        throw "Invalid Availability";
      }

    }

    // Wait for all updates to complete
    await Promise.all(updates);
    // throw trade_id_global;
    const count_not_filled = await TradeWiseToolEquipments.count({ where: { userId: userId, appId: appId, trade_id: trade_id, status: cons.SL.NOT_FILLED } });
    const conunt_filled = await TradeWiseToolEquipments.count({ where: { userId: userId, appId: appId, trade_id: trade_id, status: cons.SL.FILLED } });


    if (count_not_filled === 0) {
      const found = await TradeWideMachineToolEquipmentStatus.findOne({ where: { appId: appId, tradeId: trade_id, userId: userId }, transaction: t });
      found.update({ status: cons.SL.FILLED, submit_date: cons.currentDate });
      // throw found;
      const { tradeId, stepNo, nextStep } = found;

      if (nextStep === 0) {
        // Filling Is Completed
        await SubFlowMachineryToolEquipment.update({ status: cons.SL.FILLED }, { where: { appId: appId, step: cons.CIK.TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS, userId: userId }, transaction: t });
        await FormFlowStageII.update({ status: cons.SL.FILLED }, { where: { appId, step: cons.TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS }, transaction: t, });
        await FormFlowStageII.update({ stepStatus: cons.SL.ACTIVE }, { where: { appId, step: cons.DOCUMENT_UPLOADS }, transaction: t, });
        // throw nextStep;
        const appFlow = await AppFlow.findOne({ where: { appId, step: cons.STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS }, transaction: t, });
        await appFlow.update({ stepStatus: cons.SL.COMPLETED, status: cons.STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS_COMPLETED, completedDate: cons.currentDate });
        const app2 = await AppFlow.findOne({ where: { appId, step: cons.STAGE_II_DOCUMENT_UPLAOD }, transaction: t, });
        await app2.update({ stepStatus: cons.SL.ACTIVE });



      }
      else {
        await TradeWideMachineToolEquipmentStatus.update({ stepStatus: cons.SL.ACTIVE }, { where: { appId: appId, userId: userId, stepNo: nextStep }, transaction: t });
      }
    }
    result = { count_not_filled: count_not_filled, conunt_filled: conunt_filled };
    await t.commit();
  } catch (err) {
    await t.rollback();
    throw err;
  }
  return result;
};