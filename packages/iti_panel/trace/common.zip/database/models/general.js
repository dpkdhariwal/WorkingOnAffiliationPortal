/* eslint-disable no-undef */
import jwt from "jsonwebtoken";
import fs from "fs";
import mysql from "mysql2/promise";
import { pKeyPath } from "../../common/common.js";
import { masterConfig, eMsg, dbConfig, affDbConfig } from "../db.js";

const privateKey = fs.readFileSync(pKeyPath, "utf8");
import * as cons from "../../constant/constants.js";
import { throws } from "assert";

import dayjs from "dayjs";
import utc from "dayjs/plugin/utc.js";
import timezone from "dayjs/plugin/timezone.js";


import { EntEntityDetails, EntityAddress } from "../Sequelize/index.js";
import State from "../Sequelize/State.js";
import District from "../Sequelize/districts.js";
import VilDistrictSubDistrict from "../Sequelize/villages_district_sub_districts.js";
import MasterAffiliationCategory from "../Sequelize/master_affiliation_categories.js";
import MasterAffiliationSubCategory from "../Sequelize/master_affiliation_sub_categories.js";
import EntOtherITI from "../Sequelize/EntOtherITI.js";
// import ProposedProposedInstituteDetails from "../Sequelize/ProposedProposedInstituteDetails.js";
import { ProposedInstituteAddressesDetails } from "../Sequelize/index.js";
import ProposedProposedInstituteDetails from "../Sequelize/ProposedProposedInstituteDetails.js";
import TradesNewInstTrades from "../Sequelize/tradesNewInstTrades.js";
import LandInstDetail from "../Sequelize/LandInstDetail.js";
import LandOwnedLand from "../Sequelize/LandOwnedLand.js";
import LandLeasedLand from "../Sequelize/LandLeasedLand.js";
import MasterTradeInfo from "../Sequelize/tradeAreaInfo.js";
import AppFlow from "../Sequelize/AppFlow.js";




dayjs.extend(utc);
dayjs.extend(timezone);
let updateDate, currentDate;
export const formattedDate = dayjs().tz("Asia/Kolkata").toISOString();
export const submitDate = updateDate = currentDate = dayjs().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");


export const getAppFlowStepInfoByStep = async (req, res) => {
  let connection, userId, finalResult;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {
    connection = await mysql.createConnection(affDbConfig);

    const { step, appId } = req.body;
    userId = req.userInfo.user_id;

    await connection.beginTransaction();

    let stmt1 = await connection.prepare('SELECT * FROM `' + cons.APP_FLOW + '` WHERE step=? and appId = ?');
    let [result] = await stmt1.execute([step, appId]);
    if (result.length > 0) {
      finalResult = result[0]
    }
    else {
      throw new Error("Form FLow Step Not Found");
    }

    // Commit the transaction
    await connection.commit();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }

  return finalResult;



  // const db = await initDB();
  // try {
  //   const tx = db.transaction([cons.APP_FORM_FLOW_STAGE_I], 'readwrite');
  //   const list = tx.objectStore(cons.APP_FORM_FLOW_STAGE_I);
  //   const flow = await list.index('appId').getAll(appId);
  //   console.log(flow);
  //   flow.sort((a, b) => a.stepNo - b.stepNo);
  //   const finalList = await Promise.all(flow.map(async (item) => {
  //     switch (item.step) {
  //       case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
  //         // check possession_of_land
  //         console.log(item.step);
  //         return item;
  //       default:
  //         return item;
  //     }
  //   }));
  //   console.log(finalList);
  //   await tx.done;
  //   return finalList;
  // } catch (error) {
  //   return []
  // }
};

export const setNewStatusOfAppByStep = async (req, res) => {
  let connection, userId, finalResult;

  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {
    connection = await mysql.createConnection(affDbConfig);

    const { step, newStatus, appId } = req.body;
    userId = req.userInfo.user_id;



    await connection.beginTransaction();

    let stmt1 = await connection.prepare('SELECT * FROM `' + cons.APP_FLOW + '` WHERE step=? and appId = ?');
    let [stmt1_result] = await stmt1.execute([step, appId]);
    if (stmt1_result.length > 0) {
      let stmt_upd = await connection.prepare('UPDATE `' + cons.APP_FLOW + '` SET `status`=?, `startedDate`=? WHERE step=? and appId = ?;');
      await stmt_upd.execute([newStatus, currentDate, step, appId]);
    }
    else {
      throw new Error("Form FLow Step Not Found");
    }

    // Commit the transaction
    await connection.commit();

    // Commit rollback
    // await connection.rollback();

    connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return { status: true };


  // const db = await initDB();
  // try {
  //   const tx = db.transaction([cons.APP_FORM_FLOW_STAGE_I], 'readwrite');
  //   const list = tx.objectStore(cons.APP_FORM_FLOW_STAGE_I);
  //   const flow = await list.index('appId').getAll(appId);
  //   console.log(flow);
  //   flow.sort((a, b) => a.stepNo - b.stepNo);
  //   const finalList = await Promise.all(flow.map(async (item) => {
  //     switch (item.step) {
  //       case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
  //         // check possession_of_land
  //         console.log(item.step);
  //         return item;
  //       default:
  //         return item;
  //     }
  //   }));
  //   console.log(finalList);
  //   await tx.done;
  //   return finalList;
  // } catch (error) {
  //   return []
  // }
};

export const getAssessmentStatus = async (req, res) => {
  let connection, userId, finalResult;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {

    connection = await mysql.createConnection(affDbConfig);


    const { appId } = req.body;
    userId = req.userInfo.user_id;



    await connection.beginTransaction();

    let stmt1 = await connection.prepare('SELECT * FROM `' + cons.TBL_ASSESSMENTS_STATUS + '` WHERE appId = ?');
    let [result] = await stmt1.execute([appId]);
    if (result.length > 0) {
      finalResult = result[0]
    }
    else {
      throw new Error("Form FLow Step Not Found");
    }

    // Commit the transaction
    await connection.commit();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }

  return finalResult;



  // const db = await initDB();
  // try {
  //   const tx = db.transaction([cons.APP_FORM_FLOW_STAGE_I], 'readwrite');
  //   const list = tx.objectStore(cons.APP_FORM_FLOW_STAGE_I);
  //   const flow = await list.index('appId').getAll(appId);
  //   console.log(flow);
  //   flow.sort((a, b) => a.stepNo - b.stepNo);
  //   const finalList = await Promise.all(flow.map(async (item) => {
  //     switch (item.step) {
  //       case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
  //         // check possession_of_land
  //         console.log(item.step);
  //         return item;
  //       default:
  //         return item;
  //     }
  //   }));
  //   console.log(finalList);
  //   await tx.done;
  //   return finalList;
  // } catch (error) {
  //   return []
  // }
};



export const getEntityDetails = async (req, res) => {
  let finalResult = {};
  try {
    const { appId } = req.body;
    const userId = req.userInfo.user_id;

    const entity = await EntEntityDetails.findOne({
      where: { appId: appId },
      include: [
        {
          model: EntityAddress,
          as: "ent_address",
          include: [
            {
              model: State,
              as: "state_detail", // nested include
              attributes: ['stateCode',
                'stateNameEnglish',
                'stateNameLocal',
                'shortName',
                'stateOrUt']
            },
            {
              model: District,
              as: "district_detail", // nested include
              attributes: ['districtCode',
                'districtNameEnglish',
                'districtNameLocal',
                'districtNameshort',
                'stateCode']
            },
            {
              model: VilDistrictSubDistrict,
              as: "sub_district", // nested include,
              attributes: ['subdistrictCode',
                'subdistrictNameEnglish',
                'districtCode']
            },
            {
              model: VilDistrictSubDistrict,
              as: "village", // nested include
              attributes: ['villageCode',
                'villageNameEnglish',
                'districtCode']
            },
          ],
        },
        {
          model: MasterAffiliationCategory,
          as: "category_info", // nested include
        },
        {
          model: MasterAffiliationSubCategory,
          as: "sub_cat_info", // nested include
        },
      ],
    });

    const otherITIs = await EntOtherITI.findAll({
      include: [
        {
          model: State,
          as: "state_detail",
          attributes: ['stateCode',
            'stateNameEnglish',
            'stateNameLocal',
            'shortName',
            'stateOrUt']

        },
        {
          model: District,
          as: "district_detail",
          attributes: ['districtCode',
            'districtNameEnglish',
            'districtNameLocal',
            'districtNameshort',
            'stateCode']
        },
      ], where: { appId: appId }
    });

    finalResult = { ...finalResult, ...{ entity }, ...{ otherITIs }, }

  } catch (err) {
    throw err;
  }
  return finalResult;
};
export const getProposedInstDetails = async (req, res) => {
  let finalResult = {};
  try {
    const { appId } = req.body;
    const userId = req.userInfo.user_id;

    const pInstDetail = await ProposedProposedInstituteDetails.findOne({ where: { appId: appId } });
    const comp_postal_addres_of_inst = await ProposedInstituteAddressesDetails.findOne({
      where: { appId: appId },
      include: [
        {
          model: State,
          as: "state_detail", // nested include
          attributes: ['stateCode',
            'stateNameEnglish',
            'stateNameLocal',
            'shortName',
            'stateOrUt']
        },
        {
          model: District,
          as: "district_detail", // nested include
          attributes: ['districtCode',
            'districtNameEnglish',
            'districtNameLocal',
            'districtNameshort',
            'stateCode']
        },
        {
          model: VilDistrictSubDistrict,
          as: "sub_district", // nested include,
          attributes: ['subdistrictCode',
            'subdistrictNameEnglish',
            'districtCode']
        },
        {
          model: VilDistrictSubDistrict,
          as: "village", // nested include
          attributes: ['villageCode',
            'villageNameEnglish',
            'districtCode']
        },
      ],
    });
    finalResult = { ...finalResult, ...{ pInstDetail }, ...{ comp_postal_addres_of_inst } }
  } catch (err) {
    throw err;
  }
  return finalResult;
};



export const getDetails = async (req, res) => {
  // const db = await initDB();
  let connection, userId, finalResult, entity_details, entity_address, other_iti, proposed_insti_details, proposed_insti_addresses, new_insti_trade_list;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {
    connection = await mysql.createConnection(affDbConfig);

    const { appId } = req.body;
    userId = req.userInfo.user_id;



    await connection.beginTransaction();
    let stmt1 = await connection.prepare('SELECT * FROM `' + cons.TBL_ASSESSMENTS_STATUS + '` WHERE appId = ?');
    let [result] = await stmt1.execute([appId]);
    if (result.length > 0) {
      finalResult = result[0]
    }
    else {
      throw new Error("Form FLow Step Not Found");
    }


    let stmt2 = await connection.prepare('SELECT * FROM `' + cons.ENTITY_DETAILS_VIEW + '` WHERE appId = ?');
    let [stmt2_result] = await stmt2.execute([appId]);
    entity_details = stmt2_result[0];


    let stmt3 = await connection.prepare('SELECT * FROM `' + cons.ENTITY_ADDRESS + '` WHERE appId = ?');
    let [stmt3_result] = await stmt3.execute([appId]);
    entity_address = stmt3_result[0];


    let stmt4 = await connection.prepare('SELECT * FROM `' + cons.OTHER_ITI + '` WHERE appId = ?');
    let [stmt4_result] = await stmt4.execute([appId]);
    other_iti = stmt4_result;

    let stmt5 = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_DETAILS + '` WHERE appId = ?');
    let [stmt5_result] = await stmt5.execute([appId]);
    proposed_insti_details = stmt5_result[0];


    let stmt6 = await connection.prepare('SELECT * FROM `' + cons.PROPOSED_INSTI_ADDRESSES + '` WHERE appId = ?');
    let [stmt6_result] = await stmt6.execute([appId]);
    proposed_insti_addresses = stmt6_result[0];


    let stmt7 = await connection.prepare('SELECT t1.*,  t2.trade_name FROM `' + cons.NEW_INSTI_TRADE_LIST + '` as t1 JOIN master_trade_info as t2 on t2.trade_id=t1.tradeId WHERE appId = ?');



    let [stmt7_result] = await stmt7.execute([appId]);
    new_insti_trade_list = stmt7_result;



    await connection.commit();

  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }

  return { entity_details, entity_address, other_iti, proposed_insti_details, proposed_insti_addresses, new_insti_trade_list };

};



export const getAppFlowByAppId = async (req, res) => {
  // const db = await initDB();
  let app_flow, connection, userId, tbl_assessments_status, aStatus, assessmentFlowStageI, app_assessment_flow_stage_i;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();

  try {
    connection = await mysql.createConnection(affDbConfig);

    const { appId } = req.body;
    userId = req.userInfo.user_id;


    await connection.beginTransaction();


    // const db = await initDB();
    // let app_flow = await db.getAllFromIndex(cons.APP_FLOW, "appId", appId);

    let stmt = await connection.prepare('SELECT * FROM `' + cons.APP_FLOW + '` WHERE appId = ? ORDER BY stepNo ASC');
    let [result] = await stmt.execute([appId]);
    if (result.length === 0) {
      throw new Error("App Flow Records Not Found");
    }

    app_flow = result;





    // let app_assessment_flow_stage_i = await db.getAllFromIndex(cons.APP_ASSESSMENT_FLOW_STAGE_I, "appId", appId);
    let stmt2 = await connection.prepare('SELECT * FROM `' + cons.APP_ASSESSMENT_FLOW_STAGE_I + '` WHERE appId = ?');
    let [result2] = await stmt2.execute([appId]);
    app_assessment_flow_stage_i = result2;

    // let tbl_assessments_status = await db.getAllFromIndex(cons.TBL_ASSESSMENTS_STATUS, "appId", appId);
    let stmt3 = await connection.prepare('SELECT * FROM `' + cons.TBL_ASSESSMENTS_STATUS + '` WHERE appId = ?');
    let [result3] = await stmt3.execute([appId]);
    tbl_assessments_status = result3;

    // process each item individually
    app_flow = await Promise.all(
      app_flow.map(async (item) => {
        switch (item.step) {
          case cons.STAGE_I_FORM_FILLING:
            console.log(item);
            break;
          case cons.STAGE_I_FEE:
            console.log(item);
            break;
          case cons.STAGE_I_DOCUMENT_UPLAOD:
            console.log(item);
            break;
          case cons.STAGE_I_SUBMIT:
            console.log(item);
            break;
          case cons.STAGE_I__ASSESSMENT:
            {
              // let aStatus = await db.getFromIndex(C.TBL_ASSESSMENTS_STATUS, "appId", appId);
              let stmt = await connection.prepare('SELECT * FROM `' + cons.TBL_ASSESSMENTS_STATUS + '` WHERE appId = ?');
              let [result] = await stmt.execute([appId]);
              aStatus = result[0];

              // let assessmentFlowStageI = await db.getAllFromIndex(C.APP_ASSESSMENT_FLOW_STAGE_I, "appId", appId);
              let stmt2 = await connection.prepare('SELECT * FROM `' + cons.APP_ASSESSMENT_FLOW_STAGE_I + '` WHERE appId = ?');
              let [result2] = await stmt2.execute([appId]);
              assessmentFlowStageI = result2;

              item = { ...item, aStatus, assessmentFlowStageI }
            }
            break;
          case cons.NOC_ISSUANCE:
            console.log(item);
            break;
          case cons.STAGE_II_FORM_FILLING:
            console.log(item);
            break;
          case cons.STAGE_II_FEE:
            console.log(item);
            break;
          case cons.STAGE_II_MACHINE_EQUIPEMENT_TOOL_DETAILS:
            console.log(item);
            break;
          case cons.STAGE_II_DOCUMENT_UPLAOD:
            console.log(item);
            break;
          case cons.STAGE_II_SUBMIT:
            console.log(item);
            break;
          case cons.STAGE_II__ASSESSMENT:
            {
              // let aStatus = await db.getFromIndex(C.TBL_ASSESSMENTS_STATUS, "appId", appId);
              let stmt = await connection.prepare('SELECT * FROM `' + cons.TBL_ASSESSMENTS_STATUS + '` WHERE appId = ? and stage=?');
              let [result] = await stmt.execute([appId, 'STAGE_II']);
              aStatus = result[0];

              // let assessmentFlowStageI = await db.getAllFromIndex(C.APP_ASSESSMENT_FLOW_STAGE_I, "appId", appId);
              let stmt2 = await connection.prepare('SELECT * FROM `' + cons.APP_ASSESSMENT_FLOW_STAGE_II + '` WHERE appId = ?');
              let [result2] = await stmt2.execute([appId]);
              assessmentFlowStageI = result2;

              item = { ...item, aStatus, assessmentFlowStageI }
            }
            break;
          case cons.STAFF_DETAILS:
            console.log(item);
            break;
          case cons.INSP_SLOT_SELECTION:
            console.log(item);
            break;
          case cons.INSPENCTION:
            console.log(item);
            break;
          default:
            console.log(item);
            break;
        }
        return { ...item, };
      })
    );
    // sort by stepNo before returning
    // app_flow.sort((a, b) => a.stepNo - b.stepNo);


    await connection.commit();


  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }

  return { app_flow, app_assessment_flow_stage_i, tbl_assessments_status };

};


export const getTradeUnitsInfo = async (req, res) => {
  let finalResult = {}, userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;
    // Getting Trade Info 
    const result = await TradesNewInstTrades.findAll({
      where: { appId: appId }, include: [
        {
          model: MasterTradeInfo,
          as: "tradeInfo"
        }
      ]
    });


    finalResult = result

  } catch (err) {
    throw err;
  }
  return finalResult;
};
// export const getTradeUnitsInfo = async (req, res) => {
//   // const db = await initDB();
//   let result, app_flow, connection, userId, tbl_assessments_status, aStatus, assessmentFlowStageI, app_assessment_flow_stage_i;
//   // const pool = mysql.createPool(masterConfig);
//   // connection = await pool.getConnection();

//   try {

//     connection = await mysql.createConnection(affDbConfig);

//     const { appId } = req.body;
//     userId = req.userInfo.user_id;

//     await connection.beginTransaction();

//     let stmt = await connection.prepare('SELECT * FROM `' + cons.TRADE_INFO_VIEW + '` WHERE appId = ?');
//     let [rows] = await stmt.execute([appId]);
//     if (rows.length === 0) {
//       throw new Error("App Flow Records Not Found");
//     }
//     result = rows;

//     await connection.commit();

//   } catch (err) {
//     console.error("Error in checkUser:", err);
//     if (connection) {
//       await connection.rollback();
//     }
//     throw err;
//   } finally {
//     if (connection) await connection.end();
//   }
//   return result;

// };


export const getAppStatus = async (req, res) => {
  let finalResult = {}, userId;
  try {
    const { appId } = req.body;
    userId = req.userInfo.user_id;
    // Getting Trade Info 
    const STAGE_I_FEE = await AppFlow.findOne({
      attributes: ["appId", "step", "status", "startedDate", "stepStatus", "stepTitle", "completedDate"],
      where: { appId: appId, step: cons.STAGE_I_FEE }
    });
    const STAGE_II_FEE = await AppFlow.findOne({
      attributes: ["appId", "step", "status", "startedDate", "stepStatus", "stepTitle", "completedDate"],
      where: { appId: appId, step: cons.STAGE_II_FEE }
    });



    // const PIA_Details = await ProposedInstituteAddressesDetails.findOne({ where: { appId }});
    const PIDetails = await ProposedProposedInstituteDetails.findOne({
      attributes: [
        "name_of_applicant_institute",
        "type_of_institute",
        "under_msti_category",
        "Whether_the_institute_is_exclusive_for_women_trainees"
      ], where: { appId }
    });


    finalResult = {
      stageI_fee_info: STAGE_I_FEE,
      stageII_fee_info: STAGE_II_FEE,
      institute_info: PIDetails
    }

  } catch (err) {
    throw err;
  }
  return finalResult;
};
export const geLanguages = async (req, res) => {
  // const db = await initDB();
  let result, app_flow, connection, userId, tbl_assessments_status, aStatus, assessmentFlowStageI, app_assessment_flow_stage_i;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();

  try {

    connection = await mysql.createConnection(affDbConfig);

    // const { appId } = req.body;
    userId = req.userInfo.user_id;

    // await connection.beginTransaction();

    let stmt = await connection.prepare('SELECT * FROM `' + cons.TBL_LANGUAGES + '` ORDER BY language ASC');
    let [rows] = await stmt.execute();
    if (rows.length === 0) {
      throw new Error("Languages Not Found");
    }
    result = rows;

    // await connection.commit();

  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return result;

};


export const getMasters = async (req, res) => {
  // const db = await initDB();
  let userId, result, connection;

  try {
    connection = await mysql.createConnection(affDbConfig);
    const { master } = req.body;
    userId = req.userInfo.user_id;

    switch (master) {
      case cons.MastersKey.ID_PROOF:
        let stmt = await connection.prepare('SELECT * FROM `' + cons.TBL_MASTER_ID_PROOF_LIST + '` ORDER BY id_proof_name ASC');
        let [rows] = await stmt.execute();
        if (rows.length === 0) {
          throw new Error("ID Proof Master Not Found");
        }
        result = rows;
        break;

      case cons.MastersKey.DESIGNATION:
        let stmt2 = await connection.prepare('SELECT * FROM `' + cons.TBL_MASTER_DESIGNATION + '` ORDER BY designation ASC');
        let [rows2] = await stmt2.execute();
        if (rows2.length === 0) {
          throw new Error("Designation Master Not Found");
        }
        result = rows2;
        break;



      default:
        break;
    }
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return result;
};



export const getApplicationInfo = async (req, res) => {
  let userId, finalResult;
  // const t = await sequelize.transaction();
  try {
    const { step, appId } = req.body;
    userId = req.userInfo.user_id;

    // throw userId;
    const entDetail = await EntEntityDetails.findOne({ where: { appId: appId } });
    const pInfo = await ProposedProposedInstituteDetails.findOne({ where: { appId: appId } });
    const pAddressesInfo = await ProposedInstituteAddressesDetails.findAll({ where: { appId: appId } });
    const trades = await TradesNewInstTrades.findAll({ where: { appId: appId } });
    const landDetail = await LandInstDetail.findAll({
      where: { appId: appId },
      include: [
        {
          model: LandOwnedLand,
          required: false, // left join
        },
        {
          model: LandLeasedLand,
          required: false,
        },
      ],
    });


    finalResult = { ...finalResult, ...{ entDetail, pInfo, pAddressesInfo, trades, landDetail } }

    // await t.commit();
    console.log("Multiple records inserted within transaction ✅");

  } catch (err) {
    // await t.rollback();
    throw err;
  } finally {
    // if (connection) await connection.end();
  }
  return finalResult;
};
