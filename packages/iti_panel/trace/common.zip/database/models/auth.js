/* eslint-disable no-undef */
import jwt from "jsonwebtoken";
import fs from "fs";
import mysql from "mysql2/promise";
import { pKeyPath } from "../../common/common.js";
import { masterConfig, eMsg, dbConfig, affDbConfig } from "../db.js";
import * as cons from "../../constant/constants.js";
import { throws } from "assert";
const privateKey = fs.readFileSync(pKeyPath, "utf8");

import User from "../Sequelize/User.js";
import { sequelize } from '../../config/database.js';


export const checkUser = async (req, res) => {
  let finalResult
  const t = await sequelize.transaction();
  try {

    const { email, password } = req.body;
    const user = await User.findOne({ where: { email: email, password: password }, transaction: t });

    if (!user) {
      throw { ...eMsg, msg: "User Not Found" };
    }

    const token = jwt.sign({ email, password }, privateKey, { expiresIn: "10d", algorithm: "RS256", });

    res.cookie("token", token, {
      httpOnly: true, // not accessible by JS
      secure: false, // only set true if using https
      sameSite: "lax", // or "none" if cross-site with https
      path: "/", // cookie will be sent for all routes
      // maxAge: 24 * 60 * 60 * 1000   // 1 day in ms
      // maxAge: 10 * 1000,  // 10 seconds in ms
      expires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
    });

    user.update({ token: token, last_login_datetime: cons.currentDate })
    await t.commit();
    finalResult = { status: true, msg: "User Successfully Logged In", token, info: { ...user.get({ plain: true }), role: ["applicant"] }, };
  } catch (err) {
    await t.rollback();
    throw err;
  }
  return finalResult;
};

export const getUserByEmail = async (email) => {
  let connection, stmt, results;
  // const pool = mysql.createPool(masterConfig);
  try {
    connection = await mysql.createConnection(affDbConfig);

    // stmt = await connection.prepare("SELECT * FROM `users` WHERE `email` = ?");

    // throw email;
    stmt = await connection.prepare("SELECT t2.state,t2.state_code,  t1.* FROM `users` as t1 JOIN user_profiles as t2 on t2.id=t1.user_id WHERE t1.email=?");

    const [rows] = await stmt.execute([email]);
    await stmt.close();

    if (!rows || rows.length === 0) {
      throw 'Invalide User';
    }
    connection.commit();
    return rows[0]; // return first user
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
};


// export const checkUser = async (req, res) => {
//   const { email = 1111, password = 11 } = req.body;

//   let connection, stmt, results, update;
//   const pool = mysql.createPool(masterConfig);
//   connection = await pool.getConnection();
//   try {
//     console.log(masterConfig);


//     await connection.beginTransaction();

//     // Prepare the SQL statement
//     stmt = await connection.prepare(
//       "SELECT * FROM `users` WHERE `email` = ? AND `password` = ?"
//     );

//     // Execute the prepared statement
//     results = await stmt.execute([email, password]);

//     // Optional: Close the prepared statement
//     await stmt.close();

//     if (!results || results.length === 0) {
//       throw { ...eMsg, msg: "User Not Found" };
//     }

//     const token = jwt.sign({ email, password }, privateKey, {
//       expiresIn: "10d",
//       algorithm: "RS256",
//     });

//     res.cookie("token", token, {
//       httpOnly: true, // not accessible by JS
//       secure: false, // only set true if using https
//       sameSite: "lax", // or "none" if cross-site with https
//       path: "/", // cookie will be sent for all routes
//       // maxAge: 24 * 60 * 60 * 1000   // 1 day in ms
//       // maxAge: 10 * 1000,  // 10 seconds in ms
//       expires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
//     });

//     // Updating token and last login time
//     update = await connection.prepare("UPDATE `users` SET `token`=?, `last_login_datetime`=NOW() WHERE email=?");
//     update = await update.execute([token, email]);

//     // Commit the transaction
//     await connection.commit();

//     // return success with token
//     return { status: true, msg: "User Successfully Logged In", token, info: { ...results[0][0], role: ["applicant"] }, };
//   } catch (err) {
//     console.error("Error in checkUser:", err);
//     if (connection) {
//       await connection.rollback();
//     }
//     throw err;
//   } finally {
//     connection.release();
//   }
// };



