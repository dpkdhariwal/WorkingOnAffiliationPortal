// If using ES modules
import path from "path";
import dotenv from "dotenv";
// Load correct .env file based on NODE_ENV
dotenv.config({
  path: `.env.${process.env.NODE_ENV || "development"}`,
});

import { Sequelize, Op } from 'sequelize';

import { fileURLToPath } from "url";

/* eslint-disable no-undef */
import jwt from "jsonwebtoken";
import fs from "fs";
import mysql from "mysql2/promise";
import { pKeyPath } from "../../common/common.js";
import { masterConfig, eMsg, dbConfig, affDbConfig } from "../db.js";


import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";

const privateKey = fs.readFileSync(pKeyPath, "utf8");
import * as cons from "../../constant/constants.js";
import { throws } from "assert";

import dayjs from "dayjs";
import utc from "dayjs/plugin/utc.js";
import timezone from "dayjs/plugin/timezone.js";
import AssessmentStatus from "../Sequelize/AssessmentStatus.js";
import FormFlowStageI from "../Sequelize/FormFlowStageI.js";
import AppAssessmentFlowStageI from "../Sequelize/AppAssessmentFlowStageI.js";

dayjs.extend(utc);
dayjs.extend(timezone);
let updateDate;
export const formattedDate = dayjs().tz("Asia/Kolkata").toISOString();
export const submitDate = updateDate = dayjs().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
export const randomId = () => crypto.randomUUID();
import { sequelize } from '../../config/database.js';


import { exec } from 'child_process';
import PizZip from 'pizzip';
import Docxtemplater from 'docxtemplater';
import ImageModule from 'docxtemplater-image-module-free';
import { where } from "sequelize";
import ProposedProposedInstituteDetails from "../Sequelize/ProposedProposedInstituteDetails.js";
import { EntityAddress, ProposedInstituteAddressesDetails } from "../Sequelize/index.js";
import TradesNewInstTrades from "../Sequelize/tradesNewInstTrades.js";
import { EntEntityDetails } from "../Sequelize/index.js";
import Handlebars from "handlebars";
import puppeteer from "puppeteer";

import QRCode from "qrcode";
import NocIssuedNocDetail from "../Sequelize/nocIssuedNocDetail.js";
import Noc from "../Sequelize/nocs.js";
import AFlow from "../Sequelize/AppFlow.js";
import DaStageIVerification from "../Sequelize/da_stage_i_verifications.js";
import LandDocuments from "../Sequelize/land_documents.js";
import GET_VERIFICATION_LIST_BY_STEP from "../Sequelize/Assessment/StageI/get_verification_list_by_step.js";
import GetVerifications from "../Sequelize/Assessment/StageI/get_verifications.js";
import LandArea from "../Sequelize/LandArea.js";
import DAStageIVerificationsChecklist from "../Sequelize/DAStageIVerificationsChecklist.js";
import LandOwnedLand from "../Sequelize/LandOwnedLand.js";
import AuthorizedSignatoryDetail from "../Sequelize/AuthorizedSignatoryDetail.js";
import Certificat from "../Sequelize/Certificat.js";
import SecretaryChairpersonPresidentIdInfo from "../Sequelize/SecretaryChairpersonPresidentIdInfo.js";
import AppFlow from "../Sequelize/AppFlow.js";
import Stage1Documents from "../Sequelize/stage1_documents.js";
import State from "../Sequelize/State.js";
import District from "../Sequelize/districts.js";
import VilDistrictSubDistrict from "../Sequelize/villages_district_sub_districts.js";
import MasterTradeInfo from "../Sequelize/tradeAreaInfo.js";
import MasterAffiliationCategory from "../Sequelize/master_affiliation_categories.js";
import MasterAffiliationSubCategory from "../Sequelize/master_affiliation_sub_categories.js";
import InitialLandArea from "../Sequelize/InitialLandArea.js";
import InitialAuthorizedSignatoryDetails from "../Sequelize/initial_authorized_signatory_details.js";
import InitialCertificats from "../Sequelize/initial_certificats.js";
import InitialSecretaryChairpersonPresidentIdInfo from "../Sequelize/initial_secretary_chairperson_president_id_info.js";
import AppAssessmentFlowStageII from "../Sequelize/AppAssessmentFlowStageII.js";
import DAStageIIVerificationsChecklist from "../Sequelize/DAStageIIVerificationsChecklist.js";
import LandInstDetail from "../Sequelize/LandInstDetail.js";
import DaStageIIVerification from "../Sequelize/DaStageIiVerification.js";
import TradewiseWorkshop from "../Sequelize/TradewiseWorkShop.js";
import TradewiseClassRoom from "../Sequelize/TradewiseClassRoom.js";
import BuildingPlan from "../Sequelize/BuildingPlan.js";
import BccDocuments from "../Sequelize/BccDocuments.js";
import BuildingPhotos from "../Sequelize/BuildingPhotos.js";



import * as C from "affserver";
import CommonCivilInfrastructure from "../Sequelize/CommonCivilInfrastructure.js";
import AmenitiesParticulars from "../Sequelize/AmenitiesParticulars .js";
import SignageBoardsParticulars from "../Sequelize/SignageBoardsParticulars .js";
import ElectricityDetails from "../Sequelize/ElectricityDetails.js";
import ElectricityDocuments from "../Sequelize/ElectricityDocuments.js";

// Get current file path
const __filename = fileURLToPath(import.meta.url);

// Get current directory
const __dirname = path.dirname(__filename);

export const setStageIIAssessmentFlow = async (req, res) => {
  let connection, userId;
  const t = await sequelize.transaction();
  try {

    // connection = await mysql.createConnection(affDbConfig);

    const { appId } = req.body;

    userId = req.userInfo.user_id;

    let existAppFlow = await AppFlow.findOne({ where: { appId: appId } });

    if (!existAppFlow) {
      throw "App FLow Not Found";
    }

    let existAsmtFlow = await AppAssessmentFlowStageII.findOne({ where: { appId: appId } });
    if (existAsmtFlow) {
      throw "Assessment FLow Already Exist";
    }

    let exist_asmt = await AssessmentStatus.findOne({ where: { appId: appId, stage: cons.abbreviation.STAGE_II.key } });
    // throw exist_asmt;
    if (exist_asmt) {
      throw "Assessment Already Exist";
    }



    const { assessment_id, assessment_status, pendingAt } = cons.ASSESSMENT_STATUS;


    await AssessmentStatus.create({ appId: appId, assessment_id: assessment_id, assessment_status: assessment_status, pendingAt: pendingAt, stage: cons.abbreviation.STAGE_II.key }, { transaction: t });
    for (const flow of cons.ASSESSMENT_STAGE_II_FLOW_NEW) {
      const { step } = flow
      const asessment_flow_uid = cons.randomIdLong();
      let flowModified = {
        ...flow,
        uniqueID: asessment_flow_uid,
        appId: appId,
        assessment_id: assessment_id,
      }
      await AppAssessmentFlowStageII.create(flowModified, { transaction: t });

      try {
        switch (step) {
          case cons.ST2FC.BUILDING_DETAIL.step:
            {
              const toSave = [];
              const verification = [];
              for (const checkName of cons.asmt_building_details) {
                const v_check_list_uniqueid = cons.randomId();
                toSave.push(DAStageIIVerificationsChecklist.create({ uniqueId: v_check_list_uniqueid, checkName: checkName, step: step, reffNumber: asessment_flow_uid, assessment_id: assessment_id, appId: appId }, { transaction: t }));
                verification.push(DaStageIIVerification.create({
                  uniqueId: cons.randomId(),
                  reffNumber: v_check_list_uniqueid, // uniqueID - da_stage_i_verifications_checklist
                  appId: appId,
                  assessment_id: assessment_id,
                  keyName: checkName,
                  step: step,
                  isDraft: cons.SL.YES,
                  recordType: cons.SL.PRESENT,
                  reff_uniquId: asessment_flow_uid,
                  insertDate: cons.currentDate
                }, { transaction: t }));
              }
              await Promise.all(toSave);
              await Promise.all(verification);
            }
            break;
          case cons.ST2FC.CIVIL_INFRASTRUCTURE_DETAIL.step:
            {
              const toSave = [];
              const verification = [];
              for (const checkName of cons.asmt_civil_infra) {
                switch (checkName) {
                  case cons.DA2_KEYS.WORKSHOPS:
                    {
                      // const list = await TradewiseWorkshop.findAll({ where: { appId: appId } });
                      // for (const obj of list) {
                      //   const data = obj.get({ plain: true });
                      //   const { workshop } = data;
                      //   const v_check_list_uniqueid = cons.randomId();
                      //   await DAStageIIVerificationsChecklist.create({ uniqueId: v_check_list_uniqueid, checkName: workshop, step: step, reffNumber: asessment_flow_uid, assessment_id: assessment_id, appId: appId }, { transaction: t })
                      //   await DaStageIIVerification.create({ uniqueId: cons.randomId(), reffNumber: v_check_list_uniqueid, appId: appId, assessment_id: assessment_id, keyName: workshop, step: step, isDraft: cons.SL.YES, recordType: cons.SL.PRESENT, reff_uniquId: asessment_flow_uid, insertDate: cons.currentDate }, { transaction: t })
                      // }
                      const v_check_list_uniqueid = cons.randomId();
                      await DAStageIIVerificationsChecklist.create({ uniqueId: v_check_list_uniqueid, checkName: cons.DA2_KEYS.WORKSHOPS, step: step, reffNumber: asessment_flow_uid, assessment_id: assessment_id, appId: appId }, { transaction: t })
                      await DaStageIIVerification.create({ uniqueId: cons.randomId(), reffNumber: v_check_list_uniqueid, appId: appId, assessment_id: assessment_id, keyName: cons.DA2_KEYS.WORKSHOPS, step: step, isDraft: cons.SL.YES, recordType: cons.SL.PRESENT, reff_uniquId: asessment_flow_uid, insertDate: cons.currentDate }, { transaction: t })

                    }
                    break;
                  case cons.DA2_KEYS.CLASSROOMS:
                    {
                      // const list = await TradewiseClassRoom.findAll({ where: { appId: appId } });
                      // for (const obj of list) {
                      //   const data = obj.get({ plain: true });
                      //   const { clasroom } = data;
                      //   const v_check_list_uniqueid = cons.randomId();
                      //   await DAStageIIVerificationsChecklist.create({ uniqueId: v_check_list_uniqueid, checkName: clasroom, step: step, reffNumber: asessment_flow_uid, assessment_id: assessment_id, appId: appId }, { transaction: t })
                      //   await DaStageIIVerification.create({ uniqueId: cons.randomId(), reffNumber: v_check_list_uniqueid, appId: appId, assessment_id: assessment_id, keyName: clasroom, step: step, isDraft: cons.SL.YES, recordType: cons.SL.PRESENT, reff_uniquId: asessment_flow_uid, insertDate: cons.currentDate }, { transaction: t })
                      // }
                      const v_check_list_uniqueid = cons.randomId();
                      await DAStageIIVerificationsChecklist.create({ uniqueId: v_check_list_uniqueid, checkName: cons.DA2_KEYS.CLASSROOMS, step: step, reffNumber: asessment_flow_uid, assessment_id: assessment_id, appId: appId }, { transaction: t })
                      await DaStageIIVerification.create({ uniqueId: cons.randomId(), reffNumber: v_check_list_uniqueid, appId: appId, assessment_id: assessment_id, keyName: cons.DA2_KEYS.CLASSROOMS, step: step, isDraft: cons.SL.YES, recordType: cons.SL.PRESENT, reff_uniquId: asessment_flow_uid, insertDate: cons.currentDate }, { transaction: t })

                    }
                    break;
                  case cons.DA2_KEYS.MULTIPURPOSE_HALL:
                  case cons.DA2_KEYS.IT_LAB:
                  case cons.DA2_KEYS.LIBRARY:
                  case cons.DA2_KEYS.PLACEMENT_AND_COUNSELLING_ROOM:
                  case cons.DA2_KEYS.PRINCIPAL_ROOM:
                  case cons.DA2_KEYS.RECEPTION_CUM_WAITING_LOBBY:
                  case cons.DA2_KEYS.STAFF_ROOM:
                  case cons.DA2_KEYS.ADMINISTRATIVE_HALL_SECTION:
                    {
                      const v_check_list_uniqueid = cons.randomId();
                      toSave.push(DAStageIIVerificationsChecklist.create({ uniqueId: v_check_list_uniqueid, checkName: checkName, step: step, reffNumber: asessment_flow_uid, assessment_id: assessment_id, appId: appId }, { transaction: t }));
                      verification.push(DaStageIIVerification.create({
                        uniqueId: cons.randomId(),
                        reffNumber: v_check_list_uniqueid, // uniqueID - da_stage_i_verifications_checklist
                        appId: appId,
                        assessment_id: assessment_id,
                        keyName: checkName,
                        step: step,
                        isDraft: cons.SL.YES,
                        recordType: cons.SL.PRESENT,
                        reff_uniquId: asessment_flow_uid,
                        insertDate: cons.currentDate
                      }, { transaction: t }));
                    }
                    break;
                  default:
                    throw "Invalid Civil Infra"
                    break;
                }
              }
              await Promise.all(toSave);
              await Promise.all(verification);
            }
            break;
          case cons.ST2FC.AMENITIES_AREA.step:
            {
              const toSave = [];
              const verification = [];
              // throw cons.AMENITIES_PARTICULARS;
              for (const obj of cons.AMENITIES_PARTICULARS) {
                const { key } = obj;
                switch (key) {
                  case cons.A_FIRST_AID_ROOM.key:
                  case cons.A_LIBRARY_AND_READING_ROOM.key:
                  case cons.A_PLAYGROUND.key:
                  case cons.A_DRINKING_WATER_FACILITY.key:
                  case cons.A_AVAILABILITY_OF_STAIRCASES.key:
                  case cons.A_TOILETS_WATER_CLOSETS.key:
                  case cons.A_GENERAL_PARKING_DETAILS.key:
                    {
                      const v_check_list_uniqueid = cons.randomId();
                      await DAStageIIVerificationsChecklist.create({ uniqueId: v_check_list_uniqueid, checkName: key, step: step, reffNumber: asessment_flow_uid, assessment_id: assessment_id, appId: appId }, { transaction: t })
                      await DaStageIIVerification.create({
                        uniqueId: cons.randomId(),
                        reffNumber: v_check_list_uniqueid, // uniqueID - da_stage_i_verifications_checklist
                        appId: appId,
                        assessment_id: assessment_id,
                        keyName: key,
                        step: step,
                        isDraft: cons.SL.YES,
                        recordType: cons.SL.PRESENT,
                        reff_uniquId: asessment_flow_uid,
                        insertDate: cons.currentDate
                      }, { transaction: t })
                    }
                    break;
                  default:
                    throw "Invalid Amenities Particulars"
                    break;
                }
              }
              await Promise.all(toSave);
              await Promise.all(verification);
            }
            break;
          case cons.ST2FC.SIGNAGE_BOARDS.step:
            {
              const toSave = [];
              const verification = [];
              // throw cons.AMENITIES_PARTICULARS;
              for (const obj of cons.Signage_Boards_Particulars) {
                const { key } = obj;
                switch (key) {
                  case cons.Signage_Boards_Keys.SIGNAGE_BOARD_ON_PLOT_ENTRANCE.key:
                  case cons.Signage_Boards_Keys.SIGNAGE_BOARD_ON_INSTITUTE_BUILDING.key:
                  case cons.Signage_Boards_Keys.SIGNAGE_BOARDS.key:
                  case cons.Signage_Boards_Keys.TRADE_DETAILS_BOARD.key:
                  case cons.Signage_Boards_Keys.STAFF_DETAILS_BOARD.key:
                  case cons.Signage_Boards_Keys.EXIT_BOARD.key:
                  case cons.Signage_Boards_Keys.BOARD_INDICATING_DANGER_SIGNS.key:
                  case cons.Signage_Boards_Keys.PROHIBITED_AREA_INDICATORS.key:
                  case cons.Signage_Boards_Keys.SEXUAL_HARASSMENT_REDRESSAL_COMMITTEE_NOTICE.key:
                    {
                      const v_check_list_uniqueid = cons.randomId();
                      await DAStageIIVerificationsChecklist.create({ uniqueId: v_check_list_uniqueid, checkName: key, step: step, reffNumber: asessment_flow_uid, assessment_id: assessment_id, appId: appId }, { transaction: t })
                      await DaStageIIVerification.create({
                        uniqueId: cons.randomId(),
                        reffNumber: v_check_list_uniqueid, // uniqueID - da_stage_i_verifications_checklist
                        appId: appId,
                        assessment_id: assessment_id,
                        keyName: key,
                        step: step,
                        isDraft: cons.SL.YES,
                        recordType: cons.SL.PRESENT,
                        reff_uniquId: asessment_flow_uid,
                        insertDate: cons.currentDate
                      }, { transaction: t })
                    }
                    break;
                  default:
                    throw "Invalid Signage_Boards_Particulars Particulars"
                    break;
                }
              }
              await Promise.all(toSave);
              await Promise.all(verification);
            }
            break;
          case cons.ST2FC.ELECTRICITY_CONNECTION_DETAILS.step:
            {
              const toSave = [];
              const verification = [];
              // throw cons.AMENITIES_PARTICULARS;
              for (const obj of cons.electricity_particulars) {
                const { key } = obj;
                switch (key) {
                  case cons.electricity_particulars_keys.ELECTRICITY_CONNECTION.key:
                  case cons.electricity_particulars_keys.PHOTO_OF_BACKUP_POWER.key:
                  case cons.electricity_particulars_keys.PURCHASE_RELATED_DOCUMENTS.key:
                  case cons.electricity_particulars_keys.FIRE_AND_SAFETY_CERTIFICATE.key:
                    {
                      const v_check_list_uniqueid = cons.randomId();
                      await DAStageIIVerificationsChecklist.create({ uniqueId: v_check_list_uniqueid, checkName: key, step: step, reffNumber: asessment_flow_uid, assessment_id: assessment_id, appId: appId }, { transaction: t })
                      await DaStageIIVerification.create({
                        uniqueId: cons.randomId(),
                        reffNumber: v_check_list_uniqueid, // uniqueID - da_stage_i_verifications_checklist
                        appId: appId,
                        assessment_id: assessment_id,
                        keyName: key,
                        step: step,
                        isDraft: cons.SL.YES,
                        recordType: cons.SL.PRESENT,
                        reff_uniquId: asessment_flow_uid,
                        insertDate: cons.currentDate
                      }, { transaction: t })
                    }
                    break;
                  default:
                    throw "Invalid Signage_Boards_Particulars Particulars"
                    break;
                }
              }
              await Promise.all(toSave);
              await Promise.all(verification);
            }
            break;
          case cons.ST2FC.TRADEWISE_MACHINERY__TOOLS__EQUIPMENT_DETAILS.step:
            {
              const toSave = [];
              const verification = [];
              // throw cons.AMENITIES_PARTICULARS;
              for (const obj of cons.iti_lab_particulars) {
                const { key } = obj;
                switch (key) {
                  case cons.iti_lab_particulars_keys.DESKTOP_COMPUTER_WITH_LATEST_CONFIGURATION.key:
                  case cons.iti_lab_particulars_keys.INTERNET_CONNECTION.key:
                  case cons.iti_lab_particulars_keys.COMPUTER_WITH_MULTIMEDIA_ANTI_VIRUS_ETC.key:
                  case cons.iti_lab_particulars_keys.LAN_CABLING_ETC.key:
                  case cons.iti_lab_particulars_keys.PRINTER_LASER.key:
                  case cons.iti_lab_particulars_keys.SCANNER.key:
                  case cons.iti_lab_particulars_keys.SERVER.key:
                  case cons.iti_lab_particulars_keys.EXTERNAL_HARD_DISK_1TB.key:
                  case cons.iti_lab_particulars_keys.INSTRUCTOR_OFFICE_CHAIR.key:
                  case cons.iti_lab_particulars_keys.INSTRUCTOR_OFFICE_TABLE.key:
                  case cons.iti_lab_particulars_keys.TRAINEES_COMPUTER_CHAIRS.key:
                  case cons.iti_lab_particulars_keys.TRAINEES_COMPUTER_TABLES.key:
                  case cons.iti_lab_particulars_keys.BLACK_WHITE_BOARD_4X6_FEET.key:
                    {
                      const v_check_list_uniqueid = cons.randomId();
                      await DAStageIIVerificationsChecklist.create({ uniqueId: v_check_list_uniqueid, checkName: key, step: step, reffNumber: asessment_flow_uid, assessment_id: assessment_id, appId: appId }, { transaction: t })
                      await DaStageIIVerification.create({
                        uniqueId: cons.randomId(),
                        reffNumber: v_check_list_uniqueid, // uniqueID - da_stage_i_verifications_checklist
                        appId: appId,
                        assessment_id: assessment_id,
                        keyName: key,
                        step: step,
                        isDraft: cons.SL.YES,
                        recordType: cons.SL.PRESENT,
                        reff_uniquId: asessment_flow_uid,
                        insertDate: cons.currentDate
                      }, { transaction: t })
                    }
                    break;
                  default:
                    throw `Invalid iti_lab_particulars Particulars ${key}`
                    break;
                }
              }
              await Promise.all(toSave);
              await Promise.all(verification);

              const v_check_list_uniqueid = cons.randomId();
              await DAStageIIVerificationsChecklist.create({ uniqueId: v_check_list_uniqueid, checkName: cons.TRADEWISE_MACHINERY_TOOLS_EQUIPMENT, step: step, reffNumber: asessment_flow_uid, assessment_id: assessment_id, appId: appId }, { transaction: t })
            }
            break;
          case cons.ST2FC.REVIEW_ASSESSMENT.step:
            break;
          default:
            throw "Invalid Assessment Step";
            break;
        }
      } catch (error) {
        throw error;
      }
    }
    // throw cons.ASSESSMENT_STAGE_II_FLOW_NEW;
    await AppFlow.update({ status: cons.STAGE_II__ASSESSMENT_ON_PROGRESS, stepStatus: cons.SL.ON_PROGRESS_2 }, { where: { appId: appId, step: cons.STAGE_II__ASSESSMENT }, transaction: t });
    await t.commit();
    // await t.rollback();
  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    console.log('reached to final')
  }
  return { status: true };
};

export const setStageIAssessmentFlow = async (req, res) => {
  let connection, userId;
  const t = await sequelize.transaction();
  try {

    // connection = await mysql.createConnection(affDbConfig);

    const { appId } = req.body;

    userId = req.userInfo.user_id;

    let existAppFlow = await AppFlow.findOne({ where: { appId: appId } });

    if (!existAppFlow) {
      throw "App FLow Not Found";
    }


    let existAsmtFlow = await AppAssessmentFlowStageI.findOne({ where: { appId: appId } });
    if (existAsmtFlow) {
      // throw "Assessment FLow Already Exist";
    }

    let exist_asmt = await AssessmentStatus.findOne({ where: { appId: appId } });
    // throw exist_asmt;
    if (exist_asmt) {
      // throw "Assessment Already Exist";
    }
    const { assessment_id, assessment_status, pendingAt } = cons.ASSESSMENT_STATUS;
    let asmt = await AssessmentStatus.create({ appId: appId, assessment_id: assessment_id, assessment_status: assessment_status, pendingAt: pendingAt, stage: cons.abbreviation.STAGE_I.key }, { transaction: t });
    for (const flow of cons.ASSESSMENT_STAGE_I_FLOW) {
      const uid = cons.randomIdLong();
      let flowModified = {
        ...flow,
        uniqueID: uid,
        appId: appId,
        assessment_id: assessment_id,
        VerificationList: flow.VerificationList.map((item, index) => {
          return {
            ...item,
            assessment_id: assessment_id,
            uniqueId: cons.randomIdLong(),
            appId: appId,
            reffNumber: uid
          }
        })
      }
      await AppAssessmentFlowStageI.create(flowModified, { transaction: t });
      await DAStageIVerificationsChecklist.bulkCreate(flowModified.VerificationList, { transaction: t });
    }



    await AppFlow.update({ status: cons.STAGE_I__ASSESSMENT_ON_PROGRESS, stepStatus: cons.SL.ON_PROGRESS_2 }, { where: { appId: appId, step: cons.STAGE_I__ASSESSMENT }, transaction: t });
    await t.commit();
    // await t.rollback();

  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    console.log('reached to final')
  }
  // return { msg: "Information Successfully" };

  return { status: true };


  // const db = await initDB();
  // try {
  //   const tx = db.transaction([C.TBL_ASSESSMENTS_STATUS, C.APP_ASSESSMENT_FLOW_STAGE_I, C.DA_STAGE_I_VERIFICATIONS_CHECKLIST], 'readwrite');

  //   const store = tx.objectStore(C.APP_ASSESSMENT_FLOW_STAGE_I);
  //   const vrfcn_store = tx.objectStore(C.DA_STAGE_I_VERIFICATIONS_CHECKLIST);
  //   const asmt_store = tx.objectStore(C.TBL_ASSESSMENTS_STATUS);

  //   let assessment_id = Date.now() + Math.random();

  //   let asmt_data = await asmt_store.index("appId").getAll(appId);

  //   if (asmt_data.length === 0) {

  //     await asmt_store.put({ ...C.ASSESSMENT_STATUS, assessment_id: assessment_id, id: Date.now() + Math.random(), appId: appId, assessment_status: C.SL.ON_PROGRESS, pendingAt: C.SL.PENDING_AT_ASSESSOR });

  //     for (const [index, flow] of C.ASSESSMENT_STAGE_I_FLOW.entries()) {
  //       let id = Date.now() + Math.random();
  //       await store.put({ ...flow, id: id, appId: appId, assessment_id: assessment_id, });
  //       if (flow?.VerificationList) {
  //         for (const [index, ver] of flow.VerificationList.entries()) {
  //           let id = Date.now() + Math.random();
  //           await vrfcn_store.put({ ...ver, id: id, appId: appId, assessment_id: assessment_id, });
  //         }
  //       }
  //     }
  //   }
  //   await tx.done;
  // } catch (error) {
  //   console.error(error);
  // }

};
export const getAsmtFlowForStageII = async (req, res) => {
  let connection, userId, userInfo, userType, flowData;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {



    const { appId } = req.body;
    userType = cons.getUserTypeByString(req.userInfo.userType);
    userId = req.userInfo.user_id;

    // return userType;

    {
      const found = await AssessmentStatus.findOne({ where: { appId: appId } });
      if (!found) {
        throw "Assesment Status Not Found";
      }
      let aInfo = found;
    }

    {
      const found = await AppAssessmentFlowStageII.findAll({ where: { appId: appId, actor: userType, recordType: cons.SL.PRESENT }, order: [['stepNo', 'ASC']] });
      if (!found) {
        throw "Assesment Status Not Found";
      }
      flowData = found
    }





    // Setting Verification List
    // Setting Verification List
    // flowData = await Promise.all(
    //   result_2.map(async (step) => {
    //     switch (step.step) {
    //       case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step: {
    //         const stmt2 = await connection.prepare('SELECT * FROM `' + cons.DA_STAGE_I_VERIFICATIONS_CHECKLIST + '` WHERE appId=? and step=?');
    //         const [rows] = await stmt2.execute([appId, step.step]);
    //         if (rows.length > 0) {
    //           step = { ...step, VerificationList: rows };
    //         } else {
    //           throw new Error("Verification List Not Found");
    //         }
    //         break;
    //       }
    //       case cons.ST1FC.DOCUMENTS_UPLOAD.step: {
    //         const stmt2 = await connection.prepare('SELECT * FROM `' + cons.DA_STAGE_I_VERIFICATIONS_CHECKLIST + '` WHERE appId=? and step=?');
    //         const [rows] = await stmt2.execute([appId, step.step]);
    //         if (rows.length > 0) {
    //           step = { ...step, VerificationList: rows };
    //         } else {
    //           throw new Error("Verification List Not Found");
    //         }
    //         break;
    //       }
    //     }
    //     return step;
    //   })
    // );




    // flowData = await flowData.map((step) => {
    //   let status = false;
    //   switch (step?.status) {
    //     case cons.SL.VERIFIED:
    //       status = true;
    //       break;
    //     case cons.SL.COMPLETED:
    //       status = true;
    //       break;
    //     case cons.SL.ON_PROGRESS:
    //       switch (aInfo?.pendingAt) {
    //         case cons.SL.PENDING_AT_APPLICANT:
    //           status = true;
    //           break;
    //         case cons.SL.PENDING_AT_ASSESSOR:
    //           status = true;
    //           break;
    //         case cons.SL.PENDING_AT_RDSDE:
    //           status = true;
    //           break;
    //         default:
    //           status = false;
    //           break;
    //       }
    //       break;
    //     default:
    //       status = false;
    //       break;
    //   }
    //   return { ...step, completed: status };
    // });
    // Commit the transaction
    // await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    // if (connection) {
    //   await connection.rollback();
    // }
    throw err;
  } finally {
    // if (connection) await connection.end();
  }

  return flowData;
};
export const getAssessmentStageIIFlowById = async (req, res) => {
  let connection, userId, userInfo, userType, flowData;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {

    connection = await mysql.createConnection(affDbConfig);


    const { appId } = req.body;
    userType = cons.getUserTypeByString(req.userInfo.userType);
    userId = req.userInfo.user_id;

    // return userType;



    await connection.beginTransaction();

    // const tx = db.transaction([C.APP_ASSESSMENT_FLOW_STAGE_I, C.TBL_ASSESSMENTS_STATUS], 'readwrite');

    // Getting the assessment status
    // const store_2 = tx.objectStore(C.TBL_ASSESSMENTS_STATUS);
    let stmt1 = await connection.prepare('SELECT * FROM `' + cons.TBL_ASSESSMENTS_STATUS + '` WHERE appId = ?');
    let [result_1] = await stmt1.execute([appId]);
    if (result_1.length === 0) {
      throw new Error("Assessment Status Not Found");
    }
    let aInfo = result_1[0]; // await store_2.index('appId').get(appId);


    // const store = tx.objectStore(C.APP_ASSESSMENT_FLOW_STAGE_I);
    let stmt2 = await connection.prepare('SELECT * FROM `' + cons.APP_ASSESSMENT_FLOW_STAGE_I + '` WHERE appId=? and actor=? and recordType=? ORDER BY stepNo ASC ');
    // d1 = await store.index('appId_for_recordType').getAll([appId, userType, C.SL.PRESENT]);
    let [result_2] = await stmt2.execute([appId, userType, cons.SL.PRESENT]);
    if (result_2.length === 0) {
      throw new Error("Assessment Status Not Found");
    }

    // Setting Verification List
    // Setting Verification List
    flowData = await Promise.all(
      result_2.map(async (step) => {
        switch (step.step) {
          case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step: {
            const stmt2 = await connection.prepare('SELECT * FROM `' + cons.DA_STAGE_I_VERIFICATIONS_CHECKLIST + '` WHERE appId=? and step=?');
            const [rows] = await stmt2.execute([appId, step.step]);
            if (rows.length > 0) {
              step = { ...step, VerificationList: rows };
            } else {
              throw new Error("Verification List Not Found");
            }
            break;
          }
          case cons.ST1FC.DOCUMENTS_UPLOAD.step: {
            const stmt2 = await connection.prepare('SELECT * FROM `' + cons.DA_STAGE_I_VERIFICATIONS_CHECKLIST + '` WHERE appId=? and step=?');
            const [rows] = await stmt2.execute([appId, step.step]);
            if (rows.length > 0) {
              step = { ...step, VerificationList: rows };
            } else {
              throw new Error("Verification List Not Found");
            }
            break;
          }
        }
        return step;
      })
    );




    flowData = await flowData.map((step) => {
      let status = false;
      switch (step?.status) {
        case cons.SL.VERIFIED:
          status = true;
          break;
        case cons.SL.COMPLETED:
          status = true;
          break;
        case cons.SL.ON_PROGRESS:
          switch (aInfo?.pendingAt) {
            case cons.SL.PENDING_AT_APPLICANT:
              status = true;
              break;
            case cons.SL.PENDING_AT_ASSESSOR:
              status = true;
              break;
            case cons.SL.PENDING_AT_RDSDE:
              status = true;
              break;
            default:
              status = false;
              break;
          }
          break;
        default:
          status = false;
          break;
      }
      return { ...step, completed: status };
    });
    // Commit the transaction
    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }

  return flowData;
};
export const getAssessmentStageIFlowById = async (req, res) => {
  let connection, userId, userInfo, userType, flowData;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {

    connection = await mysql.createConnection(affDbConfig);


    const { appId } = req.body;
    userType = cons.getUserTypeByString(req.userInfo.userType);
    userId = req.userInfo.user_id;

    // return userType;



    await connection.beginTransaction();

    // const tx = db.transaction([C.APP_ASSESSMENT_FLOW_STAGE_I, C.TBL_ASSESSMENTS_STATUS], 'readwrite');

    // Getting the assessment status
    // const store_2 = tx.objectStore(C.TBL_ASSESSMENTS_STATUS);
    let stmt1 = await connection.prepare('SELECT * FROM `' + cons.TBL_ASSESSMENTS_STATUS + '` WHERE appId = ?');
    let [result_1] = await stmt1.execute([appId]);
    if (result_1.length === 0) {
      throw new Error("Assessment Status Not Found");
    }
    let aInfo = result_1[0]; // await store_2.index('appId').get(appId);


    // const store = tx.objectStore(C.APP_ASSESSMENT_FLOW_STAGE_I);
    let stmt2 = await connection.prepare('SELECT * FROM `' + cons.APP_ASSESSMENT_FLOW_STAGE_I + '` WHERE appId=? and actor=? and recordType=? ORDER BY stepNo ASC ');
    // d1 = await store.index('appId_for_recordType').getAll([appId, userType, C.SL.PRESENT]);
    let [result_2] = await stmt2.execute([appId, userType, cons.SL.PRESENT]);
    if (result_2.length === 0) {
      throw new Error("Assessment Status Not Found");
    }

    // Setting Verification List
    // Setting Verification List
    flowData = await Promise.all(
      result_2.map(async (step) => {
        switch (step.step) {
          case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step: {
            const stmt2 = await connection.prepare('SELECT * FROM `' + cons.DA_STAGE_I_VERIFICATIONS_CHECKLIST + '` WHERE appId=? and step=?');
            const [rows] = await stmt2.execute([appId, step.step]);
            if (rows.length > 0) {
              step = { ...step, VerificationList: rows };
            } else {
              throw new Error("Verification List Not Found");
            }
            break;
          }
          case cons.ST1FC.DOCUMENTS_UPLOAD.step: {
            const stmt2 = await connection.prepare('SELECT * FROM `' + cons.DA_STAGE_I_VERIFICATIONS_CHECKLIST + '` WHERE appId=? and step=?');
            const [rows] = await stmt2.execute([appId, step.step]);
            if (rows.length > 0) {
              step = { ...step, VerificationList: rows };
            } else {
              throw new Error("Verification List Not Found");
            }
            break;
          }
        }
        return step;
      })
    );




    flowData = await flowData.map((step) => {
      let status = false;
      switch (step?.status) {
        case cons.SL.VERIFIED:
          status = true;
          break;
        case cons.SL.COMPLETED:
          status = true;
          break;
        case cons.SL.ON_PROGRESS:
          switch (aInfo?.pendingAt) {
            case cons.SL.PENDING_AT_APPLICANT:
              status = true;
              break;
            case cons.SL.PENDING_AT_ASSESSOR:
              status = true;
              break;
            case cons.SL.PENDING_AT_RDSDE:
              status = true;
              break;
            default:
              status = false;
              break;
          }
          break;
        default:
          status = false;
          break;
      }
      return { ...step, completed: status };
    });
    // Commit the transaction
    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }

  return flowData;


};


export const getBasicDetail_asmt = async (req, res) => {
  let finalResult = {};
  try {

    const { appId } = req.body;
    const userType = cons.getUserTypeByString(req.userInfo.userType);
    const userId = req.userInfo.user_id;

    const found = await DaStageIIVerification.findAll({ where: { recordType: cons.SL.PRESENT, appId: appId, step: cons.ST2FC.BUILDING_DETAIL.step } });
    if (!found) {
      throw "Information Not Found";
    }

    for (const item of found) {
      const { keyName } = item;
      switch (keyName) {
        case cons.DA2_KEYS.BUILDING_PLAN:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: cons.DA2_KEYS.BUILDING_PLAN, step: cons.ST2FC.BUILDING_DETAIL.step } });
            const initial_buildingPlanDocument = await BuildingPlan.findAll({ where: { appId: appId } });

            const { uniqueId, reffNumber, keyName, step, as_per_norms, reason, assessor_comments, isDraft } = found
            // throw { uniqueId, reffNumber, keyName, step, as_per_norms, reason, assessor_comments, isDraft };
            finalResult = {
              ...finalResult, building_plan: { uniqueId, reffNumber, keyName, step, as_per_norms, reason, assessor_comments, isDraft, building_plan_docs: initial_buildingPlanDocument }
            }
          }
          break;
        case cons.DA2_KEYS.BUILDING_COMPLETION_CERTIFICATE:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: cons.DA2_KEYS.BUILDING_COMPLETION_CERTIFICATE, step: cons.ST2FC.BUILDING_DETAIL.step } });
            const { uniqueId, reffNumber, keyName, step, as_per_norms, reason, assessor_comments, isDraft } = found;
            const initial_bcc = await BccDocuments.findAll({
              attributes: ["uniqueId", "language_for_building_completion_certificate", "building_completion_certificate", "notarised_document_of_bcc", "name_of_bcc_issued_authority", "date_of_bcc_issued", "appId", "uploadDate"], where: { appId: appId }
            });

            finalResult = {
              ...finalResult, building_completion_certificate: { ...{ documents: initial_bcc, }, ...{ uniqueId, reffNumber, keyName, step, as_per_norms, reason, assessor_comments, isDraft } }
            }
          }
          break;
        case cons.DA2_KEYS.BUILDING_PHOTOS:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: cons.DA2_KEYS.BUILDING_COMPLETION_CERTIFICATE, step: cons.ST2FC.BUILDING_DETAIL.step } });
            const { uniqueId, reffNumber, keyName, step, as_per_norms, reason, assessor_comments, isDraft } = found;
            const initial_buildingPhotos = await BuildingPhotos.findAll({ where: { appId: appId } });
            finalResult = {
              ...finalResult, building_photos: { ...{ photos: initial_buildingPhotos, }, ...{ uniqueId, reffNumber, keyName, step, as_per_norms, reason, assessor_comments, isDraft } }
            }
          }
          break;
        default:
          throw "Invalide Information"
      }
    }
  } catch (err) {
    throw err;
  }
  return finalResult;
};

export const getCivilInfrastructure_asmt = async (req, res) => {
  let finalResult = {};
  try {

    const { appId } = req.body;
    const userType = cons.getUserTypeByString(req.userInfo.userType);
    const userId = req.userInfo.user_id;

    const found = await DaStageIIVerification.findAll({ where: { recordType: cons.SL.PRESENT, appId: appId, step: cons.ST2FC.CIVIL_INFRASTRUCTURE_DETAIL.step } });
    if (!found) {
      throw "Information Not Found";
    }

    // Required Value of schema
    // throw found;
    // throw C.st2Asmt.CivilInfra.intiValues;

    for (const item of found) {
      const { keyName } = item;
      switch (keyName) {
        case cons.DA2_KEYS.WORKSHOPS:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: cons.DA2_KEYS.WORKSHOPS, step: cons.ST2FC.CIVIL_INFRASTRUCTURE_DETAIL.step } });
            const [count, totalAvailableArea, singleRecord] = await Promise.all([
              TradewiseWorkshop.count({ where: { appId } }),
              TradewiseWorkshop.sum('available_area', { where: { appId } }),
              TradewiseWorkshop.findOne({ attributes: ['required_area'], where: { appId } })]);
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, WORKSHOPS: {
                as_per_norms, reason, assessor_comments,
                initial_detail: {
                  required_area: count * singleRecord.required_area,
                  totalAvailableArea: totalAvailableArea,
                },
                latest_detail: null
              }
            }
          }
          break;
        case cons.DA2_KEYS.CLASSROOMS:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: cons.DA2_KEYS.CLASSROOMS, step: cons.ST2FC.CIVIL_INFRASTRUCTURE_DETAIL.step } });
            const [count, totalAvailableArea, singleRecord] = await Promise.all([
              TradewiseClassRoom.count({ where: { appId } }),
              TradewiseClassRoom.sum('available_area', { where: { appId } }),
              TradewiseClassRoom.findOne({ attributes: ['required_area'], where: { appId } })]);
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, CLASSROOMS: {
                as_per_norms, reason, assessor_comments,
                initial_detail: {
                  required_area: count * singleRecord.required_area,
                  totalAvailableArea: totalAvailableArea,
                },
                latest_detail: null
              }
            }
          }
          break;
        case cons.DA2_KEYS.MULTIPURPOSE_HALL:
        case cons.DA2_KEYS.IT_LAB:
        case cons.DA2_KEYS.LIBRARY:
        case cons.DA2_KEYS.PLACEMENT_AND_COUNSELLING_ROOM:
        case cons.DA2_KEYS.PRINCIPAL_ROOM:
        case cons.DA2_KEYS.RECEPTION_CUM_WAITING_LOBBY:
        case cons.DA2_KEYS.STAFF_ROOM:
        case cons.DA2_KEYS.ADMINISTRATIVE_HALL_SECTION:
          const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: keyName, step: cons.ST2FC.CIVIL_INFRASTRUCTURE_DETAIL.step } });
          const found2 = await CommonCivilInfrastructure.findOne({ where: { particular: keyName, appId: appId } });
          const { as_per_norms, reason, assessor_comments } = found
          finalResult = {
            ...finalResult, [keyName]: {
              as_per_norms, reason, assessor_comments,
              initial_detail: found2,
              latest_detail: null
            }
          }
          break;

        default:
        // throw "Invalide Information"
      }
    }
  } catch (err) {
    throw err;
  }
  return finalResult;
};



export const getAmenitiesArea_asmt = async (req, res) => {
  let finalResult = {};
  try {

    const { appId } = req.body;
    const userType = cons.getUserTypeByString(req.userInfo.userType);
    const userId = req.userInfo.user_id;

    const found = await DaStageIIVerification.findAll({ where: { recordType: cons.SL.PRESENT, appId: appId, step: cons.ST2FC.AMENITIES_AREA.step } });
    if (!found) {
      throw "Information Not Found";
    }
    for (const item of found) {
      const { keyName } = item;
      switch (keyName) {
        case C.A_FIRST_AID_ROOM.key:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: keyName, step: cons.ST2FC.AMENITIES_AREA.step } });
            const found2 = await AmenitiesParticulars.findOne({ where: { particular: C.AMNT.FIRST_AID_ROOM, appId: appId } });
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, [keyName]: {
                as_per_norms, reason, assessor_comments,
                initial_detail: found2,
                latest_detail: null
              }
            }
          }
          break;
        case C.A_LIBRARY_AND_READING_ROOM.key:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: keyName, step: cons.ST2FC.AMENITIES_AREA.step } });
            const found2 = await AmenitiesParticulars.findOne({ where: { particular: C.AMNT.LIBRARY_AND_READING_ROOM, appId: appId } });
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, [keyName]: {
                as_per_norms, reason, assessor_comments,
                initial_detail: found2,
                latest_detail: null
              }
            }
          }
          break;
        case C.A_PLAYGROUND.key:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: keyName, step: cons.ST2FC.AMENITIES_AREA.step } });
            const found2 = await AmenitiesParticulars.findOne({ where: { particular: C.AMNT.PLAYGROUND, appId: appId } });
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, [keyName]: {
                as_per_norms, reason, assessor_comments,
                initial_detail: found2,
                latest_detail: null
              }
            }
          }
          break;
        case C.A_DRINKING_WATER_FACILITY.key:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: keyName, step: cons.ST2FC.AMENITIES_AREA.step } });
            const found2 = await AmenitiesParticulars.findOne({ where: { particular: C.AMNT.DRINKING_WATER_FACILITY, appId: appId } });
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, [keyName]: {
                as_per_norms, reason, assessor_comments,
                initial_detail: found2,
                latest_detail: null
              }
            }
          }
          break;
        case C.A_AVAILABILITY_OF_STAIRCASES.key:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: keyName, step: cons.ST2FC.AMENITIES_AREA.step } });
            const found2 = await AmenitiesParticulars.findOne({ where: { particular: C.AMNT.AVAILABILITY_OF_STAIRCASES, appId: appId } });
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, [keyName]: {
                as_per_norms, reason, assessor_comments,
                initial_detail: found2,
                latest_detail: null
              }
            }
          }
          break;
        case C.A_TOILETS_WATER_CLOSETS.key:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: keyName, step: cons.ST2FC.AMENITIES_AREA.step } });
            const found2 = await AmenitiesParticulars.findOne({ where: { particular: C.AMNT.TOILETS_WATER_CLOSETS, appId: appId } });
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, [keyName]: {
                as_per_norms, reason, assessor_comments,
                initial_detail: found2,
                latest_detail: null
              }
            }
          }
          break;
        case C.A_GENERAL_PARKING_DETAILS.key:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: keyName, step: cons.ST2FC.AMENITIES_AREA.step } });
            const found2 = await AmenitiesParticulars.findOne({ where: { particular: C.AMNT.GENERAL_PARKING_DETAILS, appId: appId } });
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, [keyName]: {
                as_per_norms, reason, assessor_comments,
                initial_detail: found2,
                latest_detail: null
              }
            }
          }
          break;
        default:
        // throw "Invalide Information"
      }
    }
  } catch (err) {
    throw err;
  }
  return finalResult;
};



export const getElectricityDetails_asmt = async (req, res) => {
  let finalResult = {};
  try {

    const { appId } = req.body;
    const userType = cons.getUserTypeByString(req.userInfo.userType);
    const userId = req.userInfo.user_id;

    const found = await DaStageIIVerification.findAll({ where: { recordType: cons.SL.PRESENT, appId: appId, step: cons.ST2FC.ELECTRICITY_CONNECTION_DETAILS.step } });
    if (!found) {
      throw "Information Not Found";
    }

    // throw found;
    for (const item of found) {
      const { keyName } = item;
      // throw keyName;
      switch (keyName) {
        case C.electricity_particulars_keys.ELECTRICITY_CONNECTION.key:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: keyName, step: cons.ST2FC.ELECTRICITY_CONNECTION_DETAILS.step } });
            const found2 = await ElectricityDetails.findOne({ where: { appId: appId } });
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, [keyName]: {
                as_per_norms, reason, assessor_comments,
                initial_detail: found2,
                latest_detail: null
              }
            }
          }
          break;
        case C.electricity_particulars_keys.FIRE_AND_SAFETY_CERTIFICATE.key:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: keyName, step: cons.ST2FC.ELECTRICITY_CONNECTION_DETAILS.step } });
            const found2 = await ElectricityDocuments.findOne({ where: { appId: appId, document_type: 'fire_and_safety_certificate' } });
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, [keyName]: {
                as_per_norms, reason, assessor_comments,
                initial_detail: found2,
                latest_detail: null
              }
            }
          }
          break;
        case C.electricity_particulars_keys.PHOTO_OF_BACKUP_POWER.key:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: keyName, step: cons.ST2FC.ELECTRICITY_CONNECTION_DETAILS.step } });
            const found2 = await ElectricityDocuments.findOne({ where: { appId: appId, document_type: 'power_supply_back_power' } });
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, [keyName]: {
                as_per_norms, reason, assessor_comments,
                initial_detail: found2,
                latest_detail: null
              }
            }
          }
          break;
        case C.electricity_particulars_keys.PURCHASE_RELATED_DOCUMENTS.key:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: keyName, step: cons.ST2FC.ELECTRICITY_CONNECTION_DETAILS.step } });
            const found2 = await ElectricityDocuments.findOne({ where: { appId: appId, document_type: 'power_supply_purchase_related_documents' } });
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, [keyName]: {
                as_per_norms, reason, assessor_comments,
                initial_detail: found2,
                latest_detail: null
              }
            }
          }
          break;
        default:
          throw "Invalide Information"
      }
    }
  } catch (err) {
    throw err;
  }
  return finalResult;
};
export const getSignageBoards_asmt = async (req, res) => {
  let finalResult = {};
  try {

    const { appId } = req.body;
    const userType = cons.getUserTypeByString(req.userInfo.userType);
    const userId = req.userInfo.user_id;

    const found = await DaStageIIVerification.findAll({ where: { recordType: cons.SL.PRESENT, appId: appId, step: cons.ST2FC.SIGNAGE_BOARDS.step } });
    if (!found) {
      throw "Information Not Found";
    }

    // throw found;
    for (const item of found) {
      const { keyName } = item;
      switch (keyName) {
        case C.Signage_Boards_Keys.SIGNAGE_BOARD_ON_PLOT_ENTRANCE.key:
        case C.Signage_Boards_Keys.SIGNAGE_BOARD_ON_INSTITUTE_BUILDING.key:
        case C.Signage_Boards_Keys.SIGNAGE_BOARDS.key:
        case C.Signage_Boards_Keys.TRADE_DETAILS_BOARD.key:
        case C.Signage_Boards_Keys.STAFF_DETAILS_BOARD.key:
        case C.Signage_Boards_Keys.EXIT_BOARD.key:
        case C.Signage_Boards_Keys.BOARD_INDICATING_DANGER_SIGNS.key:
        case C.Signage_Boards_Keys.PROHIBITED_AREA_INDICATORS.key:
        case C.Signage_Boards_Keys.SEXUAL_HARASSMENT_REDRESSAL_COMMITTEE_NOTICE.key:
          {
            const found = await DaStageIIVerification.findOne({ where: { recordType: cons.SL.PRESENT, appId: appId, keyName: keyName, step: cons.ST2FC.SIGNAGE_BOARDS.step } });
            const found2 = await SignageBoardsParticulars.findOne({ where: { particular: keyName, appId: appId } });
            const { as_per_norms, reason, assessor_comments } = found
            finalResult = {
              ...finalResult, [keyName]: {
                as_per_norms, reason, assessor_comments,
                initial_detail: found2,
                latest_detail: null
              }
            }
          }
          break;
        default:
        // throw "Invalide Information"
      }
    }
  } catch (err) {
    throw err;
  }
  return finalResult;
};

export const get_da_status_possasion_of_land = async (req, res) => {
  let finalResult = {};
  try {

    const { appId } = req.body;
    const userType = cons.getUserTypeByString(req.userInfo.userType);
    const userId = req.userInfo.user_id;

    // return userType;

    let result = await DaStageIVerification.findOne({
      where: {
        appId: appId, keyName: cons.DA1_KEYS.LAND_DOCUMENT, isDraft: 'yes'
      }
    });

    let land_documents = await LandDocuments.findAll({
      where: { appId: appId },
      attributes: ['appId', 'language', 'document', 'notarised_document', 'uploaded_datetime']
    });




    // throw land_documents;

    finalResult = { ...result?.get({ plain: true }), ...{ land_documents: land_documents } }
  } catch (err) {
    throw err;
  }
  return finalResult;

};

export const get_vrf_list_land_to_be_used = async (req, res) => {
  let finalResult = [];
  try {

    const { appId, step } = req.body;
    const userType = cons.getUserTypeByString(req.userInfo.userType);
    const userId = req.userInfo.user_id;

    let list = await GET_VERIFICATION_LIST_BY_STEP.findAll({
      attributes: ['checkName'],
      where: {
        appId: appId, step: step
      }
    });

    for (const item of list) {
      const { checkName } = item;
      switch (checkName) {
        case cons.DA1_KEYS.LAND_DOCUMENT:
        case "land_documents":
          // throw checkName;
          let list = await GET_VERIFICATION_LIST_BY_STEP.findOne({
            attributes: ['uniqueId', 'checkName', 'da_status', 'step', 'appId', 'assessment_id',
              [Sequelize.literal(`'${userType}'`), 'actor']
            ],
            where: {
              appId: appId, step: step, checkName: checkName
            },
            include: [
              {
                attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                model: GetVerifications,
                as: "Verificiation",
                required: false, // LEFT JOIN
                where: { appId: appId, isDraft: cons.SL.YES }
              },
              {
                // attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                model: LandOwnedLand,
                as: "land_owner_info",
                required: false, // LEFT JOIN
                where: { appId: appId }
              },
              {
                // attributes: ['appId', 'assessment_id', 'recordType', 'language', 'document', 'notarised_document', 'timestamp', 'reference_number'],
                model: Stage1Documents,
                as: "init_land_documents",
                required: false, // LEFT JOIN
                where: { appId: appId }
              },
              {
                attributes: ['appId', 'assessment_id', 'recordType', 'language', 'document', 'notarised_document', 'timestamp', 'reference_number'],
                model: LandDocuments,
                as: "old_land_documents",
                required: false, // LEFT JOIN
                where: { appId: appId, recordType: cons.SL.HISTORY }
              },
              {
                attributes: ['appId', 'assessment_id', 'recordType', 'language', 'document', 'notarised_document', 'timestamp', 'reference_number'],
                model: LandDocuments,
                as: "latest_land_documents",
                required: false, // LEFT JOIN
                where: { appId: appId, recordType: cons.SL.PRESENT }
              },
            ],
          });
          finalResult.push(list);
          break;
        case cons.DA1_KEYS.LAND_AREA:
          {
            let list = await GET_VERIFICATION_LIST_BY_STEP.findOne({
              attributes: ['uniqueId', 'checkName', 'da_status', 'step', 'appId', 'assessment_id',
                [Sequelize.literal(`'${userType}'`), 'actor']
              ],
              where: {
                appId: appId, step: step, checkName: checkName
              },
              include: [
                {
                  attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: GetVerifications,
                  as: "Verificiation",
                  required: false, // LEFT JOIN
                  where: { appId: appId, isDraft: cons.SL.YES }
                },
                {
                  attributes: ["appId", "land_area", "created_date"],
                  model: InitialLandArea,
                  as: "initial_land_area",
                  required: false, // LEFT JOIN
                },
                {
                  attributes: ["appId", "assessment_id", "reference_number", "recordType", "land_area", "created_date", "update_date"],
                  model: LandArea,
                  as: "latest_land_area",
                  required: false, // LEFT JOIN
                  where: { appId: appId, recordType: cons.SL.PRESENT }
                },
                {
                  attributes: ["appId", "assessment_id", "reference_number", "recordType", "land_area", "created_date", "update_date"],
                  model: LandArea,
                  as: "old_land_area",
                  required: false, // LEFT JOIN
                  where: { appId: appId, recordType: cons.SL.HISTORY }
                },
              ],
            });
            finalResult.push(list);
          }
          break;

        case cons.DA1_KEYS.ID_PROOF_OF_AUTHORIZED_SIGNATORY:
          {

            let list = await GET_VERIFICATION_LIST_BY_STEP.findOne({
              attributes: ['uniqueId', 'checkName', 'da_status', 'step', 'appId', 'assessment_id',
                [Sequelize.literal(`'${userType}'`), 'actor']
              ],
              where: {
                appId: appId, step: step, checkName: checkName
              },
              include: [
                {
                  attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: GetVerifications,
                  as: "Verificiation",
                  required: false, // LEFT JOIN
                  where: { appId: appId, isDraft: cons.SL.YES }
                },

                {
                  // attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: InitialAuthorizedSignatoryDetails,
                  as: "init_auth_signatory_detail",
                  required: false, // LEFT JOIN
                  where: { appId: appId }
                },
                {
                  // attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: AuthorizedSignatoryDetail,
                  as: "old_auth_signatory_detail",
                  required: false, // LEFT JOIN
                  where: { appId: appId, recordType: cons.SL.HISTORY }
                },
                {
                  // attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: AuthorizedSignatoryDetail,
                  as: "latest_auth_signatory_detail",
                  required: false, // LEFT JOIN
                  where: { appId: appId, recordType: cons.SL.PRESENT }
                },
              ],
            });
            finalResult.push(list);
          }
          break;

        case cons.DA1_KEYS.REGISTRATION_CERTIFICATE_OF_APPLICANT_ORGANIZATION:
          {
            let list = await GET_VERIFICATION_LIST_BY_STEP.findOne({
              attributes: ['uniqueId', 'checkName', 'da_status', 'step', 'appId', 'assessment_id',
                [Sequelize.literal(`'${userType}'`), 'actor']
              ],
              where: {
                appId: appId, step: step, checkName: checkName
              },
              include: [
                {
                  attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: GetVerifications,
                  as: "Verificiation",
                  required: false, // LEFT JOIN
                  where: { appId: appId, isDraft: cons.SL.YES }
                },

                {
                  // attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: InitialCertificats,
                  as: "init_certificate",
                  required: false, // LEFT JOIN
                  where: { appId: appId, keyName: 'registration_certificate' }
                },
                {
                  // attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: Certificat,
                  as: "old_certificate",
                  required: false, // LEFT JOIN
                  where: { appId: appId, recordType: cons.SL.HISTORY }
                },
                {
                  // attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: Certificat,
                  as: "latest_certificate",
                  required: false, // LEFT JOIN
                  where: { appId: appId, recordType: cons.SL.PRESENT }
                },
              ],
            });
            finalResult.push(list);
          }
          break;
        case cons.DA1_KEYS.ID_PROOF_OF_SECRETARY_CHAIRPERSON_PRESIDENT:
          {
            let list = await GET_VERIFICATION_LIST_BY_STEP.findOne({
              attributes: ['uniqueId', 'checkName', 'da_status', 'step', 'appId', 'assessment_id',
                [Sequelize.literal(`'${userType}'`), 'actor']
              ],
              where: {
                appId: appId, step: step, checkName: checkName
              },
              include: [
                {
                  attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: GetVerifications,
                  as: "Verificiation",
                  required: false, // LEFT JOIN
                  where: { appId: appId, isDraft: cons.SL.YES }
                },
                {
                  // attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: InitialSecretaryChairpersonPresidentIdInfo,
                  as: "init_scp",
                  required: false, // LEFT JOIN
                  where: { appId: appId }
                },
                {
                  // attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: SecretaryChairpersonPresidentIdInfo,
                  as: "old_scp",
                  required: false, // LEFT JOIN
                  where: { appId: appId, recordType: cons.SL.HISTORY }
                },
                {
                  // attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: SecretaryChairpersonPresidentIdInfo,
                  as: "latest_scp",
                  required: false, // LEFT JOIN
                  where: { appId: appId, recordType: cons.SL.PRESENT }
                },
              ],
            });
            finalResult.push(list);
          }
          break;
        case cons.DA1_KEYS.RESOLUTION_CERTIFICATE:
          {
            let list = await GET_VERIFICATION_LIST_BY_STEP.findOne({
              attributes: ['uniqueId', 'checkName', 'da_status', 'step', 'appId', 'assessment_id',
                [Sequelize.literal(`'${userType}'`), 'actor']
              ],
              where: {
                appId: appId, step: step, checkName: checkName
              },
              include: [
                {
                  attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: GetVerifications,
                  as: "Verificiation",
                  required: false, // LEFT JOIN
                  where: { appId: appId, isDraft: cons.SL.YES }
                },

                {
                  // attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: InitialCertificats,
                  as: "init_certificate",
                  required: false, // LEFT JOIN
                  where: { appId: appId, keyName: 'DOC_ITI_RESOLUTION' }
                },
                {
                  // attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: Certificat,
                  as: "old_certificate",
                  required: false, // LEFT JOIN
                  where: { appId: appId, recordType: cons.SL.HISTORY }
                },
                {
                  // attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: Certificat,
                  as: "latest_certificate",
                  required: false, // LEFT JOIN
                  where: { appId: appId, recordType: cons.SL.PRESENT }
                },
              ],
            });
            finalResult.push(list);
          }
          break;
        default:
          {
            let list = await GET_VERIFICATION_LIST_BY_STEP.findOne({
              attributes: ['uniqueId', 'checkName', 'da_status', 'step', 'appId', 'assessment_id',
                [Sequelize.literal(`'${userType}'`), 'actor']
              ],
              where: {
                appId: appId, step: step, checkName: checkName
              },
              include: [
                {
                  attributes: ['reffNumber', 'appId', 'assessment_id', 'keyName', 'step', 'as_per_norms', 'reason', 'assessor_comments', 'isDraft', 'insertDate', 'updateDate'],
                  model: GetVerifications,
                  as: "Verificiation",
                  required: false, // LEFT JOIN
                  where: { appId: appId, isDraft: cons.SL.YES }
                },
              ],
            });
            finalResult.push(list);
          }
          break;
      }
    }
  } catch (err) {
    throw err;
  }
  return finalResult;

};




export const save_da_doc_verification_remarks = async (req, res) => {
  let finalResult = {};
  const t = await sequelize.transaction();
  try {
    const { appId, data, step, assessment_id } = req.body;
    const userType = cons.getUserTypeByString(req.userInfo.userType);
    const userId = req.userInfo.user_id;
    const jsonData = JSON.parse(data);


    switch (step) {
      case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
        {
          const f_exist2 = await AppAssessmentFlowStageI.findOne({ where: { step: step, appId: appId, actor: cons.SL.ASSESSOR, recordType: cons.SL.PRESENT }, transaction: t });
          if (!f_exist2) {
            throw "Invalid Step";
          }
          const { uniqueID } = f_exist2;

          for (const [key, value] of Object.entries(jsonData)) {
            const { toSave, id, values, refNo } = value;
            // throw value;
            switch (id) {
              case cons.ASSESSMENT_STAGE_I_KEYS.LAND_DOCUMENTS:
              case 'land_documents':
                {
                  const { as_per_norms, reason, assessor_comments } = values;
                  let existing = await GetVerifications.findOne({
                    where: { reff_uniquId: uniqueID, recordType: cons.SL.PRESENT, assessment_id: assessment_id, appId: appId, reffNumber: refNo, keyName: id, isDraft: cons.SL.YES },  // custom condition
                    transaction: t
                  });
                  if (existing) {
                    if (as_per_norms === cons.SL.YES) {
                      await existing.update({ as_per_norms: as_per_norms, reason: null, assessor_comments: null, updateDate: cons.currentDate }, { transaction: t });
                    }
                    else {
                      await existing.update({ as_per_norms: as_per_norms, reason: reason, assessor_comments: reason === "other" ? assessor_comments || null : null, updateDate: cons.currentDate }, { transaction: t });
                    }
                  } else {
                    // throw refNo;
                    await GetVerifications.create({ reff_uniquId: uniqueID, recordType: cons.SL.PRESENT, uniqueId: cons.randomId(), reffNumber: refNo, appId, step: step, assessment_id: assessment_id || '', keyName: id, as_per_norms: as_per_norms, reason: reason || '', assessor_comments: assessor_comments || '', isDraft: cons.SL.YES, insertDate: cons.currentDate, reviewDate: cons.currentDate }, { transaction: t });
                  }
                  let checkListInfo = await DAStageIVerificationsChecklist.findOne({ where: { appId: appId, assessment_id: assessment_id, checkName: cons.DA1_KEYS.LAND_DOCUMENT } })
                  checkListInfo.update({ da_status: cons.SL.REVIEWED, reviewDate: cons.currentDate });
                }
                break;
              case cons.ASSESSMENT_STAGE_I_KEYS.LAND_AREA:
              case 'land_area':
                {
                  const { as_per_norms, reason, assessor_comments } = values;
                  let existing = await GetVerifications.findOne({
                    where: { reff_uniquId: uniqueID, recordType: cons.SL.PRESENT, assessment_id: assessment_id, appId: appId, reffNumber: refNo, keyName: id, isDraft: cons.SL.YES },  // custom condition
                    transaction: t
                  });
                  if (existing) {
                    if (as_per_norms === cons.SL.YES) {
                      await existing.update({ da_status: cons.SL.REVIEWED, as_per_norms: as_per_norms, reason: null, assessor_comments: null, updateDate: cons.currentDate }, { transaction: t });
                    }
                    else {
                      await existing.update({ da_status: cons.SL.REVIEWED, as_per_norms: as_per_norms, reason: reason, assessor_comments: reason === "other" ? assessor_comments || null : null, updateDate: cons.currentDate }, { transaction: t });
                    }
                  } else {
                    const randomId = cons.randomId();
                    await GetVerifications.create({ reff_uniquId: uniqueID, recordType: cons.SL.PRESENT, uniqueId: randomId, reffNumber: refNo, appId, step: step, assessment_id: assessment_id || '', keyName: id, as_per_norms: as_per_norms, reason: reason || '', assessor_comments: assessor_comments || '', isDraft: cons.SL.YES, insertDate: cons.currentDate, reviewDate: cons.currentDate }, { transaction: t });
                  }

                  let checkListInfo = await DAStageIVerificationsChecklist.findOne({ where: { appId: appId, assessment_id: assessment_id, checkName: cons.DA1_KEYS.LAND_AREA } })
                  checkListInfo.update({ da_status: cons.SL.REVIEWED, reviewDate: cons.currentDate });
                }
                break;
              default:
                throw "Key Mismatch";
                break;
            }
          }
          await f_exist2.update({ status: cons.SL.COMPLETED, completionDate: cons.currentDate });
          await AppAssessmentFlowStageI.update(
            { stepStatus: cons.SL.ACTIVE, activeDate: cons.currentDate },
            {
              where: {
                step: cons.ST1FC.DOCUMENTS_UPLOAD.step,
                appId: appId,
              }, transaction: t
            }
          );
        }
        break;
      case cons.ST1FC.DOCUMENTS_UPLOAD.step:
        // const allowKeys = [cons.ASSESSMENT_STAGE_I_KEYS.ID_PROOF_OF_AUTHORIZED_SIGNATORY, cons.ASSESSMENT_STAGE_I_KEYS.REGISTRATION_CERTIFICATE_OF_APPLICANT_ORGANIZATION, cons.ASSESSMENT_STAGE_I_KEYS.ID_PROOF_OF_SECRETARY_CHAIRPERSON_PRESIDENT, cons.ASSESSMENT_STAGE_I_KEYS.RESOLUTION_CERTIFICATE,];
        // allowKeys.includes(id) || (() => { throw "Invalid Step"; })();

        const f_exist = await AppAssessmentFlowStageI.findOne({ where: { step: step, appId: appId, actor: cons.SL.ASSESSOR, recordType: cons.SL.PRESENT }, transaction: t });
        if (!f_exist) {
          throw "Invalid Step";
        }
        const { uniqueID } = f_exist;
        // throw uniqueID;
        for (const [key, value] of Object.entries(jsonData)) {
          const { toSave, id, values, refNo } = value;
          switch (id) {
            case cons.ASSESSMENT_STAGE_I_KEYS.ID_PROOF_OF_AUTHORIZED_SIGNATORY:
            case cons.ASSESSMENT_STAGE_I_KEYS.REGISTRATION_CERTIFICATE_OF_APPLICANT_ORGANIZATION:
            case cons.ASSESSMENT_STAGE_I_KEYS.ID_PROOF_OF_SECRETARY_CHAIRPERSON_PRESIDENT:
            case cons.ASSESSMENT_STAGE_I_KEYS.RESOLUTION_CERTIFICATE:
              if (value.toSave === true) {
                const { as_per_norms, reason, assessor_comments } = values;
                let existing = await GetVerifications.findOne({
                  where: { reff_uniquId: uniqueID, recordType: cons.SL.PRESENT, assessment_id: assessment_id, appId: appId, reffNumber: refNo, keyName: id, isDraft: cons.SL.YES },  // custom condition
                  transaction: t
                });
                if (existing) {
                  if (as_per_norms === cons.SL.YES) {
                    await existing.update({ da_status: cons.SL.REVIEWED, as_per_norms: as_per_norms, reason: null, assessor_comments: null, updateDate: cons.currentDate }, { transaction: t });
                  }
                  else {
                    await existing.update({ da_status: cons.SL.REVIEWED, as_per_norms: as_per_norms, reason: reason, assessor_comments: reason === "other" ? assessor_comments || null : null, updateDate: cons.currentDate }, { transaction: t });
                  }
                } else {
                  const randomId = cons.randomId();
                  await GetVerifications.create({ reff_uniquId: uniqueID, recordType: cons.SL.PRESENT, uniqueId: randomId, reffNumber: refNo, appId, step: step, assessment_id: assessment_id || '', keyName: id, as_per_norms: as_per_norms, reason: reason || '', assessor_comments: assessor_comments || '', isDraft: cons.SL.YES, insertDate: cons.currentDate, reviewDate: cons.currentDate }, { transaction: t });
                }

                let checkListInfo = await DAStageIVerificationsChecklist.findOne({ where: { appId: appId, assessment_id: assessment_id, checkName: id } })
                checkListInfo.update({ da_status: cons.SL.REVIEWED, reviewDate: cons.currentDate });
              }
              break;
            default:
              throw "Key Mismatch";
              break;
          }
        }
        {
          await f_exist.update({ status: cons.SL.COMPLETED, completionDate: cons.currentDate })

          // throw update;
          await AppAssessmentFlowStageI.update(
            { stepStatus: cons.SL.ACTIVE, activeDate: cons.currentDate },
            {
              where: {
                step: cons.ST1FC.REVIEW_ASSESSMENT.step,
                appId: appId,
              }, transaction: t
            }
          );
        }
        break;
      default:
        throw "Invalid Step";
        break;
    }

    await t.commit();

  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    console.log('reached to final')
  }
  return { msg: "Information Successfully" };
};
export const save_reply_da_doc_verification_remarks = async (req, res) => {
  let finalResult = {};
  const t = await sequelize.transaction();
  try {
    const { appId, data, step, assessment_id } = req.body;
    const userType = cons.getUserTypeByString(req.userInfo.userType);
    const userId = req.userInfo.user_id;
    const jsonData = JSON.parse(data);
    switch (step) {
      case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
        for (const [key, value] of Object.entries(jsonData)) {
          const { toSave, id, values, refNo } = value;
          switch (id) {
            case cons.ASSESSMENT_STAGE_I_KEYS.LAND_DOCUMENTS:
            case 'land_documents':
              const exist = await LandDocuments.findAll({ transaction: t, where: { appId: appId, assessment_id: assessment_id, recordType: cons.SL.PRESENT } });
              // await LandDocuments.update({ recordType: cons.SL.HISTORY, update_date: cons.currentDate }, { where: { [Op.or]: [{ appId: appId }, { reference_number: refNo }] }, transaction: t });

              let toSaveArray = [];
              for (const [index, item] of values.onwed_land_documents.entries()) {
                const land_document = req.files.find(f => f.fieldname === `onwed_land_documents[${index}].document`);
                if (!land_document) {
                  throw new Error(`File missing for ${item.land_documents_language} at index ${index}`);
                }
                switch (item.land_documents_language) {
                  case "English":
                  case "Hindi":
                    toSaveArray.push({
                      uniqueId: cons.randomId(),
                      recordType: cons.SL.PRESENT,
                      reference_number: refNo,
                      appId: appId,
                      language: item.land_documents_language,
                      document: land_document.filename,
                      uploaded_datetime: cons.currentDate,
                      assessment_id: assessment_id,
                      file_meta_info: { land_document }
                    });
                    break;
                  default:
                    const land_document_notarised_document = req.files.find(f => f.fieldname === `land_notarised_documents[${index}].notarised_document`);
                    if (!land_document_notarised_document) {
                      throw new Error(`File missing`);
                    }
                    toSaveArray.push({
                      uniqueId: cons.randomId(),
                      recordType: cons.SL.PRESENT,
                      reference_number: refNo,
                      appId: appId,
                      language: item.land_documents_language,
                      document: land_document.filename,
                      notarised_document: land_document_notarised_document.filename,
                      uploaded_datetime: cons.currentDate,
                      assessment_id: assessment_id,
                      file_meta_info: { land_document, land_document_notarised_document }
                    })
                    break;
                }
              }

              await DAStageIVerificationsChecklist.update({ da_status: cons.SL.REPLIED, update_date: cons.currentDate },
                {
                  transaction: t,
                  where:
                  {
                    appId: appId,
                    assessment_id: assessment_id,
                    step: step,
                    checkName: cons.DA1_KEYS.LAND_DOCUMENT
                  }
                });
              await LandDocuments.bulkCreate(toSaveArray, { transaction: t });

              for (const row of exist) {
                await row.update({ recordType: cons.SL.HISTORY });
              }
              break;


            case cons.ASSESSMENT_STAGE_I_KEYS.LAND_AREA:
            case 'land_area':
              const { land_area } = values;
              const exist_land_area = await LandArea.findAll({ transaction: t, where: { appId: appId, assessment_id: assessment_id, recordType: cons.SL.PRESENT } });
              // await LandArea.update({ recordType: cons.SL.HISTORY, update_date: cons.currentDate }, { where: { [Op.or]: [{ appId: appId }, { reference_number: refNo }] }, transaction: t });

              await LandArea.create({
                reference_number: refNo,
                appId: appId,
                assessment_id: assessment_id,
                land_area: land_area,
                recordType: cons.SL.PRESENT,
                created_date: cons.currentDate
              }, { transaction: t });

              for (const row of exist_land_area) {
                await row.update({ recordType: cons.SL.HISTORY, update_date: cons.currentDate });
              }
              await DAStageIVerificationsChecklist.update({ da_status: cons.SL.REPLIED, update_date: cons.currentDate },
                {
                  transaction: t,
                  where:
                  {
                    appId: appId,
                    assessment_id: assessment_id,
                    step: step,
                    checkName: cons.DA1_KEYS.LAND_AREA
                  }
                });
              break;
            default:
              throw "Key Mismatch";
              break;
          }
        }
        await AppAssessmentFlowStageI.update(
          { status: cons.SL.COMPLETED, completionDate: cons.currentDate },
          {
            where: {
              actor: cons.SL.APPLICANT,
              recordType: cons.SL.PRESENT,
              assessment_id: assessment_id,
              step: step,
              appId: appId,
            }, transaction: t
          }
        );
        // throw update;
        await AppAssessmentFlowStageI.update(
          { stepStatus: cons.SL.ACTIVE, activeDate: cons.currentDate },
          {
            where: {
              step: cons.ST1FC.DOCUMENTS_UPLOAD.step,
              actor: cons.SL.APPLICANT,
              recordType: cons.SL.PRESENT,
              assessment_id: assessment_id,
              step: step,
              appId: appId,
            }, transaction: t
          }
        );
        break;

      case cons.ST1FC.DOCUMENTS_UPLOAD.step:
        for (const [key, value] of Object.entries(jsonData)) {
          const { toSave, id, values, refNo } = value;
          switch (id) {
            case cons.ASSESSMENT_STAGE_I_KEYS.ID_PROOF_OF_AUTHORIZED_SIGNATORY:
              // Saving AuthorizedSignatoryDetails
              const { name_of_authorized_signatory,
                email_id_of_authorized_signatory,
                is_verified_email_id_of_authorized_signatory,
                mobile_number_of_authorized_signatory,
                is_verified_mobile_number_of_authorized_signatory,
                id_proof_of_authorized_signatory,
                id_proof_number_of_authorized_signatory,
                id_proof_docs_of_authorized_signatory } = values;


              if (is_verified_email_id_of_authorized_signatory != true) {
                throw new Error("Please Verify Email ID of Authorized Signatory");
              }

              if (is_verified_mobile_number_of_authorized_signatory != true) {
                throw new Error("Please Verify Mobile Number Authorized Signatory");
              }

              const doc_of_authorized_signatory_document = req.files.find(f => f.fieldname === `id_proof_docs_of_authorized_signatory`);
              if (!doc_of_authorized_signatory_document) {
                throw new Error(`File missing`);
              }

              let existASD = await AuthorizedSignatoryDetail.findAll({ where: { appId: appId, assessment_id: assessment_id, recordType: cons.SL.PRESENT }, transaction: t });

              // throw existASD;

              // await AuthorizedSignatoryDetail.update({ recordType: cons.SL.HISTORY, update_date: cons.currentDate }, { where: { [Op.or]: [{ appId: appId }, { reference_number: refNo }] }, transaction: t });

              await AuthorizedSignatoryDetail.create({
                appId: appId,
                name: name_of_authorized_signatory,
                email_id: email_id_of_authorized_signatory,
                mobile_number: mobile_number_of_authorized_signatory,
                id_proof_type: id_proof_of_authorized_signatory,
                id_proof_number: id_proof_number_of_authorized_signatory,
                document: doc_of_authorized_signatory_document.fieldname,
                uploaded_datetime: cons.currentDate,
                document_meta_info: { doc_of_authorized_signatory_document },
                recordType: cons.SL.PRESENT,
                update_date: cons.currentDate,
                reference_number: refNo,
                assessment_id: assessment_id
              }, { transaction: t });

              for (const row of existASD) {
                await row.update({ recordType: cons.SL.HISTORY, update_date: cons.currentDate });
              }
              await DAStageIVerificationsChecklist.update({ da_status: cons.SL.REPLIED, update_date: cons.currentDate }, { transaction: t, where: { appId: appId, assessment_id: assessment_id, step: step, checkName: id } });
              break;
            case cons.ASSESSMENT_STAGE_I_KEYS.REGISTRATION_CERTIFICATE_OF_APPLICANT_ORGANIZATION:
              // Select Registration Certificate of Applicant Organization
              const doc_of_registration_cert_of_applicant_org = req.files.find(f => f.fieldname === `doc_of_registration_cert_of_applicant_org`);
              if (!doc_of_registration_cert_of_applicant_org) {
                throw new Error(`File missing for ${item.language} at index ${index}`);
              }
              let certList1 = await Certificat.findAll({ where: { appId: appId, assessment_id: assessment_id, recordType: cons.SL.PRESENT, keyName: 'registration_certificate' }, transaction: t });
              // await Certificat.update({ recordType: cons.SL.HISTORY, update_date: cons.currentDate }, { where: { [Op.or]: [{ appId: appId }, { reference_number: refNo }] }, transaction: t });
              await Certificat.create({
                appId: appId,
                stage: "STAGE_I",
                keyName: "registration_certificate",
                document: doc_of_registration_cert_of_applicant_org.fieldname,
                upload_datetime: cons.currentDate,
                recordType: cons.SL.PRESENT,
                update_date: cons.currentDate,
                reference_number: refNo,
                assessment_id: assessment_id
              }, { transaction: t });

              for (const row of certList1) {
                await row.update({ recordType: cons.SL.HISTORY, update_date: cons.currentDate });
              }
              await DAStageIVerificationsChecklist.update({ da_status: cons.SL.REPLIED, update_date: cons.currentDate }, { transaction: t, where: { appId: appId, assessment_id: assessment_id, step: step, checkName: id } });
              break;
            case cons.ASSESSMENT_STAGE_I_KEYS.ID_PROOF_OF_SECRETARY_CHAIRPERSON_PRESIDENT:
              for (const [index, item] of values.id_proof_scp.entries()) {
                const document = req.files.find(f => f.fieldname === `id_proof_scp[${index}].document`);
                if (!document) {
                  throw new Error(`File missing`);
                }
                const { designation, id_proof_type, id_proof_number, } = item;

                let exist_scp = await SecretaryChairpersonPresidentIdInfo.findAll({ where: { appId: appId, assessment_id: assessment_id, recordType: cons.SL.PRESENT }, transaction: t });

                // throw exist_scp;
                // await SecretaryChairpersonPresidentIdInfo.update({ recordType: cons.SL.HISTORY, update_date: cons.currentDate }, { where: { appId: appId, recordType: cons.SL.PRESENT, }, transaction: t });

                await SecretaryChairpersonPresidentIdInfo.create({
                  appId: appId,
                  designation: designation,
                  id_proof_type: id_proof_type,
                  id_proof_number: id_proof_number,
                  document: document.filename,
                  uploaded_datetime: cons.currentDate,
                  recordType: cons.SL.PRESENT,
                  update_date: cons.currentDate,
                  reference_number: refNo,
                  assessment_id: assessment_id
                }, { transaction: t, });

                for (const row of exist_scp) {
                  await row.update({ recordType: cons.SL.HISTORY, update_date: cons.currentDate });
                }
                await DAStageIVerificationsChecklist.update({ da_status: cons.SL.REPLIED, update_date: cons.currentDate }, { transaction: t, where: { appId: appId, assessment_id: assessment_id, step: step, checkName: id } });
              }
              break;
            case cons.ASSESSMENT_STAGE_I_KEYS.RESOLUTION_CERTIFICATE:
              // doc_iti_resolution
              const doc_iti_resolution = req.files.find(f => f.fieldname === `doc_iti_resolution`);
              if (!doc_iti_resolution) {
                throw new Error(`File missing`);
              }
              let exist_cert1 = await Certificat.findAll({ where: { appId: appId, assessment_id: assessment_id, recordType: cons.SL.PRESENT, keyName: 'doc_iti_resolution' }, transaction: t });

              // throw exist_cert1;
              // await Certificat.update({ recordType: cons.SL.HISTORY, update_date: cons.currentDate }, { where: { [Op.or]: [{ appId: appId }, { reference_number: refNo }] }, transaction: t });

              await Certificat.create({
                appId: appId,
                stage: "STAGE_I",
                keyName: "doc_iti_resolution",
                document: doc_iti_resolution.filename,
                upload_datetime: cons.currentDate,
                recordType: cons.SL.PRESENT,
                update_date: cons.currentDate,
                reference_number: refNo,
                assessment_id: assessment_id
              }, { transaction: t });

              for (const row of exist_cert1) {
                await row.update({ recordType: cons.SL.HISTORY, update_date: cons.currentDate });
              }
              await DAStageIVerificationsChecklist.update({ da_status: cons.SL.REPLIED, update_date: cons.currentDate }, { transaction: t, where: { appId: appId, assessment_id: assessment_id, step: step, checkName: id } });
              break;
            default:
              throw "Key Mismatch";
              break;
          }
        }
        // throw "Start From Here";
        break;
      default:
        throw "Invalid Step";
        break;
    }
    await t.commit();
    // await t.rollback();
  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    console.log('reached to final')
  }
  return { msg: "Information Successfully" };
};



export const markAsCompleteStageAssessmentFlow = async (req, res) => {
  // const db = await initDB();
  // const formattedDate = new Date().toISOString(); // "2025-08-05T07:25:13.123Z"
  let connection, userId;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  const t = await sequelize.transaction();
  try {
    connection = await mysql.createConnection(affDbConfig);
    const { appId, step, assessment_id, referenceNumber } = req.body;
    userId = req.userInfo.user_id;

    let result = await AssessmentStatus.findOne({
      where: { assessment_id: assessment_id, appId: appId }
    })
    if (!result) {
      throw "Assessment Information Not Found";
    }

    switch (req.userInfo.userType) {
      case "state_assessor":
        {
          const dbStep = await AppAssessmentFlowStageI.findOne({
            where: {
              slno: referenceNumber,
              step: step,
              assessment_id: assessment_id,
              appId: appId,
              actor: cons.SL.ASSESSOR,
              recordType: cons.SL.PRESENT
            }
          })
          if (!dbStep) {
            throw "Assessment Flow Not Found";
          }
          const update = await AppAssessmentFlowStageI.update(
            { status: cons.SL.COMPLETED, completionDate: cons.currentDate },
            {
              where: {
                slno: referenceNumber,
                step: step,
                assessment_id: assessment_id,
                appId: appId,
                actor: cons.SL.ASSESSOR,
                recordType: cons.SL.PRESENT
              }, transaction: t
            }
          );

          if (dbStep?.nextStep && dbStep?.nextStep != cons.LAST) {
            const update = await AppAssessmentFlowStageI.update(
              { stepStatus: cons.SL.ACTIVE, activeDate: cons.currentDate },
              {
                where: {
                  slno: referenceNumber,
                  step: dbStep?.nextStep,
                  assessment_id: assessment_id,
                  appId: appId,
                  actor: cons.SL.ASSESSOR,
                  recordType: cons.SL.PRESENT
                }, transaction: t
              }
            );
          }
        }
        break;
      case "applicant":
        {
          const dbStep = await AppAssessmentFlowStageI.findOne({
            where: {
              slno: referenceNumber,
              step: step,
              assessment_id: assessment_id,
              appId: appId,
              actor: cons.SL.APPLICANT,
              recordType: cons.SL.PRESENT
            }
          })

          if (!dbStep) {
            throw "Assessment Flow Not Found";
          }
          const update = await AppAssessmentFlowStageI.update(
            { status: cons.SL.COMPLETED, completionDate: cons.currentDate },
            {
              where: {
                slno: referenceNumber,
                step: step,
                assessment_id: assessment_id,
                appId: appId,
                actor: cons.SL.APPLICANT,
                recordType: cons.SL.PRESENT
              }, transaction: t
            }
          );

          if (dbStep?.nextStep && dbStep?.nextStep != cons.LAST) {
            const update = await AppAssessmentFlowStageI.update(
              { stepStatus: cons.SL.ACTIVE, activeDate: cons.currentDate },
              {
                where: {
                  slno: referenceNumber,
                  step: dbStep?.nextStep,
                  assessment_id: assessment_id,
                  appId: appId,
                  actor: cons.SL.APPLICANT,
                  recordType: cons.SL.PRESENT
                }, transaction: t
              }
            );
          }
        }
        break;
      default:
        throw "Invalid Request";
        break;
    }

    t.commit();
    // throw req.userInfo.userType;

    // await connection.beginTransaction();

    // let stmt1 = await connection.prepare('SELECT * FROM `' + cons.APP_ASSESSMENT_FLOW_STAGE_I + '` WHERE appId=? and step=?');
    // let [result_1] = await stmt1.execute([appId, step]);

    // if (result_1.length > 0) {
    //   let upd_stmt = await connection.prepare('UPDATE `' + cons.APP_ASSESSMENT_FLOW_STAGE_I + '` SET `status`=?,`completionDate`=? WHERE appId=? and step=?');
    //   await upd_stmt.execute([cons.SL.COMPLETED, cons.currentDate, appId, step]);

    //   let obj = result_1[0];

    //   if (obj?.nextStep && obj?.nextStep != cons.LAST) {

    //     let upd_stmt = await connection.prepare('UPDATE `' + cons.APP_ASSESSMENT_FLOW_STAGE_I + '` SET `stepStatus`=? WHERE appId=? and step=?');
    //     await upd_stmt.execute([cons.SL.ACTIVE, appId, step]);
    //   }
    // }
    // else {
    //   throw new Error("Assessment FLow Information Not Found");
    // }

    // await connection.commit();
  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    console.log('reached to final')
  }
  return { msg: "Information Successfully" };
}

export const getAssessmentProgressStatus = async (req, res) => {
  // const db = await initDB();
  let connection, userId;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  let steps, vStatus = [], allCompleted, assessmentStatus;

  try {

    connection = await mysql.createConnection(affDbConfig);
    const { appId } = req.body;

    userId = req.userInfo.user_id;



    await connection.beginTransaction();


    // Getting the assessment status
    let stmt1 = await connection.prepare('SELECT * FROM `' + cons.TBL_ASSESSMENTS_STATUS + '` WHERE appId=?');
    let [result_1] = await stmt1.execute([appId]);
    if (result_1.length == 0) {
      throw new Error("Assessment Status Not Found");
    }

    assessmentStatus = result_1[0]; //await store_2.index("appId").get(appId);




    let stmt2 = await connection.prepare('SELECT * FROM `' + cons.APP_ASSESSMENT_FLOW_STAGE_I + '` WHERE appId=? and actor=? and step<>"' + cons.ST1FC.REVIEW_ASSESSMENT.step + '" ORDER BY stepNo ASC');
    let [result_2] = await stmt2.execute([appId, cons.SL.ASSESSOR]);
    if (result_2.length == 0) {
      throw new Error("Assessment Flow Not Found");
    }

    steps = result_2;

    allCompleted = steps.every(step => step.status == cons.SL.COMPLETED);
    vStatus.push(allCompleted);


    // Checking the verification status of each step
    steps = await Promise.all(
      steps.map(async (step) => {
        switch (step.step) {
          case cons.ST1FC.APPLICANT_ENTITY_DETAILS.step:
          case cons.ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step:
          case cons.ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step:
          case cons.ST1FC.DOCUMENTS_UPLOAD.step:
            vStatus.push(true);
            break;
          case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step: {
            let stmt = await connection.prepare('SELECT * FROM `' + cons.DA_STAGE_I_VERIFICATIONS + '` WHERE as_per_norms="yes" and  appId=? and keyName=? and isDraft=?');

            let [stmt1] = await stmt.execute([appId, cons.ASSESSMENT_STAGE_I_KEYS.ID_PROOF_OF_AUTHORIZED_SIGNATORY, "yes"]);
            let [stmt2] = await stmt.execute([appId, cons.ASSESSMENT_STAGE_I_KEYS.REGISTRATION_CERTIFICATE_OF_APPLICANT_ORGANIZATION, "yes"]);
            let [stmt3] = await stmt.execute([appId, cons.ASSESSMENT_STAGE_I_KEYS.ID_PROOF_OF_SECRETARY_CHAIRPERSON_PRESIDENT, "yes"]);
            let [stmt4] = await stmt.execute([appId, cons.ASSESSMENT_STAGE_I_KEYS.RESOLUTION_CERTIFICATE, "yes"]);
            let [stmt5] = await stmt.execute([appId, cons.ASSESSMENT_STAGE_I_KEYS.LAND_AREA, "yes"]);

            // throw stmt5;
            // Checking
            (stmt1.length > 0) ? vStatus.push(true) : vStatus.push(false);
            (stmt2.length > 0) ? vStatus.push(true) : vStatus.push(false);
            (stmt3.length > 0) ? vStatus.push(true) : vStatus.push(false);
            (stmt4.length > 0) ? vStatus.push(true) : vStatus.push(false);
            (stmt5.length > 0) ? vStatus.push(true) : vStatus.push(false);

            // const d1 = await Promise.all([stmt1, stmt2, stmt3, stmt4, stmt5]);
            // const allAsPerNorms = d1.flat().every(item => item.as_per_norms === "yes");

            // throw allAsPerNorms;

            // vStatus.push(allAsPerNorms);
            break;
          }

          default:
            vStatus.push(true);
            break;
        }
        return {
          ...step,
          completed: step.status === cons.SL.COMPLETED,
        };
      })
    );

    connection.commit();


  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return {
    steps,
    allCompleted,
    vStatus: vStatus.every(Boolean),
    assessmentStatus
  };
};

export const getAssessmentProgressStatusApplicant = async (req, res) => {
  let connection, userId;
  let allReplied = [], steps, vStatus = [], allCompleted, assessmentStatus;
  // const t = await sequelize.transaction();
  try {

    const { appId } = req.body;
    userId = req.userInfo.user_id;


    assessmentStatus = await AssessmentStatus.findOne({ attributes: ['assessment_id', 'assessment_status', 'appId', 'pendingAt', 'stage'], where: { appId: appId } });

    if (!assessmentStatus) {
      throw new Error("Assessment Status Not Found");
    }

    steps = await AppAssessmentFlowStageI.findAll({
      where: { appId: appId, actor: cons.SL.APPLICANT, recordType: cons.SL.PRESENT }, order: [['stepNo', 'ASC']],
      include: [
        {
          model: DAStageIVerificationsChecklist,
          as: "check_list",
          required: false,
          on: {
            appId: { [Sequelize.Op.eq]: Sequelize.col("AppAssessmentFlowStageI.appId") },
            step: { [Sequelize.Op.eq]: Sequelize.col("AppAssessmentFlowStageI.step") }
          }
        },
      ]
    })


    // throw steps;


    allCompleted = steps.filter(step => step.step !== "REVIEW_ASSESSMENT").every(step => step.status == cons.SL.COMPLETED);
    // vStatus.push(allCompleted);

    await Promise.all(
      steps.map(async (step) => {
        switch (step.step) {
          case cons.ST1FC.APPLICANT_ENTITY_DETAILS.step:
          case cons.ST1FC.DETAILS_OF_THE_PROPOSED_INSTITUTE.step:
          case cons.ST1FC.DETAILS_OF_TRADE_UNIT_FOR_AFFILIATION.step:
          case cons.ST1FC.REVIEW_ASSESSMENT.step:
            allReplied.push(true);
            break;
          case cons.ST1FC.DOCUMENTS_UPLOAD.step:
          case cons.ST1FC.DETAILS_OF_THE_LAND_TO_BE_USED_FOR_THE_ITI.step:
            const all_da_status_is_replied = step.check_list.every(item => item.da_status === "REPLIED");
            allReplied.push(all_da_status_is_replied);
            break;
          default:
            allReplied.push(false);
            break;
        }
        return { ...step, completed: step.status === cons.SL.COMPLETED };
      })
    )





  } catch (err) {
    // await t.rollback();
    throw err;
  } finally {
    console.log('reached to final')
  }
  return {
    steps,
    allCompleted,
    vStatus: vStatus.every(Boolean),
    assessmentStatus,
    allReplied: allReplied.every(Boolean)
  };
};


export const set_da_status_possasion_of_land = async (req, res) => {
  let connection, userId, JsonData;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {

    connection = await mysql.createConnection(affDbConfig);


    const { appId, data } = req.body;
    JsonData = JSON.parse(data);
    const { as_per_norms, reason, assessor_comments } = JsonData;

    userId = req.userInfo.user_id;



    await connection.beginTransaction();


    let stmt1 = await connection.prepare('SELECT * FROM `' + cons.DA_STAGE_I_VERIFICATIONS + '` WHERE appId=? and keyName=? and isDraft=?');
    let [result_1] = await stmt1.execute([appId, cons.DA1_KEYS.LAND_DOCUMENT, 'yes']);
    if (result_1.length > 0) {
      let upd_stmt = await connection.prepare('UPDATE `' + cons.DA_STAGE_I_VERIFICATIONS + '` SET `as_per_norms`=?,	`reason`=?,	`assessor_comments`=?, `updateDate`=? WHERE appId=? and keyName=? and isDraft=?');
      await upd_stmt.execute([as_per_norms, reason, assessor_comments, cons.currentDate, appId, cons.DA1_KEYS.LAND_DOCUMENT, cons.SL.YES]);
    }
    else {
      let ins_stmt1 = await connection.prepare('INSERT INTO `' + cons.DA_STAGE_I_VERIFICATIONS + '` (appId,	keyName,	as_per_norms,	reason,	assessor_comments,	isDraft,	insertDate	) VALUES (?,?,?,?,?,?,?);');
      await ins_stmt1.execute([appId, cons.DA1_KEYS.LAND_DOCUMENT, as_per_norms, reason, assessor_comments, cons.SL.YES, cons.currentDate]);
    }

    // Commit the transaction
    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return { status: true };

};


export const get_da_status_land_area = async (req, res) => {
  let connection, userId;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  let result_1;
  try {

    connection = await mysql.createConnection(affDbConfig);


    const { appId } = req.body;

    userId = req.userInfo.user_id;


    await connection.beginTransaction();


    // Getting the assessment status
    // let stmt1 = await connection.prepare('SELECT * FROM `' + cons.TBL_ASSESSMENTS_STATUS + '` WHERE appId=?');
    // let [result_1] = await stmt1.execute([appId]);
    // if (result_1.length == 0) {
    //   throw new Error("Assessment Status Not Found");
    // }


    // let currentState;

    // const tx = db.transaction([C.DA_STAGE_I_VERIFICATIONS], 'readwrite');
    // const store = tx.objectStore(cons.DA_STAGE_I_VERIFICATIONS);
    // currentState = await store.index("appId_key_isDraft").getAll([appId, C.DA1_KEYS.LAND_AREA, 'yes']);

    let stmt1 = await connection.prepare('SELECT * FROM `' + cons.DA_STAGE_I_VERIFICATIONS + '` WHERE appId=? and keyName=? and isDraft=?');
    let [rows] = await stmt1.execute([appId, cons.DA1_KEYS.LAND_AREA, cons.SL.YES]);

    if (rows.length == 0) {
      throw { status: false, msg: "Record Not Found" };
    }
    result_1 = rows;

    // Commit the transaction
    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return result_1;


};

export const set_da_status = async (req, res) => {
  let connection, userId, JsonData;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {

    connection = await mysql.createConnection(affDbConfig);


    const { appId, data, stage, keyName } = req.body;
    JsonData = JSON.parse(data);
    const { as_per_norms, reason, assessor_comments } = JsonData;
    userId = req.userInfo.user_id;
    await connection.beginTransaction();
    switch (stage) {
      case cons.abbreviation.STAGE_I.key:
        let stmt1 = await connection.prepare('SELECT * FROM `' + cons.DA_STAGE_I_VERIFICATIONS + '` WHERE appId=? and keyName=? and isDraft=?');
        let [result_1] = await stmt1.execute([appId, keyName, cons.SL.YES]);
        if (result_1.length > 0) {
          let upd_stmt = await connection.prepare('UPDATE `' + cons.DA_STAGE_I_VERIFICATIONS + '` SET `as_per_norms`=?,	`reason`=?,	`assessor_comments`=?, `updateDate`=? WHERE appId=? and keyName=? and isDraft=?');
          await upd_stmt.execute([as_per_norms, reason, assessor_comments, cons.currentDate, appId, keyName, cons.SL.YES]);
        }
        else {
          let ins_stmt1 = await connection.prepare('INSERT INTO `' + cons.DA_STAGE_I_VERIFICATIONS + '` (appId,	keyName,	as_per_norms,	reason,	assessor_comments,	isDraft,	insertDate	) VALUES (?,?,?,?,?,?,?);');
          await ins_stmt1.execute([appId, keyName, as_per_norms, reason, assessor_comments, cons.SL.YES, cons.currentDate]);
        }
        // Commit the transaction
        await connection.commit();
        break;
      default:
        throw new Error("stage Not Matched");
        break;
    }

  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
};


export const updateAssessmentStatus = async (req, res) => {
  // Update the app flow status
  let info;
  let connection, userId, JsonData;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {
    connection = await mysql.createConnection(affDbConfig);


    const { appId, stage, status, pendingAt } = req.body;
    // JsonData = JSON.parse(data);
    // const { as_per_norms, reason, assessor_comments } = JsonData;
    userId = req.userInfo.user_id;
    await connection.beginTransaction();
    let stmt1 = await connection.prepare('SELECT * FROM `' + cons.TBL_ASSESSMENTS_STATUS + '` WHERE appId=? and stage=?');
    let [result_1] = await stmt1.execute([appId, stage]);

    if (result_1.length > 0) {
      let upd_stmt = await connection.prepare('UPDATE `' + cons.TBL_ASSESSMENTS_STATUS + '` SET `assessment_status`=?,	`pendingAt`=?  WHERE appId=? and stage=?');
      await upd_stmt.execute([status, pendingAt, appId, stage]);
    }
    else {
      throw new Error("Record Not Found");
    }

    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
};



export const get_da_status = async (req, res) => {
  let connection, userId, JsonData, finalResult;
  // const pool = mysql.createPool(masterConfig);
  // connection = await pool.getConnection();
  try {
    connection = await mysql.createConnection(affDbConfig);

    const { appId, stage, keyName } = req.body;
    userId = req.userInfo.user_id;
    await connection.beginTransaction();
    switch (stage) {
      case cons.abbreviation.STAGE_I.key:
        let stmt1 = await connection.prepare('SELECT * FROM `' + cons.DA_STAGE_I_VERIFICATIONS + '` WHERE appId=? and keyName=? and isDraft=?');
        let [result_1] = await stmt1.execute([appId, keyName, cons.SL.YES]);
        if (result_1.length === 0) {
          //throw new Error("stage Not Matched");
        }
        finalResult = result_1;
        break;
      default:
        throw new Error("stage Not Matched");
        break;
    }
    // Commit the transaction
    await connection.commit();
    // connection.release();
  } catch (err) {
    console.error("Error in checkUser:", err);
    if (connection) {
      await connection.rollback();
    }
    throw err;
  } finally {
    if (connection) await connection.end();
  }
  return finalResult;

};


export const markAsCompleteAssessment = async (req, res) => {
  // const db = await initDB();
  // const formattedDate = new Date().toISOString(); // "2025-08-05T07:25:13.123Z"
  let connection, userId, stmt, result;
  const t = await sequelize.transaction();
  try {

    const { appId } = req.body;

    userId = req.userInfo.user_id;


    // // Update App Flow
    // stmt = await connection.prepare('SELECT * FROM `' + cons.APP_FLOW + '` WHERE step=? and appId = ?');
    // result = await stmt.execute([cons.STAGE_I__ASSESSMENT, appId]);
    // if (result[0].length == 0) {
    //   throw new Error("Form FLow Step Not Found");
    // }

    let appFlowAtStep = await AppFlow.findOne({
      where: {
        step: cons.STAGE_I__ASSESSMENT, appId, appId
      }, transaction: t
    })

    if (!appFlowAtStep) {
      throw "Informatin Not Found";
    }


    let flow = await AppFlow.findOne({
      where: {
        step: cons.STAGE_I__ASSESSMENT,
        appId: appId
      }, transaction: t
    })

    if (!flow) {
      throw "Flow Not Found";
    }

    //  let stmt_upd = await connection.prepare('UPDATE `' + cons.APP_FLOW + '` SET `stepStatus`=?, `status`=?, `completedDate`=? WHERE step=? and appId = ?;');
    // await stmt_upd.execute([cons.SL.COMPLETED, cons.STAGE_I__ASSESSMENT_COMPLETED, cons.currentDate, cons.STAGE_I__ASSESSMENT, appId]);

    await flow.update({ stepStatus: cons.SL.COMPLETED, status: cons.STAGE_I__ASSESSMENT_COMPLETED, completedDate: cons.currentDate })



    // Update Asessment Status
    // stmt = await connection.prepare('SELECT * FROM `' + cons.TBL_ASSESSMENTS_STATUS + '` WHERE appId=? and stage=?');
    // result = await stmt.execute([appId, cons.abbreviation.STAGE_I.key]);


    // if (result[0].length === 0) {
    //   throw new Error("Record Not Found");
    // }
    // stmt = await connection.prepare('UPDATE `' + cons.TBL_ASSESSMENTS_STATUS + '` SET `assessment_status`=?,	`pendingAt`=?  WHERE appId=? and stage=?');
    // await stmt.execute([cons.SL.VERIFIED, cons.SL.NULL, appId, cons.abbreviation.STAGE_I.key]);

    // Assessment Status 
    let asmt_status = await AssessmentStatus.findOne({
      where: {
        appId: appId,
        stage: cons.abbreviation.STAGE_I.key
      }, transaction: t
    });

    if (!asmt_status) {
      throw "Assessment Information Not Found";
    }


    await asmt_status.update({
      assessment_status: cons.SL.VERIFIED, pendingAt: cons.SL.NULL
    }, {
      where: {
        appId: appId,
        stage: cons.abbreviation.STAGE_I.key
      }
    })




    //  // Mark As Complete Assessment for Stage I
    // let stmt1 = await connection.prepare('SELECT * FROM `' + cons.APP_ASSESSMENT_FLOW_STAGE_I + '` WHERE appId=? and step=?');
    // let [result_1] = await stmt1.execute([appId, cons.ST1FC.REVIEW_ASSESSMENT.step]);

    // if (result_1.length == 0) {
    //   throw new Error("Assessment FLow Information Not Found");
    // }

    // let upd_stmt = await connection.prepare('UPDATE `' + cons.APP_ASSESSMENT_FLOW_STAGE_I + '` SET `status`=?,`completionDate`=? WHERE appId=? and step=?');
    // await upd_stmt.execute([cons.SL.COMPLETED, cons.currentDate, appId, cons.ST1FC.REVIEW_ASSESSMENT.step]);
    // Setting UP Assessment FLow 
    let reviewStatus = await AppAssessmentFlowStageI.findOne({
      where: {
        appId: appId,
        step: cons.ST1FC.REVIEW_ASSESSMENT.step,
      }
    })

    if (!reviewStatus) {
      throw "Review Step Information Not Found";
    }

    await reviewStatus.update({
      status: cons.SL.COMPLETED,
      completionDate: cons.currentDate,
      appId: appId,
      step: cons.ST1FC.REVIEW_ASSESSMENT.step,
    })


    //  // Active NOC Step
    //     let stmt_upd2 = await connection.prepare('UPDATE `' + cons.APP_FLOW + '` SET `stepStatus`=?, `startedDate`=? WHERE step=? and appId = ?;');
    //     await stmt_upd2.execute([cons.SL.ON_PROGRESS_2, cons.currentDate, cons.NOC_ISSUANCE, appId]);
    // Settting Up NOC Step 
    let nocStep = await AppFlow.findOne({ where: { step: cons.NOC_ISSUANCE, appId: appId }, transaction: t })

    if (!nocStep) throw new Error("Flow Not Found");


    await nocStep.update({ stepStatus: cons.SL.ON_PROGRESS_2, startedDate: cons.currentDate, })

    await t.rollback();
    // await t.commit();
  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    console.log('reached to final')
  }
  return { status: true };
}

export const generateNoc = async (req, res) => {
  let userId, outputPath, nocFile;
  const t = await sequelize.transaction();
  const t2 = await sequelize.transaction();

  try {
    const { appId, assessment_id, data } = req.body;
    userId = req.userInfo.user_id;
    let jsonData = JSON.parse(data);


    // throw jsonData;


    const result = {};

    for (const [key, value] of Object.entries(jsonData)) {
      // split key
      const [tradePart, shiftPart] = key.split(">>");
      const tradeId = tradePart.split(">")[1];   // "18e67"
      const [shift, index] = shiftPart.split(">"); // "shift1", "0"

      if (!result[tradeId]) {
        result[tradeId] = { shift1: {}, shift2: {} };
      }

      result[tradeId][shift][index] = value;
    }

    let IssuedList = [];

    for (const [tradeId, shifts] of Object.entries(result)) {
      console.log("TradeId:", tradeId);
      const key = Object.keys(shifts.shift1)[0];
      let shift1_value = shifts.shift1[key];
      let shift2_value = shifts.shift2[key];
      // throw { shift1_value, shift2_value, tradeId };
      IssuedList.push({ tradeId: tradeId, appId: appId, issued_unit_in_shift1: shift1_value, issued_unit_in_shift2: shift2_value, issued_date_time: cons.currentDate, });
    }

    try {
      let isExist = await NocIssuedNocDetail.findAll({ where: { appId: appId } });
      if (isExist.length > 0) {
        throw "Issued Trade Already Inserted";
      }
      await NocIssuedNocDetail.bulkCreate(IssuedList, { transaction: t2 });
      await t2.commit();
    } catch (error) {
      await t2.rollback();
      throw error;
    }

    let insertedList = await NocIssuedNocDetail.findAll({
      where: {
        appId: appId
      }, include: [
        {
          model: MasterTradeInfo,
          as: "tradeInfo", // nested include
          attributes: [
            'trade_type',
            'trade_type_id',
            'trade_id',
            'trade_name',
            'is_new_age'
          ]
        }
      ],
    });


    // throw insertedList;



    let instInfo = await ProposedProposedInstituteDetails.findOne({ where: { appId: appId } });

    let InstAddInfo = await ProposedInstituteAddressesDetails.findOne({
      attributes: ['state_code', 'district_code', 'sub_district_code', 'village_code', 'pincode', 'plotNumber_khasaraNumber', 'landmark', 'appId', 'userId'],
      where: { appId: appId },
      include: [
        {
          model: State,
          as: "state_detail", // nested include
          attributes: ['stateCode',
            'stateNameEnglish',
            'stateNameLocal',
            'shortName',
            'stateOrUt']
        },
        {
          model: District,
          as: "district_detail", // nested include
          attributes: ['districtCode',
            'districtNameEnglish',
            'districtNameLocal',
            'districtNameshort',
            'stateCode']
        },
        {
          model: VilDistrictSubDistrict,
          as: "sub_district", // nested include,
          attributes: ['subdistrictCode',
            'subdistrictNameEnglish',
            'districtCode']
        },
        {
          model: VilDistrictSubDistrict,
          as: "village", // nested include
          attributes: ['villageCode',
            'villageNameEnglish',
            'districtCode']
        },
      ],
    });



    // // Example raw query (SELECT)
    // const InstAddInfo = await sequelize.query("SELECT * FROM `proposed_institute_address_view`  WHERE appId = :appId",
    //   {
    //     replacements: { appId },
    //     type: sequelize.QueryTypes.SELECT, // optional, tells Sequelize it’s a SELECT
    //     transaction: t
    //   }
    // );
    // throw InstAddInfo;

    const tradeInfo = await TradesNewInstTrades.findAll({
      where: { appId: appId },
      include: [
        {
          model: MasterTradeInfo,
          as: "tradeInfo", // nested include
          attributes: [
            'trade_type',
            'trade_type_id',
            'trade_id',
            'trade_name',
            'is_new_age'
          ]
        }
      ],
    });
    // const tradeInfo = await sequelize.query("SELECT * FROM `trade_info_view`  WHERE appId = :appId",
    //   {
    //     replacements: { appId },
    //     type: sequelize.QueryTypes.SELECT, // optional, tells Sequelize it’s a SELECT
    //     transaction: t
    //   }
    // );

    // throw tradeInfo;

    // throw tradeInfo;

    const entityDetails = await EntEntityDetails.findOne({
      attributes: [
        "aff_category",
        "aff_sub_category",
        "category",
        "name_of_applicant_entity",
        "ApplicantEntityEmailId",
        "isApplicantEntityEmailIdVerified",
        "ApplicantContactNumber",
        "Is_the_applicant_running_any_other_iti",
        "appId",
        "userId",
      ],
      where: {
        appId: appId
      },
      include: [
        {
          model: EntityAddress,
          as: "ent_address",
          include: [
            {
              attributes: ["stateCode", "stateNameEnglish", "stateNameLocal", "shortName", "stateOrUt", "isactive",],
              model: State,
              as: "state_detail",
            },
            {
              attributes: [
                "districtCode",
                "districtNameEnglish",
                "districtNameLocal",
                "districtNameshort",
                "stateCode",
                "isactive",
              ],
              model: District, as: "district_detail",
            },
            {
              attributes: ["subdistrictCode", "subdistrictNameEnglish", "districtCode", "stateCode",],
              model: VilDistrictSubDistrict,
              as: "sub_district",
            },
            {
              attributes: ["villageCode", "villageNameEnglish", "subdistrictCode", "districtCode", "stateCode", "pincode",
              ],
              model: VilDistrictSubDistrict,
              as: "village",
            }
          ]
        },
        {
          attributes: ["uniqueId", "cat_name", "keyName",
          ],
          model: MasterAffiliationCategory,
          as: "category_info"
        },
        {
          attributes: [
            "uniqueId",
            "affiliation_catId",
            "cat_name",
            "keyName",
          ],
          model: MasterAffiliationSubCategory,
          as: "sub_cat_info"
        }
      ]
    })

    // const entityDetails = await sequelize.query("SELECT * FROM `entity_details_view`  WHERE appId = :appId",
    //   {
    //     replacements: { appId },
    //     type: sequelize.QueryTypes.SELECT, // optional, tells Sequelize it’s a SELECT
    //     transaction: t
    //   }
    // );
    // throw entityDetails;


    const data_obj = {
      instInfo: instInfo.get({ plain: true }),
      InstAddInfo: InstAddInfo.get({ plain: true }),
      tradeInfo: tradeInfo.map(t => t.get({ plain: true })),
      entityDetails: entityDetails?.get({ plain: true }),
      appId: appId,
      insertedList: insertedList.map(t => t.get({ plain: true })),
    }
    // throw data_obj;


    // Check for States Code Inst And user
    if (InstAddInfo.state_code != req.userInfo.state_code) throw new Error("Institute State and User State is Different");


    try {
      nocFile = `noc_certificate_${appId}_${InstAddInfo.state_code}_${cons.randomId()}.pdf`

      // Now you can safely build paths
      const templatePath = path.join(__dirname, "../../assets/templates/NOC/temp_noc_1.html");
      // const templatePath = path.join(__dirname, "../../assets/templates/NOC/temp_1/noc_temp_1.htm");

      // throw InstAddInfo.state_code;
      // throw req.userInfo.state_code;


      // Image Stage Banner Data
      // const state_banner = path.join(__dirname, "../../assets/images/State_Directorate_Headers/");
      // const state_banner_Base64 = fs.readFileSync(state_banner, { encoding: "base64" });
      // const state_banner_image_Base64 = `data:image/png;base64,${state_banner_Base64}`;

      const bannerDir = path.join(__dirname, "../../assets/images/State_Directorate_Headers");

      // Regex to match "<stateCode>_<something>.png"
      const regex = new RegExp(`^${InstAddInfo.state_code}_.+\\.png$`, "i");

      // Find the first matching file
      const fileName = fs.readdirSync(bannerDir).find(f => regex.test(f));
      // throw fileName;
      if (!fileName) {
        throw new Error(`Banner not found for state code: ${stateCode}`);
      }

      // Full path to the file
      const state_banner = path.join(bannerDir, fileName);

      // Read file as Base64
      const state_banner_Base64 = fs.readFileSync(state_banner, { encoding: "base64" });
      const state_banner_image_Base64 = `data:image/png;base64,${state_banner_Base64}`;

      //  throw state_banner_image_Base64;


      // Image Qr Code
      const data = "nocFile";
      const qr_base64 = await QRCode.toDataURL(`${process.env.BASE_URL || '/'}/${nocFile}`, { errorCorrectionLevel: "H" });



      // State Director Singature 
      // Image Stage Banner Data
      const signature = path.join(__dirname, "../../assets/images/state_director_signature/sample_signature.png");
      const signature_Base64 = fs.readFileSync(signature, { encoding: "base64" });
      const signature_image_Base64 = `data:image/png;base64,${signature_Base64}`;


      const templateHTML = fs.readFileSync(templatePath, "utf8");
      // throw templateHTML;
      const template = Handlebars.compile(templateHTML);

      Handlebars.registerHelper("inc", function (value) {
        return parseInt(value) + 1;
      });

      // Convert image to base64
      const dgt_logo = path.join(__dirname, "../../assets/logos/dgt.png");
      const imageBase64 = fs.readFileSync(dgt_logo, { encoding: "base64" });
      const logoData = `data:image/png;base64,${imageBase64}`;

      // throw logoData;

      const toRender = {
        ...req.body,
        ...data_obj,
        state_banner_image_Base64: state_banner_image_Base64,
        qr_base64: qr_base64,
        std_signature: signature_image_Base64,
        StateDirectorName: "Vivek Mishra",
        GeneratedDate: cons.currentDate
      };
      // throw toRender;
      const html = template(toRender);

      const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
      const page = await browser.newPage();
      await page.setContent(html, { waitUntil: "networkidle0" });
      // await page.screenshot({ path: "debug.png", fullPage: true });


      // Generate PDF buffer
      const pdfBuffer = await page.pdf({ format: "A4", printBackground: true });

      await browser.close();

      // Save PDF to server
      // const savePath = "/generated/output.pdf"; // specify your folder and file name
      // const outputDir = process.env.UPLOAD_ROOT_PATH || "E:/generatedNoc/output.pdf";

      // Pick a folder from env or fixed path
      const outputDir = process.env.TEMP_FILES_UPLOAD_PATH || "/all_uploaded_affiliation_documents/temp_files";

      // Ensure the folder exists
      if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
      }

      // Build full path

      outputPath = path.resolve(outputDir, nocFile);

      fs.writeFileSync(outputPath, pdfBuffer);

      await Noc.create({
        appId: appId,
        docName: nocFile,
        genertedDate: cons.currentDate,
        stage: cons.abbreviation.STAGE_I.key,
        status: cons.NOC_ISSUANCE_ISSUED
      }, { transaction: t });
      // throw toRender;
      // Send response with file path
    } catch (err) {
      throw err;
      console.error(err);
      res.status(500).send("Error generating PDF");
    }

    // Updating Application Flows
    await AFlow.update({ stepStatus: cons.SL.COMPLETED, status: cons.NOC_ISSUANCE_ISSUED }, {
      where: { appId, step: cons.NOC_ISSUANCE },
      transaction: t,
    });

    await AFlow.update({ stepStatus: 'pending' }, {
      where: { appId, step: cons.STAGE_II_FORM_FILLING },
      transaction: t,
    });

    // await t.rollback();
    await t.commit();
  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    console.log('reached to final')
  }
  return { status: true, outputPath: nocFile };



  // let connection, userId, stmt, result;
  // // const pool = mysql.createPool(masterConfig);
  // // connection = await pool.getConnection();
  // try {

  //   connection = await mysql.createConnection(affDbConfig);


  //   const { appId } = req.body;

  //   userId = req.userInfo.user_id;

  //   await connection.beginTransaction();
  //   // Objecttive This API
  //   // 1. Restriction 
  //   // 2. Validation
  //   // 3. Applicable to Run this API


  //   // 1. Find the Step Information 
  //   stmt = await connection.prepare('SELECT * FROM `' + cons.APP_FLOW + '` WHERE step=? and appId = ?');
  //   result = await stmt.execute([cons.NOC_ISSUANCE, appId]);
  //   if (result[0].length == 0) {
  //     throw new Error("NOC Step Not Found");
  //   }

  //   // 2. Update Step Information 
  //   let stmt1 = await connection.prepare('UPDATE `' + cons.APP_FLOW + '` SET `stepStatus`=?, `status`=?, `completedDate`=? WHERE step=? and appId = ?;');
  //   await stmt1.execute([cons.SL.COMPLETED, cons.NOC_ISSUANCE_ISSUED, cons.currentDate, cons.NOC_ISSUANCE, appId]);

  //   // 3. Mark Active Next Step of Applciation Flow 
  //   let stmt2 = await connection.prepare('UPDATE `' + cons.APP_FLOW + '` SET `startedDate`=?,  `stepStatus`=? WHERE step=? and appId = ?;');
  //   await stmt2.execute([cons.currentDate, cons.SL.ON_PROGRESS_2, cons.STAGE_II_FORM_FILLING, appId]);


  //   // 4. Generate NOC 
  //   // Generate Code will come here 


  //   // 5. Save NOC Informatio In Database 
  //   let stmt5 = await connection.prepare('INSERT INTO `' + cons.NOCs + '` (appId,	docName,	genertedDate,	stage,	status) VALUES (?,?,?,?,?);');
  //   await stmt5.execute([appId, 'No-Objection-Certificate.pdf', cons.currentDate, cons.abbreviation.STAGE_I.key, cons.NOC_ISSUANCE_ISSUED]);




  //   // Commit the transaction
  //   await connection.commit();
  //   // connection.release();
  // } catch (err) {
  //   console.error("Error in checkUser:", err);
  //   if (connection) {
  //     await connection.rollback();
  //   }
  //   throw err;
  // } finally {
  //   if (connection) await connection.end();
  // }
  // return { status: true };

}


export const setSendApplicationToApplicant = async (req, res) => {
  let connection, userId;
  const t = await sequelize.transaction();
  try {
    const { appId, assessment_id } = req.body;
    userId = req.userInfo.user_id;

    const check1 = await AppAssessmentFlowStageI.findOne({
      where: { assessment_id: assessment_id, appId: appId, recordType: cons.SL.PRESENT, actor: cons.SL.ASSESSOR }
    });
    if (!check1) {
      throw "FLow Not Found";
    }



    // 1. Marks Assessment Pending at Applicant 
    await AssessmentStatus.update(
      { pendingAt: cons.SL.PENDING_AT_APPLICANT },
      { where: { appId: appId, assessment_id: assessment_id }, transaction: t }
    );
    // await t.commit();
    // throw { appId: appId, assessment_id: assessment_id };

    // throw query.toString();

    //End

    // 2. Marks as Completed Review Step fo Assessment Flow 
    AppAssessmentFlowStageI.update(
      { step: cons.ST1FC.REVIEW_ASSESSMENT.step, status: cons.SL.COMPLETED },
      { where: { appId: appId, assessment_id: assessment_id, step: cons.ST1FC.REVIEW_ASSESSMENT.step, actor: cons.SL.ASSESSOR }, transaction: t }
    );
    //End

    // 3. Mark as History Current Assessment
    AppAssessmentFlowStageI.update(
      { recordType: cons.SL.HISTORY },
      { where: { appId: appId, assessment_id: assessment_id, recordType: cons.SL.PRESENT }, transaction: t }
    );
    // End


    // 4. Generate New Flow for Applicnat 
    const flowList = await AppAssessmentFlowStageI.findAll({
      where: { assessment_id: assessment_id, appId: appId, recordType: cons.SL.PRESENT, actor: cons.SL.ASSESSOR }
    });

    // throw flowList;
    const mainStepsData = flowList.map((step) => {
      const obj = step.get({ plain: true }); // plain object
      delete obj.completionDate;
      delete obj.DA;
      delete obj.slno;

      let rObj = {
        referenceNumber: step.uniqueID,
        appId: appId,
        assessment_id: assessment_id,
        uniqueID: cons.randomId(),
        actor: cons.SL.APPLICANT,
        recordType: cons.SL.PRESENT,
        status: cons.SL.PENDING,
        forwarded_by: cons.SL.ASSESSOR
      }
      return { ...obj, ...rObj };  // <-- use obj not step
    });

    // throw mainStepsData;

    await AppAssessmentFlowStageI.bulkCreate(mainStepsData, { transaction: t });
    t.commit();

  } catch (err) {
    await t.rollback();
    throw err;
  } finally {
    console.log('reached to final')
  }
  return { msg: "Information Successfully" };
};

