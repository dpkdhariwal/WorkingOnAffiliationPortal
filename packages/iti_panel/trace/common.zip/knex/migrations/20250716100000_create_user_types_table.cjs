exports.up = function(knex) {
  return knex.schema.createTable("user_types_tbl", function (table) {
    table.string("type").primary();
    table.string("label");
  });
};

exports.down = function(knex) {
  return knex.schema.dropTable("user_types_tbl");
};
