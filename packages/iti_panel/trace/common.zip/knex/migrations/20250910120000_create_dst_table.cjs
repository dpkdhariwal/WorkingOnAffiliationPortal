const TABLE_NAME = 'dst';

/**
 * Create dst table with all required fields
 */
exports.up = function(knex) {
  return knex.schema.createTable(TABLE_NAME, function(table) {
    table.increments('id').primary();
    table.integer('user_id').notNullable();
    table.string('MIS_Code_id');
    table.date('MoU_Start_Date').notNullable();
    table.date('MoU_End_Date').notNullable();
    table.boolean('MoU_Details_verify').defaultTo(false);
    table.string('Name_of_Industry').notNullable();
    table.text('Complete_Address_of_Industry').notNullable();
    table.integer('Total_No_of_Employees').notNullable();
    table.string('Trade_Category').notNullable();
    table.integer('Min_no_of_emp_in_Industry').notNullable();
    table.decimal('Min_turnover_of_industry', 15, 2).notNullable();
    table.string('Turnover_Record_pdf');
    table.boolean('Industry_Details_verify').defaultTo(false);
    table.string('Name_of_Concerned_Person').notNullable();
    table.string('Email_of_Concerned_Person').notNullable();
    table.string('Contact_No_of_Concerned_Person').notNullable();
    table.string('Industry_PAN');
    table.string('Industry_Tin');
    table.string('Industry_GST_Registration_Number');
    table.boolean('Contact_Details_of_Concerned_Person_verify').defaultTo(false);
    table.string('Name_of_Trade_for_DST').notNullable();
    table.integer('Shift_wise_Number_of_Units').notNullable();
    table.string('Affiliated_Units_Status').notNullable(); // Already Affiliated Units / New Unit
    table.boolean('Trade_Details_Sought_Under_DST_verify').defaultTo(false);
    table.timestamps(true, true);
  });
};

exports.down = function(knex) {
  return knex.schema.dropTableIfExists(TABLE_NAME);
};
