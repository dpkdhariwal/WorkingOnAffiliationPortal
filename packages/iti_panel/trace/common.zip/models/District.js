const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const District = sequelize.define('District', {
  districtCode: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: false,
  },
  districtNameEnglish: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  districtNameLocal: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  districtNameshort: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  stateCode: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  census2011Code: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  effectiveDate: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  lastUpdated: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  majorVersion: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  minorVersion: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  transactionId: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  operationCode: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  transactionDescription: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  isactive: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
  },
}, {
  timestamps: true,
  tableName: 'districts',
});

module.exports = District;
