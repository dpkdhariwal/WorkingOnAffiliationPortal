import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

const Dst = sequelize.define('Dst', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  MIS_Code_id: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  MoU_Start_Date: {
    type: DataTypes.DATEONLY,
    allowNull: false,
  },
  MoU_End_Date: {
    type: DataTypes.DATEONLY,
    allowNull: false,
  },
  MoU_Details_verify: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  Name_of_Industry: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  Complete_Address_of_Industry: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  Total_No_of_Employees: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  Trade_Category: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  Min_no_of_emp_in_Industry: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  Min_turnover_of_industry: {
    type: DataTypes.DECIMAL(15, 2),
    allowNull: false,
  },
  Turnover_Record_pdf: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  Industry_Details_verify: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  Name_of_Concerned_Person: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  Email_of_Concerned_Person: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  Contact_No_of_Concerned_Person: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  Industry_PAN: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  Industry_Tin: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  Industry_GST_Registration_Number: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  Contact_Details_of_Concerned_Person_verify: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  Name_of_Trade_for_DST: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  Shift_wise_Number_of_Units: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  Affiliated_Units_Status: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  Trade_Details_Sought_Under_DST_verify: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
}, {
  tableName: 'dst',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});

export default Dst;
