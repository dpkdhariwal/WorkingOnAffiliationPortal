import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

const ITI = sequelize.define('ITI', {
  misCode: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  category: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  address: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  affiliatedTrades: {
    type: DataTypes.JSON, // Array of affiliated trades/units
    allowNull: false,
    defaultValue: [],
  },
}, {
  timestamps: true,
  tableName: 'ITIs',
});

export default ITI;
