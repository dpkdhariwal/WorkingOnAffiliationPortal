import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

const Village = sequelize.define('Village', {
  id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },
  villageCode: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  villageNameEnglish: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  subdistrictCode: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  subdistrictNameEnglish: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  districtCode: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  districtNameEnglish: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  stateCode: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  stateNameEnglish: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  pincode: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
}, {
  timestamps: true,
  tableName: 'villages',
});

export default Village;
