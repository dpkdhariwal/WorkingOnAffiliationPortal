import { DataTypes } from 'sequelize';
import { sequelize } from '../config/database.js';

const State = sequelize.define('State', {
  stateCode: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: false,
  },
  stateNameEnglish: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  stateNameLocal: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  shortName: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  census2011Code: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  effectiveDate: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  lastUpdated: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  majorVersion: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  minorVersion: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  stateOrUt: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  transactionId: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  operationCode: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  transactionDescription: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  isactive: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
  },
}, {
  timestamps: true,
  tableName: 'states', // Ensure it matches the migration table name
});

export default State;
