---
title: Border bottom
categories:
  - UI and keyboard
tags:
  - borders
---
