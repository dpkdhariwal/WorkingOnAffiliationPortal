---
title: Clipboard check fill
categories:
  - Real world
tags:
  - copy
  - paste
---
