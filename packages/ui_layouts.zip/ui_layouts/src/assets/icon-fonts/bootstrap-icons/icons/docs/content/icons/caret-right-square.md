---
title: Caret right square
categories:
  - Carets
tags:
  - caret
  - arrow
  - triangle
---
